import axiosInstance from "./axios";
import { getAuthToken } from "./authToken.service";
const launchPadService = {
  //favourite launchpad lists :
  userFavouriteLaunchPadList: async function (payload) {
    return axiosInstance.post("getUserFavourateLaunchpad", payload);
  },
  addRemoveFavouriteLaunchpad: async function (payload) {
    return axiosInstance.post("addFavourite", payload);
  },
  getSingleLaunchpadDetails: async function (payload) {
    console.log("payload in service", payload);
    return axiosInstance.post("launchpadDetails", payload);
  },
  createLaunchpad: async function (payload) {
    console.log("payload in service", payload);
    return axiosInstance.post("createLaunchpad", payload);
  },
  uploadLogoFileS3: async function (payload) {
    console.log("payload in service", payload);
    let headers = {
      "Content-Type": "multipart/form-data",
      "x-access-token": getAuthToken() || "",
    };
    return axiosInstance.post("uploadLogoFileS3", payload, { headers });
  },
  uploadPdfS3: async function (payload) {
    let headers = {
      "Content-Type": "multipart/form-data",
      "x-access-token": getAuthToken() || "",
    };
    return axiosInstance.post("uploadWhitepaperpdf", payload, { headers });
  },
};
export default launchPadService;
