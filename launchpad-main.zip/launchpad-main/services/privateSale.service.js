import axiosInstance from "./axios";

const privateSaleServices = {
  //favourite launchpad lists :
  userFavouritePresaleList: async function (payload) {
    return axiosInstance.post("getUserFavouratePresale", payload);
  },
  addRemoveFavouritePresale: async function (payload) {
    return axiosInstance.post("addFavourite", payload);
  },

  createPrivateSale: async function (payload) {
    return axiosInstance.post("create-private-sale", payload);
  },

  privatesaledetails: async function (payload) {
    return axiosInstance.post("privatesaledetails", payload);
  },
  getPrivateSaleCommunityVoteAnalysis: async function (payload) {
    return axiosInstance.post("getPrivateSaleCommunityVoteAnalysis", payload);
  },
  privateSaleCommunityAddRemoveLike: async function (payload) {
    return axiosInstance.post("privateSaleCommunityAddRemoveLike", payload);
  },
  privateSaleCommunityAddRemoveDislike: async function (payload) {
    return axiosInstance.post("privateSaleCommunityAddRemoveDislike", payload);
  },
  privateSaleBuy: async function (payload) {
    return axiosInstance.post("private-sale-buy", payload);
  },
};
export default privateSaleServices;
