// create axios instance :
/**
  name:swapnil shewale
  date:20/01/23
*/

import axios from "axios";

//authToken
import { getAuthToken } from "./authToken.service";
// secure
import * as secure from "../utils/secure";

// create instance of axios
const axiosInstance = axios.create({
  baseURL: process.env.API_URL,
  headers: {
    "Content-Type": "application/json",
    // "x-access-token": "1eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNjNiZTYzYTdlMWYwZjJjYjFmNGUzNWM0IiwiaWF0IjoxNjczODQ2NjU4LCJleHAiOjE2NzQwMTk0NTh9.vqbUQX04X_h6cFrp8dsNCjev56l_eoXZb5lJ2GU-cd4";
  },
});

// request middleware
axiosInstance.interceptors.request.use(
  async (config1) => {
    let config = config1;
    // console.log("ax request in axios interceptors brfore", config.data);
    //set token
    config.headers["x-access-token"] = getAuthToken() || "";

    //encrypt data ----------------
    let temp_data = { bytes: null };
    if (process.env.ENV_MODE !== "DEV") {
      temp_data["bytes"] = await secure.encryptData(config.data);
      config.data = temp_data;
    }
    // ------------------

    // console.log("ax request in axios interceptors after", config.data);

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// responce middleware
axiosInstance.interceptors.response.use(
  async (result) => {
    let res = result;

    // console.log("ax responce in axios interceptors before", res);

    //decrypte data ---------------
    let temp_data = res?.data?.data;
    // console.log("ax responce data in axios interceptors before", temp_data);
    if (process.env.ENV_MODE !== "DEV") {
      temp_data = await secure.decrypteData(temp_data);
      res.data.data = await temp_data;
    }
    // ---------------
    // console.log("ax responce in axios interceptors after", res);

    return res;
  },
  async (err) => {
    return Promise.reject(err);
  }
);


const deepCopy = (data) => {
  return JSON.parse(JSON.stringify(data));
};

export default axiosInstance;
