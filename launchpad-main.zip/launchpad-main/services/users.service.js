import axiosInstance from "./axios";
import { getAuthToken } from "../services/authToken.service";
let response = "";
const usersService = {
  loginSignupWithWallet: async function (payload) {
    return axiosInstance.post("loginSignupWithWallet", payload);
  },

  signup: async function (payload) {
    return axiosInstance.post("signup", payload);
  },
  login: async function (payload) {
    return axiosInstance.post("login", payload);
  },
  validateEmail: async function (payload) {
    return axiosInstance.post("validatemail", payload);
  },
  resendOTP: async function (payload) {
    try {
      response = await axiosInstance.post("resendOtp", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  forgetPassword: async function (payload) {
    try {
      response = await axiosInstance.post("forgetPassword", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  resetPassword: async function (payload) {
    try {
      response = await axiosInstance.post("resetPassword", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  //Edit profile page services-
  updateProfile: async function (payload) {
    try {
      response = await axiosInstance.post("updateProfileDetails", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  // updateProfile: async function (payload) {
  //   try {
  //     let headers = {
  //       "x-access-token": getAuthToken(),
  //       "Content-Type": "multipart/form-data",
  //     };
  //     response = await axiosInstance.post("updateProfile", payload, {
  //       headers,
  //     });

  //     return response.data;
  //   } catch (error) {
  //     const { name, message } = error;
  //     response = `${name} => ${message}`;
  //     return response;
  //   }
  // },
  userDetails: async function (payload) {
    try {
      response = await axiosInstance.post("userDetails", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  updateUsername: async function (payload) {
    try {
      response = await axiosInstance.post("updateUsername", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  changePassword: async function (payload) {
    try {
      response = await axiosInstance.post("changePassword", payload);
      return response.data;
    } catch (error) {
      const { name, message } = error;
      response = `${name} => ${message}`;
      return response;
    }
  },
  //update profile and banner image-
  updateProfileAndBannerImage: async function (payload) {
    let headers = {
      "x-access-token": getAuthToken(),
      "Content-Type": "multipart/form-data",
    };
    return axiosInstance.post("updateProfileAndBannerImage", payload, {
      headers: headers,
    });
  },

  updateEmail: async function (payload) {
    return axiosInstance.post("updateEmail", payload);
  },
};
export default usersService;
