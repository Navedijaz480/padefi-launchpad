export const info_msg_create_launchpad = {
  // step 1
  token_address: "This is token address ",
  whitelist_name: "This is whitelist label",
  token_listing: "This is token listing",
  token_option: "This is token option",
  padefi_option: "This is padefi option",
  presale_rate:
    "Enter the number of tokens an investor would get for each 1 unit of BNB they invest.",
  whitelist:
    "It is a pre-approved list of contributors with exclusive access to participate in the presale stage.",
  soft_cap:
    "Softcap is the minimum amount of funds required for the project to proceed.",
  hard_cap:
    "Hardcap is the maximum amount of funds that the project can raise.",
  minimun_buy: "This is minimun_buy",
  maximum_buy: "This is maximum_buy",
  refund_type: "This is refund type",
  router_type:
    "These decentralized exchange (DEX) platforms allow users to trade their tokens without the need for an intermediary.",
  router_liquidity:
    "Enter the percentage of raised funds that should be allocated to liquidity on DEX. Minimum value is 51%, maximum value is 100%.",
  router_list_rate:
    "It  is the initial rate of the liquidity pool (1 BNB = x tokens).",
  start_date: "This is start date",
  end_date: "This is end date",
  liquidity_lockup: "Lock-up time for liquidity pool, for example 30 days.",

  presale_release:
    "The percentage of the first batch of the private sale fund to be released to the project owner. Please note this is expressed in percentage and cannot be greater than 95%.",
  vesting_period:
    "Measured in days, determines the duration between the release of batches of funds from the private sale.",
  token_release: "Presale token release (percent)",

  using_anti_rug_system_check_box:
    "It  requires  project owners to lock their team tokens for a specific period, eliminating the possibility of a rug pull.",
  using_vesting_contributor_check_box:
    "It promotes the long-term price stability of a project by allowing the locking of presale investors' tokens for a specific period, preventing excessive sell pressure during listings. Actions",
  token_description: "Token description.",
  logo_pic_url: "logo pic url",
};
