export const initialSteps = [
  { label: "Verify Token", step_no: 1 },
  { label: "DeFi Launchpad Info", step_no: 2 },
  { label: "Time & Duration", step_no: 3 },
  { label: "Additional info", step_no: 4 },
  { label: "Summery", step_no: 5 },
];

export const initialWhiteList = [
  {
    id: "BNB",
    optionLabel: "BNB",
    defaultValue: "BNB",
    checked: false,
  },
  {
    id: "USDC",
    optionLabel: "USDC",
    defaultValue: "USDC",
    checked: false,
  },
  {
    id: "BUSDT",
    optionLabel: "BUSDT",
    defaultValue: "BUSDT",
    checked: false,
  },
  {
    id: "BUSD",
    optionLabel: "BUSD",
    defaultValue: "BUSD",
    checked: false,
  },
];

export const initialTokenListing = [
  {
    id: "auto",
    optionLabel: "Auto Listing",
    defaultValue: "auto",
    checked: false,
  },
  {
    id: "manual",
    optionLabel: "Manual Listing",
    defaultValue: "manual",
    checked: false,
  },
];

export const initialPadefiOption = [
  {
    id: "1",
    optionLabel: "5% USDC raised only (Recommended)",
    defaultValue: "5",
    checked: false,
  },
  {
    id: "2",
    optionLabel: "2% USDC raised + 2% token sold",
    defaultValue: "2",
    checked: false,
  },
];

export const initialWhitelistOption = [
  {
    id: "disable",
    optionLabel: "Disable",
    defaultValue: "disable",
    checked: false,
  },
  {
    id: "enable",
    optionLabel: "Enable",
    defaultValue: "enable",
    checked: false,
  },
];

export const initialRefundType = [
  {
    name: "Refund",
    defaultValue: "refund",
    selected: false,
  },
  {
    name: "Burn",
    defaultValue: "burn",
    selected: false,
  },
];

export const initialRouterType = [
  {
    name: "Pancakeswap",
    defaultValue: "pancakeswap",
    selected: false,
  },
  // {
  //   name: "PinkSwap Testnet",
  //   defaultValue: "pinkswap_testnet",
  //   selected: false,
  // },
];

export const initialStepOne = {
  token_address: "",
  token_info: {},
  whitelist_name: "",
  token_option: "",
  padefi_option: "",
};

export const initialStepTwo = {
  presale_rate: "",
  whitelist: "",
  soft_cap: "",
  hard_cap: "",
  minimun_buy: "",
  maximum_buy: "",
  refund_type: "",
  router_type: "",
  router_liquidity: "",
  router_list_rate: "",
};

export const initialStepThree = {
  start_date: "",
  end_date: "",
  liquidity_lockup: "",
  anti_rug: false,
  contributer: false,
  presale_release: "",
  vesting_period: "",
  token_release: "",
};

export const initialStepFour = {
  image_url: "",
  token_description: "",
  social_links: [],
  website: "",
  twitter: "",
};

export const initialStepOneError = {
  token_address: null,
  token_info: {},
  whitelist_name: null,
  token_option: null,
  padefi_option: null,
};

export const initialStepTwoError = {
  presale_rate: null,
  whitelist: null,
  soft_cap: null,
  hard_cap: null,
  minimun_buy: null,
  maximum_buy: null,
  refund_type: null,
  router_type: null,
  router_liquidity: null,
  router_list_rate: null,
};

export const initialStepThreeError = {
  start_date: null,
  end_date: null,
  liquidity_lockup: null,
  anti_rug: null,
  contributer: null,
  presale_release: null,
  vesting_period: null,
  token_release: null,
};

export const initialStepFourError = {
  image_url: null,
  token_description: null,
  social_links: [],
  website: null,
  twitter: null,
};


