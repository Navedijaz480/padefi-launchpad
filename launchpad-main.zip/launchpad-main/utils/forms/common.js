export const twitter_base_url = "https://twitter.com/";

export const initialSocialMedia = [
  {
    value: "facebook",
    label: "Facebook",
    isDisabled: false,
    baseUrl: "https://www.facebook.com/",
  },
  {
    value: "linkedin",
    label: "LinkedIn",
    isDisabled: false,
    baseUrl: "https://www.linkedin.com/",
  },
  {
    value: "github",
    label: "Github",
    isDisabled: false,
    baseUrl: " https://github.com/",
  },

  {
    value: "discord",
    label: "Discord",
    isDisabled: false,
    baseUrl: "https://discord.com/",
  },
  { value: "talkwalker", label: "Talkwalker", isDisabled: false, baseUrl: "" },
  // {
  //   value: "twitter",
  //   label: "Twitter",
  //   isDisabled: false,
  //   baseUrl: "https://twitter.com/",
  // },
];

export const softcap_how_many_percent_of_hardcap = 50;
export const minbuy_how_many_percent_of_max_by = 50;


