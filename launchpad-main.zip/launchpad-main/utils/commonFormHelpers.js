const getSocialIcon = (item) => {
    let icon = chainIcon;
    switch (item?.value) {
      case "linkedin":
        icon = showLinkedin;
        break;
  
      case "github":
        icon = show_gitHub;
        break;
  
      case "discord":
        icon = showDiscord;
        break;
  
      case "facebook":
        icon = show_facebook;
        break;
  
      case "talkwalker":
        icon = chainIcon;
        break;
  
      case "instagram":
        icon = showInsta;
        break;
  
      case "twitter":
        icon = showTwitter;
        break;
  
      case "web_link":
        icon = chainIcon;
        break;
    }
  
    return icon;
    // }
  };