//images
import sweplyLogo from "../static/images/sweplyLogo.svg";
import showLink from "../static/images/show-link.png";
import showTwitter from "../static/images/show-twitter.png";
import showTelegram from "../static/images/show-telegram.png";
import showLinkedin from "../static/images/show-linkedin.png";
import showReddit from "../static/images/show-reddit.png";
import showInsta from "../static/images/show-insta.png";
import showDiscord from "../static/images/show-discord.png";
import chainIcon from "../static/images/chainicon.svg";
import show_facebook from "../static/images/show-facebook.png";
import show_gitHub from "../static/images/show-gitHub.png";

// Start validation functions
export const custValidator = {
  //returns true if no is float else false
  isFloat: (value) => value.match(/^([0-9]{1,})?(\.)?([0-9]{1,})?$/),
  isNumber: (value) => value.match(/^[0-9\b]+$/),
  isEmpty: (value) => value !== undefined && value !== null && value !== "",
  isCharecters: (value) => value.match(/^[A-Za-z ]+$/),
};
// End validation functions

export const isEmpty = (str) => {
  return Boolean(str !== undefined && str !== null && str !== " ");
};

//remove html tags
export const removeHtmlTags = (str) => {
  if (!str) return str;
  return str.replace(/<(.|\n)*?>/g, "");
};

//amount
export const addCommasInAmount = (str) => parseFloat(str).toLocaleString("en");

export const commaSeparators = (num) =>
  num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

export const convertToInternationalCurrencySystem = (labelValue) => {
  // Nine Zeroes for Billions
  return Math.abs(Number(labelValue)) >= 1.0e9
    ? (Math.abs(Number(labelValue)) / 1.0e9).toFixed(0) + " B"
    : // Six Zeroes for Millions
    Math.abs(Number(labelValue)) >= 1.0e6
    ? (Math.abs(Number(labelValue)) / 1.0e6).toFixed(0) + " M"
    : // Three Zeroes for Thousands
    Math.abs(Number(labelValue)) >= 1.0e3
    ? (Math.abs(Number(labelValue)) / 1.0e3).toFixed(0) + " K"
    : Math.abs(Number(labelValue));
};

export const _parseInt = (value) => {
  if (typeof value === "number" && !Number.isNaN(value)) return value;
  return parseInt(value);
};

export const removeProtocol = (url) => {
  if (!url) {
    return "";
  }
  return url.replace(/(^\w+:|^)\/\//, "");
};

export const capitalizeFirstLetter = (str) => {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
};


export const addDotToEndOfString = (str,numberOfCharsToShow) => {
  if (!str || !numberOfCharsToShow) return str;
  if (str.length < numberOfCharsToShow) return str;
  return str?.slice(0, numberOfCharsToShow) + "..."
};


//forms
export const getSocialIcon = (value) => {
  let icon = chainIcon;
  switch (value) {
    case "linkedin":
      icon = showLinkedin;
      break;

    case "github":
      icon = show_gitHub;
      break;

    case "discord":
      icon = showDiscord;
      break;

    case "facebook":
      icon = show_facebook;
      break;

    case "talkwalker":
      icon = chainIcon;
      break;

    case "instagram":
      icon = showInsta;
      break;

    case "twitter":
      icon = showTwitter;
      break;

    case "web_link":
      icon = chainIcon;
      break;
  }

  return icon;
  // }
};

export const validateSoftCap = (
  soft_cap,
  hard_cap,
  softcap_how_many_percent_of_hardcap
) => {
  let softcap = _parseInt(soft_cap);
  let hardcap = _parseInt(hard_cap);

  let errMsg = "";

  if (!hardcap) hardcap = 0;
  // if (!softcap) softcap = 0;

  if (!soft_cap) errMsg = "Softcap cannot be blank";
  else if (softcap < 1) errMsg = "Softcap should be greter than zero";
  else if (softcap < (hardcap / 100) * softcap_how_many_percent_of_hardcap)
    errMsg = "Softcap must be greater than or equal 50% of Hardcap";
  else if (softcap > hardcap)
    errMsg = "Softcap must be less than or equal Hardcap";
  else errMsg = "";

  return errMsg;
};

export const validateMinBuy = (
  minimun_buy,
  maximum_buy,
  minbuy_how_many_percent_of_max_by
) => {
  let minimunbuy = _parseInt(minimun_buy);
  let maximumbuy = _parseInt(maximum_buy);

  let errMsg = "";

  // if (!minimunbuy) minimunbuy = 0;
  if (!maximumbuy) maximumbuy = 0;

  // must be positive number
  if (!minimun_buy) errMsg = "Minimum buy cannot be blank";
  else if (minimunbuy < 1) errMsg = "Minimum buy should be greter than zero";
  // else if (minimunbuy < (maximumbuy / 100) * minbuy_how_many_percent_of_max_by)
  //   errMsg = "Minimum buy must be greater than or equal 50% of minimun buy";
  else if (minimunbuy > maximumbuy)
    errMsg = "Minimum buy must be less than max buy";
  else errMsg = "";

  return errMsg;
};
