/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ["padefi-asset.s3.us-east-1.amazonaws.com", "images.pexels.com"],
  },
  experimental: {
    images: {
      layoutRaw: true,
      allowFutureImage: true,
    },
  },
  env: {
    //development mode
    ENV_MODE: "DEV",
    API_URL: "https://devapi.padefi.io/",
    // ENV_MODE: "LIVE",
    EN_SECRETE_KEY:
      "yt1245PADEFIeyJzdWIiOiI5NjU3Mzc1ODgxIiwibmFugohgyuq2147lk54ji6nhdmF0IGRldmVsb3BlciIsImlhdCI6MTUxNjIzOTAyMn0",
  },
};

module.exports = nextConfig;
