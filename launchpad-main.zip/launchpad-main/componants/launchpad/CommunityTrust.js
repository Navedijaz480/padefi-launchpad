import React from "react";
import Image from "next/future/image";
import iconLike from "../../static/images/icon-like.svg";
import iconDisLike from "../../static/images/icon-dislike.svg";
import ProgressBar from "react-bootstrap/ProgressBar";
import FormButton from "componants/common/FormButton";

export default function CommunityTrust(props) {
  const {
    data,
    title,
    question,
    likeBtnLabel,
    dislikeBtnLabel,
    onLike,
    onDislike,
    likeLoader,
    disLikeLoader,
  } = props;
  //   {
  //     "totalVote": 1,
  //     "likedPercent": 0,
  //     "dislikedPercent": 100,
  //     "isLiked": false,
  //     "isDisliked": false
  // }
  return (
    <div className="tokenDetailProgressBar p24">
      <div className="communityTrsutBox">
        <h2 className="font24 fontBold">
          {title} <span>({data?.totalVote} votes)</span>
        </h2>
        <div className="communityTrustProgressBox">
          <span>
            <Image src={iconLike} alt="" />
            {data?.likedPercent}%
          </span>
          <div className="launchpadProgressBar communityTrustProgressBar">
            {/* <div className="progressInner" style={{ width: "75%" }}></div> */}
            <ProgressBar
              variant="success"
              now={data?.likedPercent}
              style={{ background: "#ea4339" }}
            />
          </div>
          <span>
            <Image src={iconDisLike} alt="" />
            {data?.dislikedPercent}%
          </span>
        </div>
      </div>

      <div className="doYouLikeBox">
        <h4 className="font16 fontBold">{question}</h4>
        <div className="doYouLikeBtnBox d-flex">
          <FormButton
            className={data?.isLiked ? "doYouLikeBtn colorGrey " : "colorGrey"}
            name="like_btn"
            label={""}
            disabled={false}
            isLoading={likeLoader}
            onHandleClick={() => onLike()}
          >
            <i class="fal fa-thumbs-up"></i>
            {likeBtnLabel}
          </FormButton>

          <FormButton
            className={
              data?.isDisliked
                ? "doYouLikeBtn doYouDislikeBtn colorGrey"
                : "colorGrey"
            }
            name="dislike_btn"
            label={""}
            disabled={false}
            isLoading={disLikeLoader}
            onHandleClick={() => onDislike()}
          >
            <i class="fal fa-thumbs-down"></i>
            {dislikeBtnLabel}
          </FormButton>
        </div>
      </div>
    </div>
  );
}

// return (
//   <div className="tokenDetailProgressBar p24">
//     <div className="communityTrsutBox">
//       <h2 className="font24 fontBold">
//         Community trust <span>(8 votes)</span>
//       </h2>
//       <div className="communityTrustProgressBox">
//         <span>
//           <Image src={iconLike} alt="" />
//           75%
//         </span>
//         <div className="launchpadProgressBar communityTrustProgressBar">
//           {/* <div className="progressInner" style={{ width: "75%" }}></div> */}
//           <ProgressBar
//             variant="success"
//             now={"20"}
//             style={{ background: "#ea4339" }}
//           />
//         </div>
//         <span>
//           <Image src={iconDisLike} alt="" />
//           25%
//         </span>
//       </div>
//     </div>

//     <div className="doYouLikeBox">
//       <h4 className="font16 fontBold">Do you like Sweply?</h4>
//       <div className="doYouLikeBtnBox d-flex">
//         <button className="doYouLikeBtn colorGrey">
//           <i class="fal fa-thumbs-up"></i>Like
//         </button>
//         <button className="doYouLikeBtn doYouDislikeBtn colorGrey">
//           <i class="fal fa-thumbs-down"></i>Hmmm
//         </button>
//       </div>
//     </div>
//   </div>
// );
