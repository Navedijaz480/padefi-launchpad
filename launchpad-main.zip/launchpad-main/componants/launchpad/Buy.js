import React, { useState } from "react";
//IMPORT COMPONENT
import Input from "componants/common/Input";
import FormButton from "componants/common/FormButton";
import privateSaleServices from "services/privateSale.service";
import { _parseInt } from "utils/helpers";
import { successAlert, errorAlert } from "utils/sweetAlert";

const initialData = {
  amount: "",
  amountErr: "",
};
const Buy = (props) => {
  const { singlePrivateSaleDetails } = props;
  const [isSubmitLoading, setIsSubmitLoading] = useState(false);
  const [data, setData] = useState(initialData);
  const handaleChange = (e) => {
    let { value } = e.target;
    value = value.replace(/\D/g, "");
    setData({ amount: value });
  };

  const handaleSubmit = () => {
    let err = "";
    if (!data?.amount) err = "Enter amount";
    else if (_parseInt(data?.amount) < 1)
      err = "Amount should be greter than zero";
    else err = "";
    if (err) {
      setData({
        ...data,
        amountErr: err,
      });
      return;
    }

    let payload = {
      amount: data?.amount,
      privatesale_id: singlePrivateSaleDetails?._id,
      buy_currency: singlePrivateSaleDetails?.presale_currency,
      buy_curreny_amount: data?.amount,
      buy_tokentotal: "", //value from blockchin
    };

    setIsSubmitLoading(true);
    privateSaleServices
      .privateSaleBuy(payload)
      .then((res) => {
        if (res?.status) {
          successAlert(res?.data?.message);
          setData(initialData);
        } else {
          errorAlert(res?.data?.message);
        }

        setIsSubmitLoading(false);
      })
      .catch((err) => {
        errorAlert(err?.message);
        setIsSubmitLoading(false);
        // setData(initialData);
      });
  };

  return (
    <div className="buyTokenMain">
      <h2 className="font16 fontBold">Buy token</h2>

      <Input
        type="text"
        name="amount"
        className="form-control"
        placeholder="Enter amount"
        parantclassName="form-group mb0"
        onChange={handaleChange}
        value={data?.amount}
        // acceptOnly="number"
        minLength="1"
        maxLength="10"
        pattern="[0-9]{10}\D"
        err={data?.amountErr}
      />

      <div className="d-flex justify-content-between buyTokenValueMain">
        <div className="buyTokenValue">
          1 {singlePrivateSaleDetails?.presale_currency} = 250 ESV
        </div>
        <div className="buyTokenValue">
          Min: {singlePrivateSaleDetails?.minimum_bnb} | Max:{" "}
          {singlePrivateSaleDetails?.maximum_bnb}
        </div>
      </div>

      <div className="buyBNBBtn">
        <FormButton
          className="btnBuyBNB btnBack borderRadius8 p816 font16 font700 dBlock text-center mb24 mt12 col-12"
          label=" Buy with BNB"
          onHandleClick={handaleSubmit}
          isLoading={isSubmitLoading}
        />
      </div>

      <div className="tokenSaleDetailsSection borderNone mt0">
        <div className="tokenSummeryBox mb0">
          <h2 className="fontBold font24 mb16">Your contribution </h2>
          <div class="networkBox">
            <h3 class="font16 colorGrey">Your Contributed Amount</h3>
            <h4 class="">0.00 {singlePrivateSaleDetails?.presale_currency}</h4>
          </div>
          <div class="networkBox">
            <h3 class="font16 colorGrey">Your Reserved Tokens</h3>
            <h4 class="">0 ESV</h4>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Buy;
