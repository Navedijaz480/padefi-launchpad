import React from "react";

export default function InfoRow(props) {
  const { label, value, valueClassName, labelClassName, rowClassName } = props;
  return (
    <div className={rowClassName ? rowClassName : "networkBox"}>
      <h3 className={labelClassName ? labelClassName : "font16 "}>{label}</h3>
      <h4 className={valueClassName ? valueClassName : "fontBold "}>{value}</h4>
    </div>
  );
}

{
  /**
   How to use 
   
   <InfoRow
      rowClassName={"networkBox"}
      labelClassName={"font16"}
      valueClassName={"colorYellow"}
      label={"Private sale Address"}
      value={"Value 123"}
   />

   */
}
