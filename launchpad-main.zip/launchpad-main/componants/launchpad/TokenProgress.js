import React from "react";

export default function TokenProgress(props) {
  const { data } = props;
  return (
    <div className="progressBarToken newProgressbar">
      <h2 className="font16 fontBold">Token progress</h2>
      <div className="progressBarBox">
        <div className="launchpadProgressBar">
          <div
            className="progressInner"
            style={{ width: data?.progresspercentage + "%" }}
          >
            <div className="launchpadProgressBarProgress">
              {data?.progresspercentage}%
            </div>
          </div>
        </div>
        <div className="launchpadProgressBarReading">
          <p className="leftReading">123 {data?.presale_currency}</p>
          <p className="rightReading">246 {data?.presale_currency}</p>
        </div>
      </div>
    </div>
  );
}
