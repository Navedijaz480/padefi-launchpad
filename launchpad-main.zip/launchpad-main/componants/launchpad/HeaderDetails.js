import React, { useState } from "react";
import Image from "next/future/image";
import { useRouter } from "next/router";
import copy from "copy-to-clipboard";
//import images
import sweplyLogo from "../../static/images/sweplyLogo.svg";
import logoMetaMask from "../../static/images/logo-metamask.svg";
import logoTrustWallet from "../../static/images/logo-trustwallet.svg";

import { successAlert } from "utils/sweetAlert";
// componsnts
import SocialShare from "componants/common/SocialShare";

// store

export default function HeaderDetails(props) {
  const {
    tokenName,
    token_symbol,
    sayf,
    kyc,
    audit,
    contractAddr,
    status,
    image_url,
    isFavourite,
    onAddRemoveFavourite,
    addRemoveFavouriteLoading,
    id,
  } = props;

  const [toggleShareMenu, setToggleShareMenu] = useState(false);
  const router = useRouter();
  const handaleCopy = async (textCopy) => {
    copy(textCopy);
    successAlert("Copied");
  };
  const getStatusClass = (statusArg) => {
    if (statusArg === "LIVE") return "liveBox font12";
    else if (statusArg === "UPCOMMING") return "liveBox upcoming font12";
    else return "liveBox ended font12";
  };
  return (
    <div>
      <div className="tokenDetailsBoxHeading">
        <div className="sweplyTokenheading">
          <div className="detail-logo">
            {image_url ? (
              <Image alt="" src={image_url} width={80} height={80} />
            ) : (
              <Image alt="" src={sweplyLogo} width={80} height={80} />
            )}
          </div>
          <div className="tokenCoinNamebox">
            <h3 className="font32 fontBold">
              {tokenName}.
              <span className="colorGrey fontNormal tokenSimballTxt">
                {token_symbol}
              </span>
              {status && (
                <span className={getStatusClass(status)}>{status}</span>
              )}
            </h3>
            <div className="contCodeShareBox bgDarkGrey">
              <span className="contTitle">Contract</span>
              <span className="contCodeDetails colorGrey">
                {contractAddr
                  ? `${contractAddr.slice(0, 5)} ... ${contractAddr.slice(-5)}`
                  : ""}
                <span
                  className="cursor-pointer"
                  onClick={() => handaleCopy(contractAddr)}
                >
                  <i className="far fa-copy"></i>
                </span>
              </span>
              <span className="metaTrustBox">
                <Image alt="" src={logoMetaMask} />{" "}
                <Image alt="" src={logoTrustWallet} />
              </span>
            </div>
          </div>
        </div>
        <div className="likeShareBox">
          <span
            onClick={onAddRemoveFavourite}
            className={
              isFavourite
                ? "favouriteIconHeart verticalAlignTop favouriteAdded cursor-pointer"
                : "favouriteIconHeart verticalAlignTop cursor-pointer"
            }
          >
            <i className="far fa-heart"></i>
          </span>

          <SocialShare
            parantClassName={""}
            toggleShareMenu={toggleShareMenu}
            setToggleShareMenu={() => setToggleShareMenu(!toggleShareMenu)}
            url_for_facebook={`https://dev.padefi.io/private-sale/${id}`}
            url_for_twitter={`https://dev.padefi.io/private-sale/${id}`}
            url_for_linkedin={`https://dev.padefi.io/private-sale/${id}`}
            url_for_copy={`https://dev.padefi.io/private-sale/${id}`}
          />

          <div className="tokenTagBox">
            {sayf && <div className="liveBox sayf font12">SAYF</div>}
            {kyc && <div className="liveBox audit font12">Audit</div>}
            {audit && <div className="liveBox kyc font12">KYC</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
