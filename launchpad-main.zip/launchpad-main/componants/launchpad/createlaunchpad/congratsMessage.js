import React, { useEffect, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/router";
import Link from "next/link";
// packages
import copy from "copy-to-clipboard";
// import images
import token_success from "static/images/token-success-icon.svg";
import tokenImg from "static/images/token-img.png";
// utils
import { successAlert } from "utils/sweetAlert";
import CongratsMessageLayout from "componants/common/CongratsMessageLayout";

export default function CongratsMessage(props) {
  const router = useRouter();
  let contractAddr = "ioiosiaosias";
  console.log("contractaddr123", contractAddr);
  const handaleCopy = async (textToCopy) => {
    copy(textToCopy);
    successAlert("Copied");
  };

  return (
    <CongratsMessageLayout
      message={" Congrats, Your launchpad is ready"}
      description={"Check in by clicking on &quot; View page&quot; "}
    >
      <div className="instantcongratsDone d-flex justify-content-center align-items-center">
        <Link href={"/launchpad/" + props?.id}>
          <a className="instantcongratsDoneBtn font16 fontBold btnTrans">
            View page
          </a>
        </Link>
        <Link href={"/launchpad"}>
          <a className="instantcongratsDoneBtn font16 fontBold">Done</a>
        </Link>
      </div>
    </CongratsMessageLayout>
  );
}

// <div className="instantcongratsMain">
// {!contractAddr ? (
//   <div className="instantcongratsHead text-center">
//     {/* Opps ! Something went wrong! */}
//     Contract address missing !
//   </div>
// ) : (
