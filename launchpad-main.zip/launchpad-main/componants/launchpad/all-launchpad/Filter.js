import React from "react";
import Dropdown from "react-bootstrap/Dropdown";

export default function Filter() {
  return (
    <div>
      <div className="filterBySelectSection">
        <div className="leftFilterBox">
          <h3 className="font16 mb0">Filter By</h3>
          <div className="filterBtnSection">
            <button className="bgDarkGrey active fontWhite">All</button>
            <button className="bgDarkGrey fontWhite">
              <span></span> Ongoing
            </button>
            <button className="bgDarkGrey fontWhite">
              <span className="colorUpcoming"></span> Upcoming
            </button>
            <button className="bgDarkGrey fontWhite">
              <span className="colorEnded"></span> Ended
            </button>
          </div>
        </div>
        <div className="filterRightBox">
          <Dropdown>
            <Dropdown.Toggle variant="success" id="dropdown-basic">
              All chains
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
              <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
              <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
            {/* <i className="fas fa-chevron-down"></i> */}
          </Dropdown>
        </div>
      </div>
    </div>
  );
}
