import React from "react";
import Image from "next/future/image";
import { Chart } from "react-google-charts";
import tokenMetric from "../../static/images/token-matric-chart-img.jpg";
//GOOGLE CHART-
export const data = [
  ["Task", "Hours per Day"],
  ["Burn", 11],
  ["DxLock", 2],
  ["Presale", 2],
  ["Liquidity", 2],
  ["Unlocked", 7], // CSS-style declaration
];

export const options = {
  title: "ESV Distribution",
  pieHole: 0.3,
  is3D: false,
};

export default function TokenDetails() {
  return (
    <div className="tokenMetricMain">
      <h2 className="fontBold font24 mb16">Token Metric</h2>
      {/* <Image src={tokenMetric} alt="" style={{ height: "auto" }} /> */}
      <Chart
        chartType="PieChart"
        width="100%"
        height="400px"
        data={data}
        options={options}
        colors={"#FB7A21"}
        backgroundColor={"red"}
      />
    </div>
  );
}
