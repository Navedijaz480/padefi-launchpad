// // store
// import { openAuthModal, closeAuthModal } from "store/features/users/usersSlice";
// import { getAuthToken } from "services/authToken.service";

// if (!getAuthToken() && router?.query?.forLoginIn) {
//     // handleShow();
//     dispatch(openAuthModal());
//     dispatch(closeAuthModal());
//   }

// import React from "react";
// import { router } from "next/router";

// //auth services
// import {
//   getAppSettingsCookie,
//   getAuthToken,
// } from "../../services/authToken.service";

// import Auth from "../auth";
// // redux
// import { useSelector, useDispatch } from "react-redux";
// import {
//   openAuthLogin,
//   closeAuthLogin,
// } from "../../store/features/users/usersSlice";

// const PrivateRoute = (Children) => {
//   const PrivateComponat = () => {
//     return (
//       <div>
//         <Auth isDefaultOpenLogin={true} />
//       </div>
//     );
//   };

//   return (props) => {
//     const dispatch = useDispatch();
//     const userState = useSelector((state) => state?.users);
//     const appSettingsState = useSelector((state) => state?.appSettingsState);

//     console.log("user123 userState", userState);
//     console.log("user123 appSettingsState", appSettingsState);
//     if (typeof window !== "undefined") {
//       if (!appSettingsState?.blackTheme) {
//         dispatch(openAuthLogin());
//         return <PrivateComponat {...props} />;
//       } else {
//         return <Children {...props} />;
//       }
//     }
//     return null;
//   };
// };

// export default PrivateRoute;

// //redux
// // import { useSelector, useDispatch } from "react-redux";
// //We can not use useSelector and useDispatch here (Redux)
// //TypeError: Cannot read properties of null (reading 'useContext')

// //const dispatch = useDispatch();
// //const userState = useSelector((state) => state.users);

// // if (!userState?.user?.token) {
// //   return <h1>You are not logged in</h1>;
// // }
