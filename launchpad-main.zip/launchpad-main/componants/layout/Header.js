import React, { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/future/image";
import { useRouter } from "next/router";

// images
import logoMain from "../../static/images/logo.svg";
import logoMainBlue from "../../static/images/logoBlue.svg";
import proImg from "../../static/images/round-img.png";

//componants
import Dropdown from "react-bootstrap/Dropdown";
import Auth from "../auth";
import Loader from "componants/common/Loader";

// blockchain
import { checkEmpty } from "../../utils/helpers";
import { ethers } from "ethers";
import { isConnected } from "../auth/wallet/walletConnectAuth";

// auth token
import {
  removeCurrantUser,
  getAuthToken,
  getCurrantUser,
} from "../../services/authToken.service";

// store
import { openAuthModal, closeAuthModal } from "store/features/users/usersSlice";

// redux
import { useSelector, useDispatch } from "react-redux";
import UsersThunkAPI from "../../store/features/users/middleware";
import { logout } from "../../store/features/users/usersSlice";
import { STATUSES } from "../../utils/statuses";

// componants
import WalleteConnectButton from "../auth/CustomWallet/WalleteConnectButton";
import NetworkChainSelectorPopup from "../auth/CustomWallet/NetworkChainSelectorPopup";

// utils
import * as sweetAlert from "../../utils/sweetAlert";
import { isEmpty } from "../../utils/helpers";

export default function Header() {
  const router = useRouter();
  // stats
  const [isLocalLoading, setIsLocalLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  //redux
  const dispatch = useDispatch();
  const userState = useSelector((state) => state.users);
  const user = userState?.user || null;

  //blockchain
  const menuOpen = () => {
    document.body.classList.remove("menuAction");
  };

  const menuClose = () => {
    document.body.classList.add("menuAction");
  };

  const clearCurrantUserData = () => {
    dispatch(logout());
    setIsLoggedIn(false);
  };

  const onLogout = () => {
    clearCurrantUserData();
    router.push("/");
  };

  //wallete
  const [showNetworkChainOptionas, setShowNetworkChainOptionas] =
    useState(false);
  const onShowNetworkChainOptionas = () => {
    setShowNetworkChainOptionas(true);
  };
  const onHideNetworkChainOptionas = () => {
    setShowNetworkChainOptionas(false);
  };
  //wallete

  //  login with wallete address
  const onloginSignupWithWallet = async (data) => {
    //  {
    //   walletAddress
    //    signHash
    //  }
    let payload = {
      wallet_address: data?.walletAddress,
      wallet_signup: true,
      signHash: data?.signHash,
    };

    dispatch(
      UsersThunkAPI.loginSignupWithWallet({
        payload,
        callback: (res) => {
          if (res.status == 1) {
            // onHideConnetWalleteOptions();
            // sweetAlert.successAlert(res?.message);
            // router.push("/user/profile");
          }
        },
      })
    );
  };

  useEffect(() => {
    let token = getAuthToken();
    if (token) setIsLoggedIn(true);
    else setIsLoggedIn(false);
  }, [user]);

  useEffect(() => {
    let token = getAuthToken();
    if (token) {
      let payload = { userid: user?._id };
      dispatch(UsersThunkAPI.userDetailsAsync(payload));
    }
    setIsLocalLoading(false);
  }, []);

  useEffect(() => {
    onIsConnected();
  }, []);

  const onIsConnected = async () => {
    const walletAddress = await isConnected();
    if (walletAddress) {
      const network = await ethers.getDefaultProvider().getNetwork();
    }
  };

  //|| STATUSES?.LOADING == userState?.status
  const getNetworkName = (name) => {
    let temp_name = name;
    switch (name) {
      case "homestead":
        temp_name = "ETH MAINNET";
        break;
      case "bnb":
        temp_name = "BSC MAINNET";
        break;
      case "bnbt":
        temp_name = "BSC TESTNET";
        break;
      case "matic":
        temp_name = "MATIC MAINNET";
        break;
    }
    return temp_name;
  };
  return (
    <>
      <div>
        <div className="mainHeader">
          {isLocalLoading && <Loader />}
          <div className="logoSection d-flex align-items-center">
            <div className="menuIconOpen" onClick={menuOpen}>
              <i className="far fa-bars"></i>
            </div>
            <div className="menuIconClose" onClick={menuClose}>
              <i className="far fa-bars"></i>
            </div>
            <Link href="/">
              <a>
                <Image className="logo" alt="" src={logoMain} />
                <Image className="logoBlue" alt="" src={logoMainBlue} />
              </a>
            </Link>
          </div>
          <div className="rightMenuBox d-flex align-items-center">
            {isLoggedIn && userState?.userWalletInfo && (
              <WalleteConnectButton
                onClick={onShowNetworkChainOptionas}
                className= "binanceBtn fontBold d-flex align-items-center justify-content-center" 
                classNameAfterConnect={"createAccountBtn connectWalletBtn"}
                isConnected={userState?.userWalletInfo?.network?.name}
              >
                {getNetworkName(userState?.userWalletInfo?.network?.name)}
                {/* {userState?.userWalletInfo?.network?.name} */}
                {/* Binance Smart Chain */}
              </WalleteConnectButton>
            )}

            <div className="notificationBox">
              <span className="bellIcon">
                <i className="far fa-bell"></i>
              </span>
              <span className="notiCount">12</span>
            </div>
            {isLoggedIn && (
              <div className="profilemenu">
                <Dropdown>
                  <Dropdown.Toggle variant="success" id="dropdown-basic">
                    {(user?.user_profile_image?.url && (
                      <div className="proPicmainImg">
                        <Image
                          src={user?.user_profile_image?.url || proImg}
                          width={50}
                          height={50}
                          alt="profile-image"
                        />
                      </div>
                    )) || (
                      <span className="proPic">
                        {(isEmpty(user?.name) &&
                          user?.name.charAt(0).toUpperCase()) ||
                          (isEmpty(user?.email) &&
                            user?.email.charAt(0).toUpperCase()) ||
                          "M"}
                      </span>
                    )}
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item>
                      <Link href={"/user/profile"}>My profile</Link>
                    </Dropdown.Item>
                    <Dropdown.Item>
                      {" "}
                      <a href="#">My wallet</a>{" "}
                    </Dropdown.Item>
                    <Dropdown.Item>
                      {" "}
                      <Link href={"/my-token-manager"}>My token manager</Link>
                    </Dropdown.Item>
                    <Dropdown.Item
                      className="logOutmenu"
                      // href="#/action-3"
                      onClick={onLogout}
                    >
                      <a>
                        <span>
                          <svg
                            width="18"
                            height="18"
                            viewBox="0 0 18 18"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M2 2H8C8.55 2 9 1.55 9 1C9 0.45 8.55 0 8 0H2C0.9 0 0 0.9 0 2V16C0 17.1 0.9 18 2 18H8C8.55 18 9 17.55 9 17C9 16.45 8.55 16 8 16H2V2Z"
                              fill="#8B93A3"
                            />
                            <path
                              d="M17.65 8.64954L14.86 5.85954C14.54 5.53954 14 5.75954 14 6.20954V7.99954H7C6.45 7.99954 6 8.44954 6 8.99954C6 9.54954 6.45 9.99954 7 9.99954H14V11.7895C14 12.2395 14.54 12.4595 14.85 12.1395L17.64 9.34954C17.84 9.15954 17.84 8.83954 17.65 8.64954Z"
                              fill="#8B93A3"
                            />
                          </svg>
                        </span>
                        Log Out
                      </a>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
                {/* <DropdownButton
                  id="dropdown-basic-button"
                  title={(isEmpty(user?.name) && user?.name) || "My profile"}
                >
                  <Dropdown.Item href="/profile">Profile</Dropdown.Item>
                  <Dropdown.Item href="">Edit profile</Dropdown.Item>
                  <Dropdown.Item onClick={onLogout}>Logout</Dropdown.Item>
                </DropdownButton> */}
              </div>
            )}
            {/* signup button */}
            {!isLoggedIn && <Auth />}

            {showNetworkChainOptionas && (
              <NetworkChainSelectorPopup
                onConnect={(data) => {
                  // onloginSignupWithWallet(data);
                  onHideNetworkChainOptionas();
                }}
                isPopup={true}
                showNetworkChainOptionas={showNetworkChainOptionas}
                onHideNetworkChainOptionas={onHideNetworkChainOptionas}
                onBack={onHideNetworkChainOptionas}
              />
            )}
          </div>
        </div>
        <div className="heightDev"></div>
      </div>
    </>
  );
}
