import Header from "./Header";
import LeftSidebar from "./LeftSidebar";
import { useRouter } from "next/router";

export default function Layout(props) {
  const router = useRouter();
  const routsToHideComponent = ["/landing"];
  let isHide = routsToHideComponent.includes(router.asPath);
  return (
    <>
      {!isHide && <Header />}
      {!isHide && <LeftSidebar />}
      <div className={!isHide ? "rightSection" : ""}>{props?.children}</div>
    </>
  );
}
