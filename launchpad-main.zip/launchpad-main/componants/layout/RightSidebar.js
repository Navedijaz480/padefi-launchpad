import React from "react";
import Image from "next/future/image";
import rightBarFire from "../../static/images/rightBar-fire.svg";

export default function RightSidebar() {
  return (
    <div className="">
      <div className="rightBarInfoBox mb24">
        <div className="rightBarInfoHeading d-flex justify-content-between">
          <div className="rightBarInfoHead font16 font600">
            <Image src={rightBarFire} alt="" className="mr8" /> trending (24h)
          </div>
          <div className="rightBarInfoView">
            <a href="#" className="rightBarInfoViewBtn font600 colorAC51E0">
              View
            </a>
          </div>
        </div>
        <ul>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              1 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              2 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              3 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between">
            <div className="rightBarInfoContent">
              4 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
        </ul>
      </div>
      <div className="rightBarInfoBox mb24">
        <div className="rightBarInfoHeading d-flex justify-content-between">
          <div className="rightBarInfoHead font16 font600">
            Recent Launchpad
          </div>
          <div className="rightBarInfoView">
            <a href="#" className="rightBarInfoViewBtn font600 colorAC51E0">
              View
            </a>
          </div>
        </div>
        <ul>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              1 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              2 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              3 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between">
            <div className="rightBarInfoContent">
              4 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
        </ul>
      </div>
      <div className="rightBarInfoBox mb24">
        <div className="rightBarInfoHeading d-flex justify-content-between">
          <div className="rightBarInfoHead font16 font600">Recent Presale</div>
          <div className="rightBarInfoView">
            <a href="#" className="rightBarInfoViewBtn font600 colorAC51E0">
              View
            </a>
          </div>
        </div>
        <ul>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              1 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              2 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between mb8">
            <div className="rightBarInfoContent">
              3 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
          <li className="d-flex justify-content-between">
            <div className="rightBarInfoContent">
              4 <span className="font700">trending</span>
            </div>
            <div className="rightBarInfoCount">1</div>
          </li>
        </ul>
      </div>
    </div>
  );
}
