import { useEffect, useState } from "react";
import Image from "next/future/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { getAppSettingsCookie } from "../../services/authToken.service";
//import icons
import logoMain from "../../static/images/logo.svg";

// import homeImg from "../../static/images/leftmenu-home.svg";
// import launchpadImg from "../../static/images/leftmenu-launchpad.svg";
// import presaleImg from "../../static/images/leftmenu-presale.svg";
// import airdropImg from "../../static/images/leftmenu-airdrop.svg";
// import toolboxImg from "../../static/images/leftmenu-toolbox.svg";
// import poolalertsImg from "../../static/images/leftmenu-poolalerts.svg";

//import menulist constant
import { MENUS_LEFT_SIDEBAR } from "./menusLeftSidebar";

//redux
import { useSelector, useDispatch } from "react-redux";
import { changeTheme } from "../../store/features/appSettings/appSettingsSlice";

//cookies
import { parseCookies } from "nookies";

export default function LeftSidebar() {
  //redux
  const appSettingsState = useSelector((state) => state?.appSettingsState);
  const dispatch = useDispatch();
  // const [isLightMode, setIsLightMode] = useState(false);

  const router = useRouter();

  const addBodyClass = () => {
    dispatch(changeTheme());
    // setIsLightMode(true);
    document.body.classList.add("light-mode");
  };
  const removeBodyClass = () => {
    dispatch(changeTheme());
    // setIsLightMode(false);
    document.body.classList.remove("light-mode");
  };
  const menuClose = () => {
    document.body.classList.remove("menuAction");
  };

  const isActive = (routelink, activeMenuRoutes) => {
    // return router.asPath.toLowerCase().includes(menu);

    // console.log("router.asPath", router.asPath);
    return (
      (activeMenuRoutes && activeMenuRoutes.includes(router.asPath)) ||
      routelink == router.asPath
    );
  };

  useEffect(() => {
    // document.body.classList.contains("light-mode") && setIsLightMode(true);

    appSettingsState?.blackTheme
      ? document.body.classList.remove("light-mode")
      : document.body.classList.add("light-mode");
  }, []);

  return (
    <>
      <div className="overlayLeftbar"></div>
      <div className="leftHeadMenuBox">
        <div className="leftMenu" onClick={menuClose}>
          <div className="leftMenuLogo">
            <Link href={"/"}>
              <Image className="logo" alt="" src={logoMain} />
            </Link>
          </div>
          <div className="resMenuClose">
            <i className="fal fa-times"></i>
          </div>
          {/* start left sidebar menu  */}
          <ul>
            {MENUS_LEFT_SIDEBAR?.map((item, index) => (
              <MenuItem
                index={index}
                menu_name={item?.menu_name}
                icon={item?.icon}
                link={item?.link}
                svgIcon={item?.svgIcon}
                isActive={isActive(item?.link, item?.activeMenuRoutes)}
              />
            ))}
          </ul>
          {/* end left sidebar menu  */}

          <div className="menuBotam">
            <div className="socialBtmSection">
              {/* start social media buttons */}
              <div className="socailIcon">
                <a href="#">
                  <i className="fab fa-telegram-plane"></i>
                </a>
                <a href="#">
                  <i className="fab fa-twitter"></i>
                </a>
              </div>
              {/* end social media buttons */}

              {/* start theme button */}
              <div className="socailIcon modeBox cursor-pointer">
                {appSettingsState?.blackTheme ? (
                  <a>
                    {" "}
                    <i
                      className="far fa-lightbulb-on"
                      onClick={addBodyClass}
                    ></i>
                  </a>
                ) : (
                  <a>
                    {" "}
                    <i className="fas fa-moon" onClick={removeBodyClass}></i>
                  </a>
                )}
              </div>
              {/* end theme button */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

const MenuItem = (props) => {
  return (
    <li key={props?.index}>
      <Link href={props?.link}>
        <a className={props?.isActive ? "active" : ""}>
          <div dangerouslySetInnerHTML={{ __html: props.svgIcon }} />
          <span>{props?.menu_name}</span>
        </a>
      </Link>
    </li>
  );
};
