import React from "react";
import Image from "next/future/image";
//IMPORT IMAGES
import sweplyLogo from "../../static/images/sweplyLogo.svg";

//IMPORT COMPONENT
import EndSales from "./EndSales";

export default function AirdropCart(props) {
  const { status, statusClass, detailPageLink } = props;
  return (
    <div>
      <div className="latestLaunchpadBox">
        <div className="latestLaunchpadHead">
          <Image alt="" src={sweplyLogo} />
          <div className="latestLaunchpadDetails">
            <div className="likeBox">
              <i className="far fa-heart"></i>
              <span className={statusClass}>{status}</span>
            </div>
            <div className="clearfix"></div>
          </div>
        </div>
        <h3 className="font18 fontBold">El Salvador crypto work</h3>
        <p className="font14">Project will receive 30% at first release</p>
        <div className="tokenDetailsBox">
          <ul>
            <li>
              Token <span>BNB</span>
            </li>
            <li>
              Total Token <span>1000</span>
            </li>
            <li className="participantQty">
              Participants <span>1000</span>
            </li>
          </ul>
        </div>
        <EndSales
          timer={"12:02:58"}
          viewUrl={"url"}
          detailPageLink={detailPageLink}
        />
      </div>
    </div>
  );
}
