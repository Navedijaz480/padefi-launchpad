import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/future/image";
import viewBtnArrow from "../../static/images/viewbtnarrow.svg";
import viewBtnArrowBlack from "../../static/images/viewbtnarrowblack.svg";
import moment from "moment";
export default function EndSales(props) {
  const Ref = useRef(null);
  const { start_date, created_date, end_date, id, detailPageLink } = props;

  const [ShowDate, setShowDate] = useState("");
  const [ShowDateStatus, setShowDateStatus] = useState("");

  useEffect(() => {
    const startMoment = moment(start_date).format("MM/DD/YYYY hh:mm:ss");
    const endMoment = moment(end_date).format("MM/DD/YYYY hh:mm:ss");
    const now = new Date();
    const currentMoment = moment(now).format("MM/DD/YYYY hh:mm:ss");

    if (startMoment >= currentMoment) {
      const futureDate = new Date(startMoment).getTime();
      setShowDateStatus(`Sale end in ${startMoment} start ${currentMoment}`);
      setShowDateStatus("Sale start in");
      CountDownTimer(futureDate);
    } else if (endMoment > startMoment) {
      if (currentMoment >= endMoment) {
        setShowDateStatus("Sale ended");
        return;
      }
      const futureDate = new Date(endMoment).getTime();
      CountDownTimer(futureDate);
      setShowDateStatus("Sale end in");
    } else if (currentMoment >= endMoment) {
      setShowDateStatus("Sale ended");
    }
  }, []);

  function CountDownTimer(dt) {
    const end = new Date(dt);

    const _second = 1000;
    const _minute = _second * 60;
    const _hour = _minute * 60;
    const _day = _hour * 24;
    let timer;

    function showRemaining() {
      const now = new Date();
      const distance = end - now;
      if (distance < 0) {
        clearInterval(timer);
        return;
      }
      const days = Math.floor(distance / _day);
      const hours = Math.floor((distance % _day) / _hour);
      const minutes = Math.floor((distance % _hour) / _minute);
      const seconds = Math.floor((distance % _minute) / _second);
      setShowDate(days + ": " + hours + ": " + minutes + ": " + seconds);
    }
    timer = setInterval(showRemaining, 1000);
  }

  return (
    <div>
      <div className="saleEndTimerBox">
        <p className="font16">
          {ShowDateStatus}
          {/* timer */}
          <span className="num-span">{ShowDate}</span>
        </p>
        <Link className="" href={`${detailPageLink}`}>
          <span className="launchpadViewBtn cursor-pointer">
            View
            <Image alt="" src={viewBtnArrow} className="viewBtnArrow" />
            <Image
              alt=""
              src={viewBtnArrowBlack}
              className="viewBtnArrowBlack"
            />
          </span>
        </Link>
      </div>
    </div>
  );
}
