import React from "react";
import Image from "next/future/image";
//IMPORT IMAGES
import sweplyLogo from "../../static/images/sweplyLogo.svg";
import viewBtnArrow from "../../static/images/viewbtnarrow.svg";
import viewBtnArrowBlack from "../../static/images/viewbtnarrowblack.svg";
//IMPORT SWIPER
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
//IMPORT COMPONENT
import EndSales from "./EndSales";

export default function Cart(props) {
  const {
    status,
    isKYC,
    isAudit,
    isSAYF,
    tokenName,
    token_symbol,
    hardcap,
    created_date,
    start_date,
    end_date,
    currency,
    Id,
    isLiked,
    isLike,
    fund_release_percent,
    handleLikeUnlike,
    detailPageLink
  } = props;

  const getStatusClass = (statusArg) => {
    if (statusArg === "LIVE") return "liveBox font12";
    else if (statusArg === "UPCOMMING") return "liveBox upcoming font12";
    else return "liveBox ended font12";
  };
  return (
    <div className="latestLaunchpadBox">
      <div className="latestLaunchpadHead">
        <Image alt="" src={sweplyLogo} />
        <div className="latestLaunchpadDetails">
          <div className={(isLiked && "likeBox active") || "likeBox"}>
            <i
              className="far fa-heart"
              onClick={() => handleLikeUnlike(Id)}
            ></i>
            {status && <span className={getStatusClass(status)}>{status}</span>}
          </div>

          <div className="clearfix"></div>
          {isSAYF && <span className="liveBox sayf font12">SAYF</span>}
          {isAudit && <span className="liveBox audit font12">Audit</span>}
          {isKYC && <span className="liveBox kyc font12">KYC</span>}
        </div>
      </div>
      <h3 className="font18 fontBold">
        {tokenName}
        {token_symbol && <span>({token_symbol})</span>}
      </h3>

      {hardcap && (
        <p className="font14">
          {hardcap}/4000 {currency}
        </p>
      )}

      {fund_release_percent && (
        <p className="font14">
          Project will receive {fund_release_percent}% at first release
        </p>
      )}

      <div className="progressBarBox">
        <div className="launchpadProgressBar">
          <div className="progressInner" style={{ width: "50%" }}>
            <div className="launchpadProgressBarProgress">50%</div>
          </div>
        </div>
        <div className="launchpadProgressBarReading">
          <p className="leftReading">123 BNB</p>
          <p className="rightReading">246 BNB</p>
        </div>
      </div>
      {start_date && (
        <EndSales
          id={Id}
          timer={"25:06:48"}
          viewUrl={"url"}
          start_date={start_date}
          end_date={end_date}
          created_date={created_date}
          detailPageLink ={detailPageLink}
        />
      )}
    </div>
  );
}
