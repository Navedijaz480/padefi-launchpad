import React from "react";
import Image from "next/future/image";
import sweplySliderLogo from "../../static/images/sweplySliderImg.svg";
import starIcon from "../../static/images/star.svg";
import sweplyTextIcon from "../../static/images/SWPLY.svg";
import sweplyTextIconBlack from "../../static/images/SWPLYblack.svg";

export default function TrendingSlider() {
  return (
    <div>
      <div className="trendingSlider">
        <div className="tredingDiv">
          Trending​ <span>🔥</span>​​​
        </div>
        <div className="slider">
          <div className="slide-track">
            <div className="slide">#1 AWS</div>
            <div className="slide">#2 AWS</div>
            <div className="slide">#3 AWS</div>
            <div className="slide">#4 AWS</div>
            <div className="slide">#5 AWS</div>
            <div className="slide">#6 AWS</div>
            <div className="slide">#7 AWS</div>
            <div className="slide">#8 AWS</div>
            <div className="slide">#9 AWS</div>
            <div className="slide">#10 AWS</div>
            <div className="slide">#1 AWS</div>
            <div className="slide">#2 AWS</div>
            <div className="slide">#3 AWS</div>
            <div className="slide">#4 AWS</div>
            <div className="slide">#5 AWS</div>
            <div className="slide">#6 AWS</div>
            <div className="slide">#7 AWS</div>
            <div className="slide">#8 AWS</div>
            <div className="slide">#9 AWS</div>
            <div className="slide">#10 AWS</div>
          </div>
        </div>
        <div className="tredingDiv sweplySliderRight">
          <Image alt="" src={starIcon} className="starImg" />
          <Image alt="" src={sweplySliderLogo} className="sweplySliderLogo" />
          <Image alt="" src={sweplyTextIcon} className="sweplyTextIcon" />
          <Image
            alt=""
            src={sweplyTextIconBlack}
            className="sweplyTextIconBlack"
          />
        </div>
      </div>
    </div>
  );
}
