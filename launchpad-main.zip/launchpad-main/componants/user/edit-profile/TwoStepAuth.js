import React from "react";

export default function TwoStepAuth() {
  return (
    <div>
      <h5 className="font16 fontBold">Two-Factor Authentication</h5>
      <p className="colorGrey">
        Add an extra layer of security to your Padefi account by using your
        password and a code on your mobile phone to log in.
      </p>
      <button
        className="btnDisconnect font16 fontBold chgPassword"
        type="button"
      >
        Set up Two-Factor Authentication
      </button>
    </div>
  );
}
