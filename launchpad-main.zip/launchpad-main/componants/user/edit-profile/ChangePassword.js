import React, { useState } from "react";
import usersService from "services/users.service";
import { custValidator } from "utils/helpers";
import validator from "validator";
import * as sweetAlert from "../../../utils/sweetAlert";
import { encryptData_, decrypteData_ } from "../../../utils/secure";

// import { useSelector, useDispatch } from "react-redux";

// import {
//   openForgotPwPopup,
//   closeForgotPwPopup,
// } from "../../../store/features/users/usersSlice";

const initialState = {
  oldpassword: "",
  newpassword: "",
};
const initialError = {
  oldpassword: null,
  newpassword: null,
};

export default function ChangePassword(props) {
  const { user } = props;
  // const dispatch = useDispatch();

  const [showPassModal, setShowPassModal] = useState(false);
  const [hideUpdateModal, sethideUpdateModal] = useState(true);
  const [userDetails, setUserDetails] = useState(initialState);
  const [validateError, setValidateError] = useState(initialError);
  const [passwordType, setPasswordType] = useState("password");
  const [passwordType2, setPasswordType2] = useState("password");

  const onHandleOpenCloseModal = () => {
    setShowPassModal(true);
    sethideUpdateModal(false);
  };
  const handleClose = () => {
    setShowPassModal(false);
    sethideUpdateModal(true);
    setUserDetails(initialState);
    setValidateError(initialError);
  };

  const togglePassword = (event, label) => {
    event.preventDefault();
    if (label == "oldPassword") {
      let temp = "";
      temp = passwordType == "password" ? "text" : "password";
      setPasswordType(temp);
    } else {
      let temp = "";
      temp = passwordType2 == "password" ? "text" : "password";
      setPasswordType2(temp);
    }
  };

  const onHandleinfo = (event, label) => {
    const { value } = event.target;
    switch (label) {
      case "oldPassword":
        setUserDetails({ ...userDetails, oldpassword: value.trim() });
        break;
      case "newPassword":
        setUserDetails({ ...userDetails, newpassword: value.trim() });
        break;
      case "oldPassErr":
        if (value && !validator.isStrongPassword(value)) {
          setValidateError({
            ...validateError,
            oldpassword: "Please enter password",
          });
        } else {
          setValidateError({
            ...validateError,
            oldpassword: null,
          });
        }
        break;
      case "newPassErr":
        if (!validator.isStrongPassword(value)) {
          setValidateError({
            ...validateError,
            newpassword:
              "password must contain atleast one uppercase letter,special character and number.",
          });
        } else {
          setValidateError({
            ...validateError,
            newpassword: null,
          });
        }
        break;
      default:
        setUserDetails(initialState);
        setValidateError(initialError);
        break;
    }
  };
  const passCheck = Boolean(userDetails.oldpassword && userDetails.newpassword);
  const checkError = Boolean(
    validateError.oldpassword || validateError.newpassword
  );

  const validate = () => {
    let valid = true;
    if (!userDetails?.oldpassword) {
      setValidateError({
        ...validateError,
        oldpassword: "Plaese enter old password",
      });
      //sweetAlert.errorAlert("plaese enter old password");
      valid = false;
    } else if (!userDetails?.newpassword) {
      setValidateError({
        ...validateError,
        newpassword: "Plaese enter new password",
      });
      valid = false;
    } else if (userDetails?.oldpassword == userDetails?.newpassword) {
      sweetAlert.errorAlert("Old Password and new password cannot be same");
      valid = false;
    }
    return valid;
  };

  const onHandleChangePassword = async () => {
    if (!validate()) return;
    try {
      if (
        custValidator.isEmpty(userDetails.oldpassword) &&
        custValidator.isEmpty(userDetails.newpassword) &&
        passCheck &&
        !checkError
      ) {
        let encrypted_oldpw = encryptData_(userDetails?.oldpassword);
        let encrypted_newpw = encryptData_(userDetails?.newpassword);
        let payload = {
          user_id: user?._id,
          oldPassword: encrypted_oldpw,
          newPassword: encrypted_newpw,
        };
        const response = await usersService.changePassword(payload);
        if (response.status) {
          setUserDetails(response.data);
          handleClose();
          sweetAlert.successAlert(response.message);
        } else {
          sweetAlert.errorAlert(response.message);
        }
      } else {
        sweetAlert.errorAlert("something went wrong");
      }
    } catch (error) {
      const { name, message } = error;
      console.log(`${name}=>${message}`);
    }
  };

  // const goForgetPassword = () => {
  //   dispatch(openForgotPwPopup());
  //   // closeForgotPwPopup,
  // };
  return (
    <div>
      <h5 className="font24 fontBold">Account security</h5>
      <p className="colorGrey">Update your profile image and details here</p>
      {hideUpdateModal && (
        <div className="updatePassBtnBox">
          <h4 className="font16">Passaword</h4>
          {/* <p className="resetPassTxt colorGrey">
            Can’t remember your current password ?{" "}
            <a href="#">Reset your password</a>
          </p> */}

          <button
            className="updatePassBtn font16 fontBold"
            type="button"
            onClick={onHandleOpenCloseModal}
          >
            Update Password
          </button>
        </div>
      )}
      {showPassModal && (
        <div className="passwordFlidShowBox">
          <div className="crossbtnLabel">
            <h2 className="font16 fontBold mb0">Enter your password</h2>
            <button type="button" onClick={handleClose}>
              <i className="far fa-times"></i>
            </button>
          </div>
          <div className="form-group">
            <input
              type={passwordType}
              className="form-control"
              placeholder="Old password"
              value={userDetails.oldpassword}
              onChange={(e) => onHandleinfo(e, "oldPassword")}
              onKeyUp={(e) => onHandleinfo(e, "oldPassErr")}
            />
            <button
              className="showEyeIcon"
              onClick={(e) => togglePassword(e, "oldPassword")}
            >
              {passwordType === "password" ? (
                <i className="far fa-eye-slash"></i>
              ) : (
                <i className="far fa-eye"></i>
              )}
            </button>
            <div>
              <h6 style={{ color: "#d34747" }}>{validateError.oldpassword}</h6>
            </div>
          </div>
          <div className="form-group">
            {/* <label>New Password</label> */}
            <input
              type={passwordType2}
              className="form-control"
              placeholder="New password"
              value={userDetails.newpassword}
              onChange={(e) => onHandleinfo(e, "newPassword")}
              onKeyUp={(e) => onHandleinfo(e, "newPassErr")}
            />
            <button
              className="showEyeIcon"
              onClick={(e) => togglePassword(e, "newPassword")}
            >
              {passwordType2 === "password" ? (
                <i className="far fa-eye-slash"></i>
              ) : (
                <i className="far fa-eye"></i>
              )}
            </button>
            <div>
              <h6 style={{ color: "#d34747" }}>{validateError.newpassword}</h6>
            </div>
          </div>

          <button
            className={
              (checkError && "btnDisconnect2 font16 fontBold chgPassword") ||
              "btnDisconnect font16 fontBold chgPassword"
            }
            type="button"
            disabled={checkError}
            style={{ cursor: (checkError && "no-drop") || "pointer" }}
            onClick={onHandleChangePassword}
          >
            Change Password
          </button>
          {/* <p className="resetPassTxt colorGrey">
            Can’t remember your current password?
            <a href="/">Reset your password</a>
          </p> */}
        </div>
      )}
    </div>
  );
}
