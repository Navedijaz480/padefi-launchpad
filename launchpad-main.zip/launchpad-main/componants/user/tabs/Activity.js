import React from "react";
import Link from "next/link";
import { useSelector } from "react-redux";
//IMPORT COMPONENT
import CountItem from "../tabs/tabs-components/CountItem";
import RecentItems from "./tabs-components/RecentItems";
import RecentTransaction from "./tabs-components/RecentTransaction";
export default function Activity() {
  const user = useSelector((state) => state?.users?.user);
  return (
    <div>
      <div className="myTokenMainSection">
        <h2 className="font20 fontBold mb16">My activity</h2>
      </div>
      <div className="d-flex justify-content-between align-items-center mobileBlock">
        <div className="pollBoxParent mr24">
          <CountItem label="Total pools invested" count={0} index={0} />
        </div>
        <div className="pollBoxParent mr24">
          <CountItem label="Total ETH invested" count={0} index={2} />
        </div>
        <div className="pollBoxParent mr24">
          <CountItem label="Total invested" count={`$0`} index={1} />
        </div>
      </div>
      <div className="poolInvestedMain mb16">
        <div className="myTokenMainSection d-flex justify-content-between mb16">
          <h2 className="font20 fontBold mb16">Recent Total pool invested</h2>
          <Link href={"/pool-invested-list"}>
            <a className="color338BFF font16 font700">Show all</a>
          </Link>
        </div>
        <div className="poolInvestedContent">
          {(!user?.wallet_address && (
            <div className="connectWalletMessage text-center">
              Connect wallet to show details
            </div>
          )) ||
            ""}
          {user?.wallet_address && (
            <div className="poolInvestedContent">
              {/* Recent Total pool invested component */}
              <RecentItems
                parentClassName={
                  "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center "
                }
                index={0}
                imageUrl={"image url"}
                tokenName={"Sweply inu."}
                tokenSymbol={"Swply"}
                viewUrl={"url"}
                isLike={true}
              />
              <RecentItems
                URL={"image url"}
                tokenName={"Sweply inu."}
                tokenSymbol={"Swply"}
                View={"url"}
                active={true}
                parentClassName={
                  "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center "
                }
              />
            </div>
          )}
        </div>
      </div>
      <div className="poolInvestedMain">
        {/* recent transactions */}
        {user?.wallet_address && <RecentTransaction />}
      </div>
    </div>
  );
}
