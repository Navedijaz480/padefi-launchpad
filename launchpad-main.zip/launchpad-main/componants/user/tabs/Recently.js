import React from "react";
import Image from "next/future/image";
import RecentItems from "./tabs-components/RecentItems";

export default function Recently() {
  return (
    <div>
      <div className="myTokenMainSection">
        <h2 className="font20 fontBold mb16">Recently visited</h2>
      </div>
      <div className="poolInvestedContent">
        <RecentItems
          parentClassName={
            "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center"
          }
          index={0}
          imageUrl={"image url"}
          tokenName={"Sweply inu."}
          tokenSymbol={"Swply"}
          viewUrl={"url"}
          isLike={true}
        />
      </div>
    </div>
  );
}
