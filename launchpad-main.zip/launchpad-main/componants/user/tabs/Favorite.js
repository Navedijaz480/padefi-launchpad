import React, { useState, useEffect } from "react";
//REDUX
import { useRouter } from "next/router";
import { useSelector, useDispatch } from "react-redux";
import LaunchPadThunkAPI from "../../../store/features/launchPads/middleware";
import PresaleThunkAPI from "../../../store/features/privateSale/middleware";
import TokenManagerThunkAPI from "../../../store/features/tokenManager/middleware";
import { removeFavouriteLaunchpad } from "store/features/launchPads/launchPadSlice";
import { removeFavouritePresale } from "store/features/privateSale/privateSaleSlice";
import tokenThunkAPI from "store/features/token/middleware";
//IMPORT COMPONENT
import RecentItems from "./tabs-components/RecentItems";
export default function Favorite() {
  const dispatch = useDispatch();
  const router = useRouter();
  const user = useSelector((state) => state?.users?.user);
  const { launchPad } = useSelector((state) => state.launchPadState);
  const { favTokenPageList } = useSelector((state) => state.tokenManagerState);
  const { presale } = useSelector((state) => state.presaleState);

  const [isFavouriteTokenPage, setIsFavouriteTokenPage] = useState(true);
  // get user favourite launchpad list
  useEffect(() => {
    const payload = {
      user_id: user?._id,
    };
    dispatch(LaunchPadThunkAPI.favouriteLaunchPadAsync(payload));
  }, []);

  // get user favourite presale list
  useEffect(() => {
    const payload = {
      user_id: user?._id,
    };
    dispatch(PresaleThunkAPI.favouritePresaleAsync(payload));
  }, []);

  // get user favourite token page list
  useEffect(() => {
    const payload = {
      user_id: user?._id,
    };
    dispatch(TokenManagerThunkAPI.favouriteTokenPageAsync(payload));
  }, []);

  /**
   *@desc add or remove favourite launchpad to list
   */
  const handleLikeDislikeLaunchpad = (Id) => {
    dispatch(removeFavouriteLaunchpad(Id));
    //console.log("ID", Id);
    try {
      const payload = {
        launchpad_id: Id,
      };
      dispatch(
        LaunchPadThunkAPI.addFavouriteLaunchpadAsync({
          payload: payload,
          callback: (res) => {
            if (res?.status) {
              const payload = {
                user_id: user?._id,
              };
              //dispatch(LaunchPadThunkAPI.favouriteLaunchPadAsync(payload));
            }
          },
        })
      );
    } catch (error) {
      console.log("error", error);
    }
  };

  // add or remove favourite presale to list
  const handleLikeDislikePresale = (Id) => {
    dispatch(removeFavouritePresale(Id));
    try {
      const payload = {
        presale_id: Id,
      };
      dispatch(
        PresaleThunkAPI.addFavouritePresaleAsync({
          payload: payload,
          callback: (res) => {
            if (res?.status) {
              const payload = {
                user_id: user?._id,
              };
              //dispatch(PresaleThunkAPI.favouritePresaleAsync(payload));
            }
          },
        })
      );
    } catch (error) {
      console.log("error", error);
    }
  };

  //add/remove favourite token page
  const handleLikeDislikeTokenPage = (id) => {
    setIsFavouriteTokenPage(!isFavouriteTokenPage);
    try {
      const payload = {
        tokenPageid: id,
      };

      dispatch(tokenThunkAPI.tokenPageAddRemoveFavouriteAsync(payload));
    } catch (error) {
      console.log("error", error);
    }
  };

  //redirect to token page
  const redirectToTokenPage = (id) => {
    router.push(`/token/${id}`);
  };

  return (
    <div>
      <div className='myTokenMainSection'>
        <h2 className='font20 fontBold mb16'>Favourite Launchpad</h2>
      </div>
      <div className='favoriteLaunchBoxMain'>
        <div className='favoriteLaunchBoxInner'>
          <div className='row'>
            {launchPad &&
              Array.isArray(launchPad) &&
              launchPad.map((item, i) => (
                <div className='col-sm-12 col-md-6 col-lg-6' key={i}>
                  <RecentItems
                    parentClassName={
                      "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center favoriteLaunchBox"
                    }
                    key={i + 1}
                    Id={item?._id}
                    isLiked={item?.isLiked}
                    imageUrl={item?.logo_url}
                    tokenName={item?.tokenName}
                    tokenSymbol={item?.token_symbol}
                    viewUrl={"url"}
                    isLike={true}
                    handleLikeDislike={handleLikeDislikeLaunchpad}
                  />
                </div>
              ))}
          </div>
        </div>
      </div>
      {/* Favourite Presale */}

      <div className='myTokenMainSection'>
        <h2 className='font20 fontBold mb16'>Favourite Presale</h2>
      </div>
      <div className='favoriteLaunchBoxMain'>
        <div className='favoriteLaunchBoxInner'>
          <div className='row'>
            {presale &&
              Array.isArray(presale) &&
              presale.map((item, i) => (
                <div className='col-sm-12 col-md-6 col-lg-6' key={i}>
                  <RecentItems
                    parentClassName={
                      "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center favoriteLaunchBox"
                    }
                    key={i + 1}
                    Id={item?._id}
                    isLiked={item?.isLiked}
                    tokenName={item?.presale_title}
                    isLike={true}
                    handleLikeDislike={handleLikeDislikePresale}
                  />
                </div>
              ))}
          </div>
        </div>
      </div>

      <div className='myTokenMainSection'>
        <h2 className='font20 fontBold mb16'>Favourite Token Page</h2>
      </div>
      <div className='favoriteLaunchBoxMain'>
        <div className='favoriteLaunchBoxInner'>
          <div className='row'>
            {favTokenPageList &&
              Array.isArray(favTokenPageList) &&
              favTokenPageList.map((item, i) => (
                <div className='col-sm-12 col-md-6 col-lg-6' key={i}>
                  <RecentItems
                    parentClassName={
                      "poolInvestedContentRow colorECF1FF d-flex justify-content-between align-items-center favoriteLaunchBox"
                    }
                    key={i + 1}
                    Id={item?.tokenPageid}
                    isLiked={true}
                    imageUrl={item?.tokenPagedata?.logo_uri}
                    tokenName={item?.tokenPagedata?.token_data?.[0]?.name}
                    isLike={true}
                    handleLikeDislike={handleLikeDislikeTokenPage}
                    isFavourite={isFavouriteTokenPage}
                    viewPageUrl={redirectToTokenPage}
                  />
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
