import React, { useEffect } from "react";
import { useRouter } from "next/router";
import { useSelector, useDispatch } from "react-redux";
import MyTokenListItem from "./tabs-components/MyTokenListItem";
import FormButton from "../../common/FormButton";
import CountItem from "../tabs/tabs-components/CountItem";

export default function Overview() {
  const router = useRouter();
  const { singleUserTokenList } = useSelector((state) => state.tokenState);
  return (
    <div>
      <div className="activityPollTab">
        <div className="totalPoolsInvestedSection">
          <div className="tootalPoolMainBox">
            <CountItem label="Total pools invested" count={0} index={0} />
            <span className="heightLine"></span>
            <CountItem label="Total invested" count={`$0`} index={1} />
            <span className="heightLine"></span>
            <CountItem label="Total ETH invested" count={0} index={2} />
          </div>
          <a className="activityViewBtn font16 fontBold" href="#">
            View my activity
          </a>
        </div>
        <div className="myTokenMainSection">
          <h2 className="font20 fontBold">My Token</h2>
          {singleUserTokenList && singleUserTokenList?.length != 0
            ? singleUserTokenList &&
              Array.isArray(singleUserTokenList) &&
              singleUserTokenList.map((item, i) => (
                <MyTokenListItem
                  key={i + 1}
                  tokenName={item.token_name}
                  tokenId={item._id}
                  tokenSymbol={item.token_symbol}
                  contractAddr={item.contractAddress}
                />
              ))
            : "No token have been created"}
          <div className="createTokenBtn">
            <FormButton
              label="Create new Token"
              onHandleClick={() => router.push("/toolbox?forCreateToken=true")}
              className="btnCreateToken"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
