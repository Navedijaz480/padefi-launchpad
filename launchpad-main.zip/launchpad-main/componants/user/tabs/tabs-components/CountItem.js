import React from "react";

export default function CountItem(props) {
  const { label, count, index } = props;
  return (
    <div className="pollBox" key={index}>
      <p>{label}</p>
      <h2 className="font24 font700">{count}</h2>
    </div>
  );
}
