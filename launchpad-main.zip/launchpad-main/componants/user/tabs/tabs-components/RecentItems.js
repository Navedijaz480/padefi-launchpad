import React from "react";
import Link from "next/link";
import Image from "next/future/image";
import investedUserIcon from "../../../../static/images/poll-sweply-logo.svg";

export default function RecentItems(props) {
  const {
    index,
    imageUrl,
    tokenName,
    tokenSymbol,
    viewUrl,
    isLiked,
    parentClassName,
    handleLikeDislike,
    Id,
    isFavourite,
    viewPageUrl,
  } = props;

  return (
    <div className={parentClassName}>
      <div className='investedContentLeft posRelative'>
        <div className='investedContentImg posAbsolute'>
          <Image src={investedUserIcon} alt='image' width={35} height={35} />
        </div>
        <div className='investedContentxt'>
          <div className='investedContentHead font16'>{tokenName}</div>
          <div className='investedContentSubHead font16'>{tokenSymbol}</div>
        </div>
      </div>
      <div className='investedContentLeft d-flex align-items-center cursor-pointer'>
        <div
          className={
            (isFavourite && "investedContentWishlist active") ||
            "investedContentWishlist"
          }
        >
          <i
            className='far fa-heart'
            onClick={(e) => handleLikeDislike(Id)}
          ></i>
        </div>
        <div className='viewBtnfav font16 font700'>
          <Link href='/launchpad/Details'>View</Link>
          {/* <span
            onClick={() => {
              viewPageUrl(Id);
            }}
          >
            View
          </span> */}
        </div>
      </div>
    </div>
  );
}
