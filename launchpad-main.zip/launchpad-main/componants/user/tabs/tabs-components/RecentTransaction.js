import React from "react";
import Link from "next/link";
import Image from "next/future/image";
import { useSelector } from "react-redux";
import ethTableIcon from "../../../../static/images/ethereum-table-icon.svg";
import investedUserIcon from "../../../../static/images/poll-sweply-logo.svg";
export default function RecentTransaction() {
  const user = useSelector((state) => state?.users?.user);
  return (
    <div>
      <div className="myTokenMainSection d-flex justify-content-between mb16">
        <h2 className="font20 fontBold mb16">Recent transactions</h2>
        <Link href={"/transection-list"}>
          <a className="color338BFF font16 font700">Show all</a>
        </Link>
      </div>
      <div className="poolInvestedContent poolRecentTransactionsContent">
        {(!user?.wallet_address && (
          <div className="connectWalletMessage text-center p24">
            Connect wallet to show details
          </div>
        )) ||
          ""}
        <div className="table-responsive">
          <table className="table font16">
            <caption></caption>
            <thead>
              <tr>
                <th>Name</th>
                <th>Amount</th>
                <th>Type</th>
                <th>Date</th>
                <th>Transaction</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <Image src={investedUserIcon} alt="" className="mr16" />
                  Sweply
                </td>
                <td>
                  <Image src={ethTableIcon} alt="" className="mr16" />
                  18.4
                </td>
                <td>Launchpad</td>
                <td>13:44 - 4/7/2022</td>
                <td>
                  <a href="#" className="tableViewBtn font16">
                    View
                  </a>
                </td>
              </tr>
              <tr>
                <td>
                  <Image src={investedUserIcon} alt="" className="mr16" />
                  Sweply
                </td>
                <td>
                  <Image src={ethTableIcon} alt="" className="mr16" />
                  18.4
                </td>
                <td>Launchpad</td>
                <td>13:44 - 4/7/2022</td>
                <td>
                  <a href="#" className="tableViewBtn font16">
                    View
                  </a>
                </td>
              </tr>
              <tr>
                <td>
                  <Image src={investedUserIcon} alt="" className="mr16" />
                  Sweply
                </td>
                <td>
                  <Image src={ethTableIcon} alt="" className="mr16" />
                  18.4
                </td>
                <td>Launchpad</td>
                <td>13:44 - 4/7/2022</td>
                <td>
                  <a href="#" className="tableViewBtn font16">
                    View
                  </a>
                </td>
              </tr>
              <tr>
                <td>
                  <Image src={investedUserIcon} alt="" className="mr16" />
                  Sweply
                </td>
                <td>
                  <Image src={ethTableIcon} alt="" className="mr16" />
                  18.4
                </td>
                <td>Launchpad</td>
                <td>13:44 - 4/7/2022</td>
                <td>
                  <a href="#" className="tableViewBtn font16">
                    View
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
