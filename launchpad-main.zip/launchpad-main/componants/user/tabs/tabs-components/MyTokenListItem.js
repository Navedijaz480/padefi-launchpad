import React from "react";
import Link from "next/link";
import Image from "next/future/image";
import copy from "copy-to-clipboard";
import { useRouter } from "next/router";
import tokenImg from "../../../../static/images/token-img.png";
import FormButton from "../../../common/FormButton";
import { successAlert } from "../../../../utils/sweetAlert";

export default function MyTokenListItem(props) {
  const { tokenName, tokenSymbol, contractAddr, tokenId } = props;
  const router = useRouter();
  //const { contractaddr } = router.query;
  const handaleCopy = async (textToCopy) => {
    copy(textToCopy);
    successAlert("Copied");
  };
  return (
    <div>
      <div className='myTokenBoxWithBtn mb16'>
        <div className='myTokanBox'>
          <div className='tokennameimgBox'>
            <div className='tokenImg'>
              <Image alt='' src={tokenImg} />
            </div>
            <div className='tokenNamenInfo'>
              <h3 className='font16'>{tokenName}</h3>
              <p>{tokenSymbol}</p>
            </div>
          </div>
          <div className='contractAddressBox'>
            <p className='fontNormal'>Contract address</p>
            <h2 className='font16 fontNormal'>
              {contractAddr}
              <span
                onClick={() => handaleCopy(contractAddr)}
                className='cursor-pointer'
              >
                <i className='far fa-copy'></i>
              </span>
            </h2>
          </div>
          {/* <Link
            className='activityViewBtn font16 fontBold'
            href={`/token/${tokenId}`}
            // href='/token-explore'
          >
            View page
          </Link> */}
        </div>
        <div className='tokenCreateABox'>
          {/* <a className="pagePresaleBtn font16 fontBold" href="#">
                View presale page
              </a> */}

          <FormButton
            label='View presale page'
            onHandleClick={() => router.push("/presale")}
            className='pagePresaleBtn font16 fontBold'
          />
          <FormButton
            label='Create launchpad'
            onHandleClick={() => router.push("/launchpad")}
            className='pagePresaleBtn font16 fontBold'
          />
          <FormButton
            label='Create Airdrop'
            onHandleClick={() => router.push("/airdrop")}
            className='pagePresaleBtn font16 fontBold'
          />
        </div>
      </div>
    </div>
  );
}
