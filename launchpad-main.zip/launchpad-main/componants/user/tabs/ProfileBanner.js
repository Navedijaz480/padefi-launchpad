import React, { useEffect, useState, useRef } from "react";
import Image from "next/future/image";
import Link from "next/link";
import { Modal, Button } from "react-bootstrap";
import { nanoid } from "@reduxjs/toolkit";
import bannerImg from "../../../static/images/banner-img.png";
import proImg from "../../../static/images/round-img.png";
import * as sweetAlert from "../../../utils/sweetAlert";
import { useSelector, useDispatch } from "react-redux";
import UsersThunkAPI from "../../../store/features/users/middleware";
import moment from "moment";

//import package for crop images
import {
  FixedCropper,
  ImageRestriction,
  CircleStencil,
} from "react-advanced-cropper";

import "react-advanced-cropper/dist/style.css";
import Resizer from "react-image-file-resizer";

//custom wallet
import WalleteConnectButton from "componants/auth/CustomWallet/WalleteConnectButton";
import CustomWalletConnector from "componants/auth/CustomWallet/NetworkChainSelectorPopup";

export default function ProfileBanner(props) {
  const dispatch = useDispatch();
  const { isEdit } = props; //isEdit is used for hide or show div when page switch.
  const cropperRef = useRef();
  //PROFILE IMAGE STATE
  const imageInputRef = useRef();
  const [showModal, setShowModal] = useState(false);
  const [imageStatus, setImageStatus] = useState(false);
  const [imageURL, setImageURL] = useState();
  const [CropImageURL, setCropImageURL] = useState();
  //BANNER IMAGE STATE
  const bannerInputRef = useRef();
  const [bannerImageStatus, setBannerImageStatus] = useState(false);
  const [showBannerModal, setShowBannerModal] = useState(false);
  const [bannerImageURL, setBannerImageURL] = useState();
  const [CropBannerImageURL, setCropBannerImageURL] = useState();
  const [userDetails, setUserDetails] = useState();

  const user = useSelector((state) => state?.users?.user);

  const onHandleOpenModal = (label) => {
    if (label === "openProfile") {
      setShowModal(true);
    } else {
      setShowBannerModal(true);
    }
  };
  const onHandleCloseModal = (label) => {
    if (label === "closeProfile") {
      setCropImageURL("");
      setShowModal(false);
    } else {
      setCropBannerImageURL("");
      setShowBannerModal(false);
    }
  };
  const onHandleClick = (label) => {
    if (label === "profileClick") {
      imageInputRef.current && imageInputRef.current.click();
    } else {
      bannerInputRef.current && bannerInputRef.current.click();
    }
  };

  function onHandleImageUpload(event, label) {
    try {
      const { files } = event.target;
      const file = files && files[0];
      if (file instanceof File) {
        const fileType = file.type;
        const isImage = ["image/jpg", "image/jpeg", "image/png", "image/webp"];
        const isFileImage = Boolean(isImage.includes(fileType));
        if (isFileImage) {
          let imgUrl = URL.createObjectURL(file);
          if (imgUrl) {
            if (label === "profile") {
              setCropImageURL(imgUrl);
              onHandleOpenModal("openProfile");
            } else {
              setCropBannerImageURL(imgUrl);
              onHandleOpenModal("openBanner");
            }
          } else {
            throw new Error("Image url not converted");
          }
        } else {
          sweetAlert.errorAlert("Unsupported file selected.");
          throw new TypeError("The File not supported", file.name);
        }
      }
      event.target.value = null;
    } catch (error) {
      if (error instanceof TypeError) {
        const { name, message, fileName } = error;
        console.error(`${name} => ${message} => ${fileName}`);
      }
    }
  }

  const dataURLtoFile = (dataurl, filename) => {
    let arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  };

  const onHandleCompressImage = (file) =>
    new Promise((resolve) => {
      try {
        Resizer.imageFileResizer(
          file,
          300,
          300,
          "JPEG",
          100,
          0,
          (uri) => {
            resolve(uri);
          },
          "file"
        );
      } catch (error) {
        const { name, message } = error;
        console.error(`${name} => ${message}`);
      }
    });

  const onHandleImageCrop = async (image) => {
    // bannerImg , profileImg
    try {
      const cropper = cropperRef.current; //get cropper dom
      if (cropper) {
        const canvas = cropper.getCanvas(); // get canvas for image
        const file = dataURLtoFile(canvas.toDataURL(), `${nanoid()}.jpg`); //convert base64 to image file

        // ---------------------------------------------------------------
        // do not compress image due to image quality
        // const compressImage = await onHandleCompressImage(file); //send to API
        const compressImage = file; //send to API
        // ---------------------------------------------------------------
        let urlTopreview = URL.createObjectURL(compressImage);
        if (image === "profileImg") {
          setImageURL(URL.createObjectURL(file));
          setImageStatus(true);
          setCropImageURL();
          setShowModal(false);

          //send compressed file to edit profile page to submit
          props.onChangeProfileImage(compressImage);
        } else {
          setBannerImageURL(URL.createObjectURL(file));
          setBannerImageStatus(true);
          setCropBannerImageURL();
          setShowBannerModal(false);

          //send compressed file to edit profile page to submit
          props.onChangeBannerImage(compressImage);
        }
      } else {
        throw new Error("Cropper error");
      }
    } catch (error) {
      const { name, message } = error;
      console.error(`${name} => ${message}`);
    }
  };

  //custome wallete
  const [showConnetWalleteOptionas, setShowConnetWalleteOptions] =
    useState(false);
  const onShowConnetWalleteOptions = () => {
    setShowConnetWalleteOptions(true);
  };
  //console.log("showConnetWalleteOptionas", showConnetWalleteOptionas);
  const onHideConnetWalleteOptions = () => {
    setShowConnetWalleteOptions(false);
  };

  //  login with wallete address
  const onloginSignupWithWallet = async (data) => {
    onHideConnetWalleteOptions();
    let payload = {
      wallet_address: data?.walletAddress,
      wallet_signup: true,
      signHash: data?.signHash,
    };

    dispatch(
      UsersThunkAPI.loginSignupWithWallet({
        payload,
        callback: (res) => {
          if (res.status == 1) {
            // sweetAlert.successAlert(res?.message);
            // router.push("/user/profile");
          }
        },
      })
    );
  };

  useEffect(() => {
    let payload = { userid: user?._id };
    dispatch(UsersThunkAPI.userDetailsAsync(payload));
  }, []);

  //  // wallet verify
  //  useEffect(() => {
  //   if (isConnected) {
  //     console.log("address : ", address);

  //     // wallet verify

  //     // api call and store wallet address
  //   } else {
  //     console.log("not connected");
  //   }
  // }, [isConnected]);
  console.log("user1233", user);
  return (
    <>
      {/* banner image */}
      <div className='profileCoverPage'>
        <span>
          {(bannerImageStatus && (
            <Image
              src={bannerImageURL != "" ? bannerImageURL : bannerImg}
              width={870}
              height={350}
              alt='img'
            />
          )) || (
            <Image
              src={user?.user_banner_image?.url || bannerImg}
              width={870}
              height={350}
              alt='img'
            />
          )}
        </span>
        {isEdit && (
          <button
            className='coverPageBtn fontBold'
            onClick={() => onHandleClick("bannerClick")}
          >
            <i className='fas fa-camera'></i> Edit cover page
          </button>
        )}
        <input
          ref={bannerInputRef}
          type='file'
          accept='image/*'
          onChange={(e) => onHandleImageUpload(e, "banner")}
          hidden
        />
      </div>
      {/* end banner image */}
      <div className='profileBoxSection'>
        <div className='profileTitlePicBox'>
          <div className='profilePicBox'>
            {/* profile image */}
            <div className='proPicmainImg'>
              <span>
                {(imageStatus && (
                  <Image
                    src={imageURL != "" ? imageURL : proImg}
                    width={100}
                    height={100}
                    alt='img'
                  />
                )) || (
                  <Image
                    src={user?.user_profile_image?.url || proImg}
                    width={100}
                    height={100}
                    alt='img'
                  />
                )}
              </span>
              {/* camera icon */}
              <div className='profileImgUpload'>
                {isEdit && (
                  <button
                    onClick={() => onHandleClick("profileClick")}
                    type='button'
                    className='d-flex justify-content-center align-items-center'
                  >
                    <i className='fas fa-camera'></i>
                  </button>
                )}
                <input
                  ref={imageInputRef}
                  type='file'
                  accept='image/*'
                  onChange={(e) => onHandleImageUpload(e, "profile")}
                  hidden
                />
              </div>
            </div>
            {/* profile image end */}

            {/* user details */}
            {!isEdit && (
              <div className='pro-userDetails'>
                <h2 className='font24 fontBold'>{user?.name}</h2>
                <h3 className='colorGrey'>@{user?.username}</h3>
              </div>
            )}
          </div>
          {!isEdit && (
            <Link href='/user/profile/edit-profile'>
              <a className='editProBtn font16 fontBold'>
                <i className='fas fa-pen'></i> Edit Profile
              </a>
            </Link>
          )}
        </div>
        {!isEdit && (
          <div className='joinAndConnectWalletBox'>
            <p className='colorGrey'>
              Joined.{" "}
              <span>
                {user?.created_at && moment(user?.created_at).format("ll")}
              </span>
            </p>

            {(user?.wallet_address && (
              <div className='prowalleticonBtn colorGrey d-flex'>
                {/* <button
                    className="prowalleticonBtn colorGrey "
                    // onClick={openChainModal}
                    type="button"
                  > */}
                <i class='fas fa-wallet'></i> {user?.wallet_address}
                {/* </button> */}
              </div>
            )) || (
              <WalleteConnectButton
                className={"walleteConnectBtn fontBold"}
                classNameAfterConnect={""}
                onClick={onShowConnetWalleteOptions}
                type='button'
              >
                Wallete connect
              </WalleteConnectButton>
            )}

            <CustomWalletConnector
              onConnect={(data) => {
                onloginSignupWithWallet(data);
              }}
              isPopup={true}
              showConnetWalleteOptionas={showConnetWalleteOptionas}
              onHideConnetWalleteOptions={onHideConnetWalleteOptions}
              // onBack={() => setShowLoginSignupTabs(true)}
            />

            {/* <ConnectButton.Custom>
              {({
                account,
                chain,
                openAccountModal,
                openChainModal,
                openConnectModal,
                authenticationStatus,
                mounted,
              }) => {
                // Note: If your app doesn't use authentication, you
                // can remove all 'authenticationStatus' checks
                const ready = mounted && authenticationStatus !== "loading";
                const connected =
                  ready &&
                  account &&
                  chain &&
                  (!authenticationStatus ||
                    authenticationStatus === "authenticated");

                return (
                  <div
                    className={isConnected ? "walletButtonMain w100" : ""}
                    {...(!ready && {
                      "aria-hidden": true,
                      style: {
                        opacity: 0,
                        pointerEvents: "none",
                        userSelect: "none",
                      },
                    })}
                  >
                    {(() => {
                      if (!connected) {
                        return (
                          <button
                            className="connectWalletproBtn"
                            onClick={openConnectModal}
                            type="button"
                          >
                            Wallet Connect
                          </button>
                        );
                      }

                      return (
                        <div className="">
                          <button
                            className="prowalleticonBtn colorGrey"
                            // onClick={openChainModal}
                            type="button"
                          >
                            <i class="fas fa-wallet"></i> {address}
                          </button>
                        </div>
                      );
                    })()}
                  </div>
                );
              }}
            </ConnectButton.Custom> */}
          </div>
        )}

        {/* end user details */}
      </div>

      {/**
       * * @desc image crop as required width and height
       */}
      <Modal className='cropModal' show={showModal} size='lg'>
        <Modal.Header>
          <Modal.Title>Crop Profile Image</Modal.Title>
          <Button
            className='modalCloseBtn'
            onClick={() => onHandleCloseModal("closeProfile")}
          >
            <i className='fal fa-times'></i>
          </Button>
        </Modal.Header>
        <Modal.Body>
          <FixedCropper
            ref={cropperRef}
            className='example__cropper'
            backgroundClassName='example__cropper-background'
            src={CropImageURL}
            stencilSize={{
              width: 400,
              height: 400,
            }}
            stencilProps={{
              handlers: false,
              lines: false,
              movable: true,
              resizable: true,
            }}
            imageRestriction={ImageRestriction.stencil}
            stencilComponent={CircleStencil}
            //aspectRatio={2 / 1}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button
            className='posRelative'
            letiant='primary'
            onClick={() => onHandleImageCrop("profileImg")}
          >
            Crop Image
          </Button>
        </Modal.Footer>
      </Modal>

      {/**
       * * @desc banner image crop popup
       */}
      <Modal className='cropModal' show={showBannerModal} size='lg'>
        <Modal.Header>
          <Modal.Title>Crop Banner Image</Modal.Title>
          <Button
            className='modalCloseBtn'
            onClick={() => onHandleCloseModal("closeBanner")}
          >
            <i className='fal fa-times'></i>
          </Button>
        </Modal.Header>
        <Modal.Body>
          <FixedCropper
            ref={cropperRef}
            className='example__cropper'
            backgroundClassName='example__cropper-background'
            src={CropBannerImageURL}
            stencilSize={{
              width: 870,
              height: 350,
            }}
            stencilProps={{
              handlers: false,
              lines: false,
              movable: true,
              resizable: true,
            }}
            imageRestriction={ImageRestriction.stencil}
            //aspectRatio={2 / 1}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button
            className='posRelative'
            letiant='primary'
            onClick={() => onHandleImageCrop("bannerImg")}
          >
            Crop Image
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
