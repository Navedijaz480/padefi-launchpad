import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useRouter } from "next/router";


//redux
import UsersThunkAPI from "../../store/features/users/middleware";

//utils
import * as sweetAlert from "../../utils/sweetAlert";

const WalleteConnectorButton = () => {
  const dispatch = useDispatch();
  const router = useRouter();

  //  login with wallete address
  const onloginSignupWithWallet = async (wallet_address) => {
    let payload = {
      wallet_address: wallet_address,
      wallet_signup: true,
    };

    dispatch(
      UsersThunkAPI.loginSignupWithWallet({
        payload,
        callback: (res) => {
          if (res.status == 1) {
            sweetAlert.successAlert(res?.message);
            router.push("/user/profile");
          }
        },
      })
    );
  };

  // wallet connect login
  useEffect(() => {
    if (isConnected) {
      //   console.log("address : ", address);
      onloginSignupWithWallet(address);
      // wallet verify
      // api call and store wallet address
    } else {
      //   console.log("not connected");
    }
  }, [isConnected]);
  return (
    <ConnectButton.Custom>
      {({
        account,
        chain,
        openAccountModal,
        openChainModal,
        openConnectModal,
        authenticationStatus,
        mounted,
      }) => {
        // Note: If your app doesn't use authentication, you
        // can remove all 'authenticationStatus' checks
        const ready = mounted && authenticationStatus !== "loading";
        const connected =
          ready &&
          account &&
          chain &&
          (!authenticationStatus || authenticationStatus === "authenticated");

        return (
          <div
            className={
              isConnected
                ? "walletButtonMain w100"
                : "walletButtonMain w100 onlyConnectWalletBtn d-flex justify-content-center"
            }
            {...(!ready && {
              "aria-hidden": true,
              style: {
                opacity: 0,
                pointerEvents: "none",
                userSelect: "none",
              },
            })}
          >
            {(() => {
              if (!connected) {
                return (
                  <button
                    className="createAccountBtn connectWalletBtn"
                    onClick={openConnectModal}
                    type="button"
                  >
                    Wallet Connector
                  </button>
                );
              }

              return (
                <div className="d-flex justify-content-between walletButton">
                  <button
                    className="curPointer walletName walletFormButton mr14"
                    onClick={openChainModal}
                    type="button"
                  >
                    {chain.name}
                  </button>
                </div>
              );
            })()}
          </div>
        );
      }}
    </ConnectButton.Custom>
  );
};

export default WalleteConnectorButton;
