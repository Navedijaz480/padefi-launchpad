import { ethers } from "ethers";
import { infuraId } from "../../../utils/config";
async function ethereumMainnet() {
  try {
     // request to metamask
    let hex_chainId = ethers.utils.hexValue(1) ;
    await window.ethereum.request({
      method: "wallet_addEthereumChain",
      params: [
        {
          chainId: hex_chainId, // 1
          rpcUrls: ["https://rpc.ankr.com/eth"],
          chainName: "Ethereum Mainnet",
          nativeCurrency: {
            name: "ETH",
            symbol: "ETH",
            decimals: 18,
          },
          blockExplorerUrls: ["https://etherscan.io"],
        },
      ],
    });
  } catch (error) {
    console.log(error);
  }
}
async function bscMainnet() {

  // request to metamask
  await window.ethereum.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: "0x38", // 56
        rpcUrls: ["https://bsc-dataseed2.defibit.io"],
        chainName: "Smart Chain",
        nativeCurrency: {
          name: "BNB",
          symbol: "BNB",
          decimals: 18,
        },
        blockExplorerUrls: ["https://bscscan.com"],
      },
    ],
  });
}
async function bscTestnet() {
   // request to metamask
  await window.ethereum.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: "0x61", // 97
        rpcUrls: ["https://data-seed-prebsc-2-s2.binance.org:8545"],
        chainName: "BSC Testnet",
        nativeCurrency: {
          name: "BNB",
          symbol: "BNB",
          decimals: 18,
        },
        blockExplorerUrls: ["https://explorer.binance.org/smart-testnet"],
      },
    ],
  });
}
async function polygonMainnet() {
   // request to metamask
  await window.ethereum.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: "0x89", // 137
        rpcUrls: ["https://polygon-rpc.com"],
        chainName: "Polygon Mainnet",
        nativeCurrency: {
          name: "MATIC",
          symbol: "MATIC",
          decimals: 18,
        },
        blockExplorerUrls: ["https://polygonscan.com/"],
      },
    ],
  });
}
async function fantomMainnet() {
  await window.ethereum.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: "0xFA", // 250
        rpcUrls: ["https://rpc.ftm.tools/"],
        chainName: "Fantom",
        nativeCurrency: {
          name: "FTM",
          symbol: "FTM",
          decimals: 18,
        },
        blockExplorerUrls: ["https://ftmscan.com/"],
      },
    ],
  });
}

async function goerliTestnet() {
  var hex_chainId = ethers.utils.hexValue(5) ;
  await window.ethereum.request({
    method: "wallet_addEthereumChain",
    params: [
      {
        chainId: hex_chainId, // 5
        rpcUrls: ["https://goerli.infura.io/v3/"],
        chainName: "Goerli test network",
        nativeCurrency: {
          name: "GoerliETH",
          symbol: "GoerliETH",
          decimals: 18,
        },
        blockExplorerUrls: ["https://goerli.etherscan.io/"],
      },
    ],
  });
}

export { ethereumMainnet, bscMainnet, bscTestnet, polygonMainnet, fantomMainnet, goerliTestnet };
