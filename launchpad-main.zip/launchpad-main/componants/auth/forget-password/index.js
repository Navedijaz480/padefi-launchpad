import React, { useState, useEffect, useRef } from "react";
import Loader from "../../common/Loader";
import validator from "validator";
import * as sweetAlert from "../../../utils/sweetAlert";
import usersService from "../../../services/users.service";

export default function Forget(props) {
  const { setForgetModal } = props;
  const [userDetails, setUserDetails] = useState({ forgetPassword: "" });
  const [validateError, setValidateError] = useState({ forgetPassword: null });
  const onHandleUserInfo = (event, label) => {
    const { value } = event.target;
    switch (label) {
      case "forgetPassword":
        setUserDetails({ ...userDetails, forgetPassword: value.trim() });
        break;
      case "forgetPassErr":
        if (value.length < 3) {
          setValidateError({
            ...validateError,
            forgetPassword: "Please enter email",
          });
        } else if (!validator.isEmail(value)) {
          setValidateError({
            ...validateError,
            forgetPassword: "Please enter correct email",
          });
        } else {
          setValidateError({ ...validateError, forgetPassword: null });
        }
        break;
      default:
        setUserDetails({ forgetPassword: "" });
        setValidateError({ forgetPassword: null });
        break;
    }
  };
  const forgetPassCheck = Boolean(userDetails?.forgetPassword);
  const forgetPassError = Boolean(validateError.forgetPassword);

  const forgetPassword = async (event) => {
    event.preventDefault();
    try {
      if (forgetPassCheck && !forgetPassError) {
        let payload = {
          mail: userDetails.forgetPassword.toLowerCase(),
        };
        const response = await usersService.forgetPassword(payload);
        if (response.status) {
          sweetAlert.successAlert("Please check your email");
          setForgetModal(false);
        } else {
          sweetAlert.errorAlert(response.message);
        }
      } else {
        console.log("Error");
      }
    } catch (error) {
      const { name, message } = error;
      // console.log(`${name}=>${message}`);
    }
  };
  return (
    <div>
      <form>
        <div className="forgetPassword">
          <div className="form-group">
            <h5>
              Enter your details below to request your account password reset.
            </h5>
            <label>Email</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter Email "
              value={userDetails.forgetPassword}
              onChange={(e) => onHandleUserInfo(e, "forgetPassword")}
              onBlur={(e) => onHandleUserInfo(e, "forgetPassErr")}
            />
            <div>
              <h6 style={{ color: "#d34747" }}>
                {validateError.forgetPassword}
              </h6>
            </div>
          </div>

          <button
            className={
              ((!userDetails?.forgetPassword || forgetPassError) &&
                "createAccountBtn2 cursor-no-drop mb-4") ||
              " createAccountBtn mb-4"
            }
            type="button"
            disabled={!userDetails?.forgetPassword || forgetPassError}
            onClick={forgetPassword}
          >
            Send
          </button>

          <button
            className="forgerPassBtn"
            type="button"
            style={{
              // textDecorationLine: "underline",
              border: "none",
              color: "blue",
            }}
            onClick={props.goSignIn}
          >
            Remember my account password ? Sign in
          </button>
        </div>
      </form>
    </div>
  );
}
