import React, { useEffect, useState } from "react";
import Image from "next/future/image";

//redux
import { useDispatch } from "react-redux";
import { useRouter } from "next/router";
import { setUserWalletInfo } from "store/features/users/usersSlice";

//bootstrap
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

// componants
import Spinner from "componants/common/Spinner";

import ethCoinImg from "../../../static/images/eth.svg";
import bnbCoinImg from "../../../static/images/bnb.svg";
import maticCoinImg from "../../../static/images/matic.svg";

// blockchain
import { ethers } from "ethers";

import {
  checkNetworkID,
  signMessage,
  isConnected,
} from "../wallet/walletConnectAuth";

import {
  ethereumMainnet,
  bscMainnet,
  bscTestnet,
  polygonMainnet,
  fantomMainnet,
} from "../wallet/walletNetworks";

//redux
import UsersThunkAPI from "../../../store/features/users/middleware";

// import * as sweetAlert from "../../utils/sweetAlert";

const CustomWalletConnector = (props) => {
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();

  const {
    showNetworkChainOptionas,
    onShowNetworkChainOptionas,
    onHideNetworkChainOptionas,
    onBack,
  } = props;

  // const [showNetworkChainOptionas, setShowConnetWalleteModal] = useState(false);
  // const onShowNetworkChainOptionas = () => {
  //   setShowConnetWalleteModal(true);
  //   if (props.onOpenWalleteConnectOptions) props.onOpenWalleteConnectOptions();
  // };
  // const onHideNetworkChainOptionas = () => {
  //   setShowConnetWalleteModal(false);
  //   if (props.onOpenWalleteConnectOptions) props.onCloseWalleteConnectOptions();
  // };
  //blockchain

  //  login with wallete address
  // const onloginSignupWithWallet = async (wallet_address) => {
  //   let payload = {
  //     wallet_address: wallet_address,
  //     wallet_signup: true,
  //   };

  //   dispatch(
  //     UsersThunkAPI.loginSignupWithWallet({
  //       payload,
  //       callback: (res) => {
  //         if (res.status == 1) {
  //           sweetAlert.successAlert(res?.message);
  //           router.push("/user/profile");
  //         }
  //       },
  //     })
  //   );
  // };

  // // wallet connect login
  // useEffect(() => {
  //   if (isConnected) {
  //     //   console.log("address : ", address);
  //     // onloginSignupWithWallet(address);
  //     // wallet verify
  //     // api call and store wallet address
  //   } else {
  //     //   console.log("not connected");
  //   }
  // }, [isConnected]);

  const onConnect = (data) => {
    // if (!data.signHash) return;
    
    //set or update user wallet info in redux and local storage
    dispatch(setUserWalletInfo(data));
    props.onConnect(data);
  };

  const getCurrentNetwork = async () => {
    const provider = new ethers.providers.Web3Provider(ethereum);
    const network = await provider.getNetwork();
    return network;
  };

  const onWalletConnect = async (id) => {
    setIsLoading(true);
    const network_id = await checkNetworkID();
    switch (id) {
      // ethereum
      case 1:
        if (network_id != id) {
          try {
            await ethereumMainnet();
            // const signHash = await signMessage();
            const walletAddress = await isConnected();
            // console.log("walletAddress is eath: ", walletAddress);
            // console.log("sign is eath: ", signHash);
            const network = await  getCurrentNetwork();

            // console.log("Network name=", network.name);
            // console.log("Network chain id=", network.chainId);
            setIsLoading(false);

            onConnect({
              network,
              walletAddress,
              // signHash,
            });
            // wallet address and sign message pass to API
          } catch (error) {
            setIsLoading(false);
          }
        } else {
          // const signHash = await signMessage();
          const walletAddress = await isConnected();
          const network = await getCurrentNetwork();
          // console.log("walletAddress is bscM2: ", walletAddress);
          // console.log("sign is bscM2: ", signHash);
          setIsLoading(false);

          onConnect({
            network,
            walletAddress,
            // signHash,
          });
        }
        break;

      // BSC Mainnet
      case 56:
        if (network_id != id) {
          try {
            await bscMainnet();
            // const signHash = await signMessage();
            const walletAddress = await isConnected();
            const network = await getCurrentNetwork();
            // console.log("Network chain id=", network.chainId);
            // console.log("sign is bscM: ", signHash);
            setIsLoading(false);

            onConnect({
              network,
              walletAddress,
              // signHash,
            });
            // wallet address and sign message pass to API
          } catch (error) {
            setIsLoading(false);
          }
        } else {
          // const signHash = await signMessage();
          const walletAddress = await isConnected();
          // console.log("walletAddress is bscM2: ", walletAddress);
          const network = await getCurrentNetwork();
          // console.log("sign is bscM2: ", signHash);
          setIsLoading(false);

          onConnect({
            network,
            walletAddress,
            // signHash,
          });
        }
        break;

      // BSC Testnet
      case 97:
        if (network_id != id) {
          try {
            await bscTestnet();
            // const signHash = await signMessage();
            const walletAddress = await isConnected();
            // console.log("walletAddress is bscT: ", walletAddress);
            // console.log("sign is bscT: ", signHash);
            // wallet address and sign message pass to API
            const network = await getCurrentNetwork();
            setIsLoading(false);

            onConnect({
              network,
              walletAddress,
              // signHash,
            });
          } catch (error) {
            setIsLoading(false);
          }
        } else {
          // const signHash = await signMessage();
          const walletAddress = await isConnected();
          // console.log("walletAddress is bscT2: ", walletAddress);
          // console.log("sign is bscT2: ", signHash);
          const network = await getCurrentNetwork();
          setIsLoading(false);

          onConnect({
            network,
            walletAddress,
            // signHash,
          });
        }
        break;

      // Polygon Mainnet
      case 137:
        if (network_id != id) {
          try {
            await polygonMainnet();
            // const signHash = await signMessage();
            const walletAddress = await isConnected();
            // console.log("walletAddress is poly: ", walletAddress);
            // console.log("sign is poly: ", signHash);
            const network = await getCurrentNetwork();
            setIsLoading(false);

            onConnect({
              network,
              walletAddress,
              // signHash,
            });
            // wallet address and sign message pass to API
          } catch (error) {
            setIsLoading(false);
          }
        } else {
          // const signHash = await signMessage();
          const walletAddress = await isConnected();
          // console.log("walletAddress is poly: ", walletAddress);
          // console.log("sign is poly: ", signHash);
          const network = await getCurrentNetwork();
          setIsLoading(false);

          onConnect({
            network,
            walletAddress,
            // signHash,
          });
        }
        break;
      // Fantom Mainnet
      case 250:
        if (network_id != id) {
          try {
            await fantomMainnet();
            // const signHash = await signMessage();
            const walletAddress = await isConnected();
            // console.log("walletAddress is poly: ", walletAddress);
            // console.log("sign is poly: ", signHash);
            const network = await getCurrentNetwork();
            setIsLoading(false);

            onConnect({
              network,
              walletAddress,
              // signHash,
            });
            // wallet address and sign message pass to API
          } catch (error) {
            setIsLoading(false);
          }
        } else {
          // const signHash = await signMessage();
          const walletAddress = await isConnected();
          // console.log("walletAddress is poly: ", walletAddress);
          // console.log("sign is poly: ", signHash);
          const network = await getCurrentNetwork();
          setIsLoading(false);

          onConnect({
            network,
            walletAddress,
            // signHash,
          });
        }
        break;
      default:
        // const signHash = await signMessage();
        const walletAddress = await isConnected();
        // console.log("walletAddress is poly2: ", walletAddress);
        // console.log("sign is poly2: ", signHash);
        const network = await getCurrentNetwork();
        setIsLoading(false);

        onConnect({
          network,
          walletAddress,
          // signHash,
        });
    }
  };

  let getOptions = () => {
    return (
      <>
        {/* {onBack && <span onClick={() => onBack()}>Back kk</span>} */}
        <div className="BodayHeadTitle font20 fontBold">
          <button
            onClick={() => {
              onBack();
            }}
          >
            <i class="far fa-arrow-left"></i>
          </button>
          Choose network
        </div>
        <div className="allSelectCoinBox position-relative">
          {isLoading && (
            <Spinner
            // className="spinner-border text-light spinner-border-sm"
            />
          )}

          <div className="row">
            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Button
                  className="CoinSelectBox"
                  onClick={() => onWalletConnect(1)}
                >
                  <Image alt="" src={ethCoinImg} /> ETH-ERC20
                </Button>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Button
                  className="CoinSelectBox"
                  onClick={() => onWalletConnect(56)}
                >
                  <Image alt="" src={bnbCoinImg} /> BSC-EEP20
                </Button>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Button
                  className="CoinSelectBox"
                  onClick={() => onWalletConnect(97)}
                >
                  <Image alt="" src={bnbCoinImg} /> BSC Testnet-EEP20
                </Button>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Button
                  className="CoinSelectBox"
                  onClick={() => onWalletConnect(137)}
                >
                  <Image alt="" src={maticCoinImg} /> Polygon-ERC20
                </Button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  return (
    <>
      {props?.isPopup ? (
        <Modal
          // className="coinSelectionPopup"
          className="signUpPop connectNetworkPopUp"
          animation={false}
          show={showNetworkChainOptionas}
          onHide={onHideNetworkChainOptionas}
        >
          {/* <Modal.Header closeButton>
            <Modal.Title className="font20">Choose network</Modal.Title>
          </Modal.Header> */}
          <Modal.Body>{getOptions()}</Modal.Body>
        </Modal>
      ) : (
        showNetworkChainOptionas && getOptions()
      )}
    </>
  );
};

export default CustomWalletConnector;
