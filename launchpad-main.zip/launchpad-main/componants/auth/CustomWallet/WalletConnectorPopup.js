import React, { useState } from "react";
import { useRouter } from "next/router";
//bootstrap
import Modal from "react-bootstrap/Modal";

// blockchain
import { ethers } from "ethers";
import ConnectWalletConnect from "./ConnectWalletConnect";
import ConnectCoinbaseWallet from "./ConnectCoinbaseWallet";
import ConnectTrustWallet from "./ConnectTrustWallet/ConnectTrustWallet";
import ConnectMetaMaskWallet from "./ConnectMetaMaskWallet";
import { Web3ReactProvider } from "@web3-react/core";

//redux
import { useDispatch } from "react-redux";
import { setUserWalletInfo } from "store/features/users/usersSlice";

const CustomWalletConnector = (props) => {
  const [isLoading, setIsLoading] = useState(false);
  const [test, setTest] = useState(false);

  const dispatch = useDispatch();
  const router = useRouter();

  const {
    showConnetWalleteOptionas,
    onShowConnetWalleteModal,
    onHideConnetWalleteOptions,
    onBack,
    isDisableSignatureRequest,
    networksListToCheck,
    isForMultiNetworkCheck,
    contractAddress,
  } = props;

  const onConnect = (data) => {
    // if (!data.signHash) return;
    //set user wallete and nwtwork info
    //set or update user wallet info in redux and local storage
    dispatch(setUserWalletInfo(data));
    //login
    props.onConnect(data);
  };

  function getLibrary(provider) {
    return new ethers.providers.Web3Provider(provider);
  }

  const onHandleSetIsLoading = (val) => {
    // setIsLoading(val);
  };

  const getOptions = () => {
    return (
      <>
        <div className="BodayHeadTitle font20 fontBold">
          <button
            onClick={() => {
              onBack();
            }}
          >
            <i class="far fa-arrow-left"></i>
          </button>
          Connect wallet
        </div>
        <div className="allSelectCoinBox position-relative">
          <div className="row">
            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <ConnectMetaMaskWallet
                  onConnect={onConnect}
                  isLoading={isLoading}
                  setIsLoading={onHandleSetIsLoading}
                  isDisableSignatureRequest={isDisableSignatureRequest}
                  //multi network for check contract address
                  networksListToCheck={networksListToCheck}
                  isForMultiNetworkCheck={isForMultiNetworkCheck}
      
                  contractAddress={contractAddress}
                />
              </div>
            </div>

            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Web3ReactProvider getLibrary={getLibrary}>
                  <div className="App">
                    <ConnectWalletConnect
                      onConnect={onConnect}
                      isLoading={isLoading}
                      setIsLoading={onHandleSetIsLoading}
                      isDisableSignatureRequest={isDisableSignatureRequest}
                      //multi network for check contract address
                      networksListToCheck={networksListToCheck}
                      isForMultiNetworkCheck={isForMultiNetworkCheck}
          
                      contractAddress={contractAddress}
                    />
                  </div>
                </Web3ReactProvider>
              </div>
            </div>

            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <ConnectTrustWallet
                  onConnect={onConnect}
                  isLoading={isLoading}
                  setIsLoading={onHandleSetIsLoading}
                  isDisableSignatureRequest={isDisableSignatureRequest}
                  //multi network for check contract address
                  networksListToCheck={networksListToCheck}
                  isForMultiNetworkCheck={isForMultiNetworkCheck}
      
                  contractAddress={contractAddress}
                />
              </div>
            </div>

            <div className="col-sm-12 col-md-6 col-lg-6">
              <div className="allSelectCoinBoxBTN">
                <Web3ReactProvider getLibrary={getLibrary}>
                  <div className="App">
                    <ConnectCoinbaseWallet
                      onConnect={onConnect}
                      isLoading={isLoading}
                      setIsLoading={onHandleSetIsLoading}
                      isDisableSignatureRequest={isDisableSignatureRequest}
                      //multi network for check contract address
                      networksListToCheck={networksListToCheck}
                      isForMultiNetworkCheck={isForMultiNetworkCheck}
          
                      contractAddress={contractAddress}
                    />
                  </div>
                </Web3ReactProvider>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };
  return (
    <>
      {props?.isPopup ? (
        <Modal
          // className="coinSelectionPopup"
          className="signUpPop connectNetworkPopUp"
          animation={false}
          show={showConnetWalleteOptionas}
          onHide={onHideConnetWalleteOptions}
        >
          {/* <Modal.Header closeButton>
            <Modal.Title className="font20">Choose network</Modal.Title>
          </Modal.Header> */}
          <Modal.Body>{getOptions()}</Modal.Body>
        </Modal>
      ) : (
        showConnetWalleteOptionas && getOptions()
      )}
    </>
  );
};

export default CustomWalletConnector;

{
  /**  how to use
   * 
  import WalletConnectorPopup from "componants/auth/CustomWallet/WalletConnectorPopup";

  const [showConnetWalleteOptionas, setShowConnetWalleteOptions] =
    useState(false);
  const onShowConnetWalleteModal = () => {
    setShowConnetWalleteOptions(true);
  };
  const onHideConnetWalleteOptions = () => {
    setShowConnetWalleteOptions(false);
  };

  <WalletConnectorPopup
    onConnect={(data) => {}}
    isPopup={false}
    showConnetWalleteOptionas={showConnetWalleteOptionas}
    onHideConnetWalleteOptions={onHideConnetWalleteOptions}
    onBack={() => {}}
  />;

**/
}
