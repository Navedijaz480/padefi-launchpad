import React from "react";

/**
 * @desc Social media
 * @param {Object} props
 * @param {String} props.label
 * @param {String} props.value
 * @param {String} props.id
 * @param {String} props.name
 * @param {String} props.minLength
 * @param {String} props.maxLength
 * @param {String} props.placeholder
 * @param {String} props.type
 * @param {Function} props.onHandleChange
 * @author Amol Aher
 * @returns
 */
export default function SocialMediaLuanchpad(props) {
  const {
    label,
    value,
    id,
    name,
    placeholder,
    type,
    onHandleChange,
    minLength,
    maxLength,
  } = props;
  return (
    <div className="socialMainBox">
      <div className="websiteTitleBox">{label}</div>
      <div className="websiteNameBox">
        <div className="form-group">
          <input
            type={type}
            id={id}
            name={name}
            minLength={minLength}
            maxLength={maxLength}
            className="form-control"
            placeholder={placeholder}
            value={value}
            onChange={onHandleChange}
          />
        </div>
      </div>
    </div>
  );
}
