import React from "react";
import Image from "next/future/image";

const LogoPreviewBox = (props) => {
  const { title, name, symbolName, imageUrl } = props;
  return (
    <div className="tokenSummeryBox">
      <h2 className="fontBold">{title}</h2>
      <div className="tokenLogoSectionmain">
        <div className="tokenLogoSection">
          <div className="tokenLogoImg">
            {imageUrl && (
              <Image
                src={imageUrl}
                alt=""
                width={64}
                height={64}
                style={{ borderRadius: "50%" }}
              />
            )}
          </div>
          <div className="tokenLogoContentName">
            <div className="tokenLogoContentNameHead font16">{name}</div>
            <div className="tokenLogoContentNameTxt">{symbolName}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogoPreviewBox;
