export default function RadioGroup(props) {
  return (
    <div className={props?.parantClassName}>
      <h2 className="font16 fontBold">
        {props?.label}
        {props?.info && (
          <span className="informationSpan posRelative">
            <i className="far fa-info-circle"></i>
            <span className="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
              {props?.info}
            </span>
          </span>
        )}
      </h2>
      {props?.subtitle && (
        <h3 className="colorGrey font14">which users can pay you with</h3>
      )}
      <div className="radio-btns">
        <div className="row">
          {props.options &&
            props.options.map((item, index) => (
              <div className={props?.className} key={index}>
                <div className="radio-btn">
                  <input
                    type={props?.type}
                    onChange={props?.onChange}
                    name={props?.name}
                    id={item?.id}
                    defaultValue={item?.defaultValue}
                    defaultChecked={item?.checked}
                  />
                  <label htmlFor={item?.id}>{item?.optionLabel}</label>
                  <div className="check"></div>
                </div>
              </div>
            ))}
        </div>
        <span className="text-danger err">{props?.err}</span>
      </div>

      <p className="sml-below-txt">{props?.description}</p>
    </div>
  );
}

// // How to use
{
  /* <RadioGroup
  type="radio"
  parantClassName =  "chooseTokenChain"
  className="col-sm-6 col-md-6 col-lg-6"
  label="Choose your token Chain"
  description={
    data?.network_name
      ? "Your token will be build on " +
        data?.network_name +
        " smart chain network"
      : ""
  }
  err={error?.message || data?.errors?.network_name}
  onChange={handleChange}
  info={info_msg?.network_name}
  name="network_name"
  options={[
    {
      id: "ETH",
      optionLabel: "ETH",
      defaultValue: "ETH",
      checked: data?.network_name == "ETH",
    },
    {
      id: "BNB",
      optionLabel: "Bep 20",
      defaultValue: "BNB",
      checked: data?.network_name == "BNB",
    },
  ]}
/> */
}
