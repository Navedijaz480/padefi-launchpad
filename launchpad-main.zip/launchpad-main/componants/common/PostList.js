import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/router";
import moment from "moment";
import InfiniteScroll from "react-infinite-scroll-component";
import Image from "next/future/image";
import sweplyLogo from "../../static/images/sweplyLogo.svg";
import CommentBox from "./CommentBox";
import tokenThunkAPI from "../../store/features/token/middleware";
import { clearAllStatus } from "../../store/features/token/tokenSlice";

import ViewPostDetails from "./ViewPostModal";
import Loader from "./Loader";
import SectionLoader from "./SectionLoader";
//aurh
import { getAuthToken } from "services/authToken.service";

function PostList(props) {
  let router = useRouter();
  const dispatch = useDispatch();
  const [likePost, setLikePost] = useState(false);
  const [profileLogo, setProfileLogo] = useState("");
  const [disLikePost, setDisLikePost] = useState(false);
  const [likeCount, setLikeCount] = useState(1);
  const [disLikeCount, setDisLikeCount] = useState(1);
  const [commentBox, setCommentBox] = useState(false);
  const [postData, setPostData] = useState();
  const [postId, setPostId] = useState("");

  // token post like/unlike
  const tokenPostLikeUnlikeFunction = (postid, action) => {
    try {
      let payload = {
        post_id: postid,
      };
      if (!getAuthToken()) {
        router.push(`/token/${props.tokenids}?forLoginIn=true`);
        return;
      }
      if (action == "like") {
        setLikeCount(likeCount + 1);
        setLikePost(true);
      } else {
        setLikeCount(likeCount - 1);
        setLikePost(false);
      }

      dispatch(props.likeUnlikeFunction(payload));
    } catch (error) {
      console.log("error", error);
    }
  };

  // token post like/unlike
  const addDislikeFunction = (postid, action) => {
    try {
      let payload = {
        post_id: postid,
      };
      if (!getAuthToken()) {
        router.push(`/token/${props.tokenids}?forLoginIn=true`);
        return;
      }
      if (action == "adddislike") {
        setDisLikeCount(disLikeCount + 1);
        setDisLikePost(true);
      } else {
        setDisLikeCount(disLikeCount - 1);
        setDisLikePost(false);
      }
      dispatch(props.dislikeFunction(payload));
    } catch (error) {
      console.log("error", error);
    }
  };
  const { status, likeStatus, createStatus } = useSelector(
    (state) => state.tokenState
  );
  const handleClose = (e) => {
    let payload = {
      token_id: props.tokenids,
    };
    dispatch(tokenThunkAPI.getTokenPostListAsync(payload));
    setCommentBox(false);
    // dispatch(clearAllStatus());
  };
  useEffect(() => {
    if (createStatus == "true") {
      setPostId("");
      let payload = {
        token_id: props.tokenids,
      };
      dispatch(tokenThunkAPI.getTokenPostListAsync(payload));
      dispatch(clearAllStatus());
    }
  }, [createStatus]);

  return (
    <>
      {props.loader ? (
        <SectionLoader />
      ) : (
        <>
          {props?.posts == undefined || props?.posts?.length == 0 ? (
            <div className='discussionCommentBox'>
              <div className='commentDoneBox'>
                <div className='commentAddedBox'>No Data Found....</div>
              </div>
            </div>
          ) : (
            <div
              className='listAllmsgBox'
              // ref={props?.posts?.length == 5 ? props.lastElementRef : null}
            >
              {/* <InfiniteScroll
                dataLength={props?.posts?.length}
                next={props.fetchMoreData}
                hasMore={props.hasmore}
                loader={<h4>Loading...</h4>}
                height={600}
              > */}
              {props.posts.map((el, i) => {
                return (
                  <div
                    className='discussionCommentBox'
                    key={i}

                    // ref={userFollowers.length == i + 5 ? lastElementRef : null}
                  >
                    <div className='commentDoneBox'>
                      <div className='commentAddedBox'>
                        <Image
                          alt=''
                          style={{ borderRadius: "50%" }}
                          src={
                            el?.creator?.user_profile_image?.url || sweplyLogo
                          }
                          width={50}
                          height={50}
                        />
                        <div className='commenterBox'>
                          <h6>
                            {el?.creator?.name}{" "}
                            <span className='font12 colorGrey'>
                              {moment(el.updated_at).fromNow(true)}
                            </span>
                          </h6>
                          <p className='colorGrey'>@{el?.creator?.username}</p>
                        </div>
                        {/* <div className='commenterBox'>
                          <h6> </h6>
                        </div> */}
                      </div>
                      <p
                        className='commentText backIconHeading'
                        onClick={(e) => {
                          setCommentBox(!commentBox);
                          setPostId(el._id);
                          setPostData(el);
                        }}
                      >
                        {el?.postData || "N/A"}
                        {/* <span>Read all</span> */}
                      </p>
                      <div className='commentLikeBtnBox colorGrey'>
                        <span>
                          {el?.isLiked ? (
                            <i
                              className='fa fa-solid fa-thumbs-up backIconHeading'
                              style={{ color: "#FF5D47" }}
                              onClick={(e) => {
                                tokenPostLikeUnlikeFunction(el?._id, "unlike");
                              }}
                            ></i>
                          ) : (
                            <i
                              className='fal fa-thumbs-up backIconHeading'
                              onClick={(e) => {
                                tokenPostLikeUnlikeFunction(el?._id, "like");
                              }}
                            ></i>
                          )}
                          {el?.like || "0"}
                        </span>
                        <span>
                          {el?.isDisliked ? (
                            <i
                              className='fa fa-solid fa-thumbs-down backIconHeading'
                              style={{ color: "#FF5D47" }}
                              onClick={(e) => {
                                addDislikeFunction(el?._id, "removedislike");
                              }}
                            ></i>
                          ) : (
                            <i
                              className='fal fa-thumbs-down backIconHeading'
                              onClick={(e) => {
                                addDislikeFunction(el?._id, "adddislike");
                              }}
                            ></i>
                          )}
                          {el?.dislike || "0"}
                        </span>
                        <span>
                          <i
                            className='fal fa-comment-alt backIconHeading'
                            onClick={(e) => {
                              if (!getAuthToken()) {
                                router.push(
                                  `/token/${props.tokenids}?forLoginIn=true`
                                );
                                return;
                              }
                              setCommentBox(!commentBox);
                              setPostId(el._id);
                              setPostData(el);
                            }}
                          ></i>
                          {el?.comment || "0"}
                        </span>

                        <span>
                          <i className='far fa-ellipsis-v backIconHeading'></i>
                        </span>
                      </div>
                      {/* {commentBox && postId == el._id && (
                    <CommentBox
                      postid={el._id}
                      submitComment={tokenThunkAPI.createTokenPostsCommentAsync}
                    />
                  )} */}
                      {/* <div className='replayCommentBox'>
    <div className='commentAddedBox'>
      <Image alt='' src={sweplyLogo} />
      <div className='commenterBox'>
        <h6>cnaw78w</h6>
        <p className='colorGrey'>@cnaw78w</p>
      </div>
    </div>
    <p className='commentText colorGrey'>
      Hello my name is sweply ansd thnis is my token and here we can
      work together to be able to compent the matters so our utlities
      are ready to launch within 2 years
    </p>
  </div> */}
                    </div>
                  </div>
                );
              })}
              {/* </InfiniteScroll> */}
            </div>
          )}
        </>
      )}

      <ViewPostDetails
        postId={postId}
        postData={postData}
        commentBox={commentBox}
        setCommentBox={setCommentBox}
        handleClose={handleClose}
        addDislikeFunction={addDislikeFunction}
        tokenPostLikeUnlikeFunction={tokenPostLikeUnlikeFunction}
      />
    </>
  );
}

export default PostList;
