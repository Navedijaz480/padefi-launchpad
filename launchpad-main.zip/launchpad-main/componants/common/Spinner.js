import React from "react";

const Spinner = (props) => {
  const { className } = props;
  return (
    <>
      <div className={className} role="status" />
      <div className={"loader-parant-spinner"} />
    </>
  );
};

export default Spinner;

// .loader-parant-spinner {position: absolute;right: 0;left: 0;z-index: 999;top: 0;background-color: rgba(0, 0, 0, 0.9);bottom: 0;display: flex;align-items: center;justify-content: center;}
