import React from "react";

function Swap(props) {
  const { tokenAdd } = props;

  return (
    // <div className='col-lg-7 col-md-7 col-sm-12'>
    //   <div className='becomeOwnerImgBox'>
    //     {/* <Image src={becomeOwnerImg} alt="" /> */}
    //     <div className='swapSection'>
    <iframe
      src={`https://app.uniswap.org/#/swap?use=v1?exactField=inputCurrency=${
        tokenAdd != "" ? tokenAdd : "ETH"
      }&outputCurrency=0xce041D2D752af9FC570252a33Af1391c474ab37d&theme=dark`}
      // src='https://app.uniswap.org/#/swap?inputCurrency=0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0'
      height='501px'
      width='100%'
      style={{
        border: 0,
        margin: "auto",
        display: "block",
        borderRadius: "10px",
        maxWidth: "600px",
        minWidth: "300px",
        backgroundColor: "black",
      }}
      id='myId'
    />
    //     </div>
    //   </div>
    // </div>
  );
}

export default Swap;
