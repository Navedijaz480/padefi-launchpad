import React, { useState } from "react";
export default function SummeryBox(props) {
  const {
    heading,
    containerclassName,
    headingclassName,
    rowclassName,
    labelTxtclassName,
    valueTxtclassName,
    data,
  } = props;

  return (
    <div className={containerclassName}>
      <h2 className={headingclassName}>{heading} </h2>

      {data && Array.isArray(data) && data.length > 0
        ? data?.map((row, row_index) => (
            <div className={rowclassName} key={row_index}>
              <h3
                className={`${labelTxtclassName} ${
                  row.lableCellClassName || ""
                }`}
              >
                {row?.label}
              </h3>
              <h4
                className={
                  row?.value && row?.value !== "-"
                    ? `${valueTxtclassName} ${row.valueCellClassName || ""}`
                    : `${row.valueTxtclassName || ""}`
                }
              >
                {row?.value}
              </h4>

              {row?.value2 && (
                <h4 className={valueTxtclassName}>{row?.value2}</h4>
              )}
            </div>
          ))
        : "No data"}
    </div>
  );
}

// // //  How to use
// <SummeryBox
//   heading="Token summery"
//   containerclassName="tokenSummeryBox"
//   headingclassName="fontBold"
//   rowclassName="networkBox"
//   labelTxtclassName="font16"
//   valueTxtclassName="font16"
//   data={[
//     { label: "Network", value: "12" },
//     { label: "Token Type", value: "12" },
//     {
//       label: "Token Name",
//       value: "12",
//       lableCellClassName: "",
//       valueCellClassName: "colorBlue",
//     },
//     {
//       label: "Token Symbol",
//       value: "12",
//       lableCellClassName: "",
//       valueCellClassName: "colorBlue",
//     },
//     { label: "Decimals", value: "12" },
//     {
//       label: "Total supply",
//       value: "12",
//       lableCellClassName: "",
//       valueCellClassName: "colorBlue fontBold",
//     },
//   ]}
// />;
