import React from "react";
import Head from "next/head";

export default function MetaTags({
  metaKeywords,
  metaDescription,
  ogType,
  ogTitle,
  ogDescription,
  ogImageUrl,
  ogImageUrlType,
  ogImageWidth,
  ogImageHeight,
}) {
  return (
    <Head>
      <meta charSet='utf-8' />
      <meta name='viewport' content='width=device-width' />
      <meta name='Keywords' content={metaKeywords || "Padefi"} />
      <meta name='Description' content={metaDescription} />
      {ogType && <meta property='og:type' content={ogType} />}
      {ogTitle && <meta property='og:title' content={ogTitle} />}
      {ogDescription && (
        <meta property='og:description' content={ogDescription} />
      )}
      {ogImageUrl && <meta property='og:image' content={ogImageUrl} />}
      {ogImageUrlType && (
        <meta property='og:image:type' content={ogImageUrlType} />
      )}
      {ogImageWidth && (
        <meta property='og:image:width' content={ogImageWidth} />
      )}
      {ogImageHeight && (
        <meta property='og:image:height' content={ogImageHeight}></meta>
      )}
    </Head>
  );
}
