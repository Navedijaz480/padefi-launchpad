import React, { useRef, useState, useEffect } from "react";
import moment from "moment";

const TimerComponant = (props) => {
  const Ref = useRef(null);
  const { start_date, end_date, parantClassName } = props;

  const [ShowDate, setShowDate] = useState("");
  const [showDateObj, setShowDateObj] = useState({
    days: "00",
    hours: "00",
    minutes: "00",
    seconds: "00",
  });

  const [ShowDateStatus, setShowDateStatus] = useState("");

  useEffect(() => {
    const startMoment = moment(start_date).format("MM/DD/YYYY hh:mm:ss");
    const endMoment = moment(end_date).format("MM/DD/YYYY hh:mm:ss");
    const now = new Date();
    const currentMoment = moment(now).format("MM/DD/YYYY hh:mm:ss");

    if (startMoment >= currentMoment) {
      const futureDate = new Date(startMoment).getTime();
      setShowDateStatus(`Sale end in ${startMoment} start ${currentMoment}`);
      setShowDateStatus("Sale start in");
      CountDownTimer(futureDate);
    } else if (endMoment > startMoment) {
      if (currentMoment >= endMoment) {
        setShowDateStatus("Sale ended");
        return;
      }
      const futureDate = new Date(endMoment).getTime();
      CountDownTimer(futureDate);
      setShowDateStatus("Sale end in");
    } else if (currentMoment >= endMoment) {
      setShowDateStatus("Sale ended");
    }
  }, []);

  function CountDownTimer(dt) {
    const end = new Date(dt);

    const _second = 1000;
    const _minute = _second * 60;
    const _hour = _minute * 60;
    const _day = _hour * 24;
    let timer;

    function showRemaining() {
      const now = new Date();
      const distance = end - now;
      if (distance < 0) {
        clearInterval(timer);
        return;
      }
      const days = Math.floor(distance / _day);
      const hours = Math.floor((distance % _day) / _hour);
      const minutes = Math.floor((distance % _hour) / _minute);
      const seconds = Math.floor((distance % _minute) / _second);
      setShowDate(days + ": " + hours + ": " + minutes + ": " + seconds);
      setShowDateObj({
        days: days,
        hours: hours,
        minutes: minutes,
        seconds: seconds,
      });
    }
    timer = setInterval(showRemaining, 1000);
  }
  return (
    <div className={parantClassName}>
      {" "}
      {/* <span className="show-date-str">{ShowDate}</span> */}
      <span className="timer-item days">{showDateObj?.days} <span className="colorGrey fontNormal">D</span> </span>
      <span className="timer-item hours">{showDateObj?.hours} <span className="colorGrey fontNormal">H</span></span>
      <span className="timer-item minutes">{showDateObj?.minutes} <span className="colorGrey fontNormal">M</span></span>
      <span className="timer-item seconds">{showDateObj?.seconds} <span className="colorGrey fontNormal">S</span></span>
    </div>
  );
};

export default TimerComponant;
