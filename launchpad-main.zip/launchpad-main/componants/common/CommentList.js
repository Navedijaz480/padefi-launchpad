import React from "react";
import Image from "next/future/image";
import moment from "moment";

import sweplyLogo from "../../static/images/sweplyLogo.svg";

function CommentList(props) {
  return (
    <div className='allCoomentBoxPopup'>
      <h2 className='font20 fontBold'>
        Comments <span>({props.tokenSinglePostData?.totalComment || "0"})</span>
      </h2>
      {props.tokenSinglePostData?.commentdata?.length > 0 ? (
        props.tokenSinglePostData?.commentdata?.map((el, i) => {
          return (
            <div className='discussionCommentBox' key={i}>
              <div className='commentDoneBox'>
                <div className='commentAddedBox'>
                  <Image
                    style={{ borderRadius: "50%" }}
                    alt=''
                    src={el?.commentUser?.user_profile_image?.url || sweplyLogo}
                    width={50}
                    height={50}
                  />
                  <div className='commenterBox'>
                    <h6>
                      {el?.commentUser?.name}{" "}
                      <span className='font12 colorGrey'>
                        {moment(el?.created_at).fromNow(true)}
                      </span>
                    </h6>{" "}
                    <p className='colorGrey'>@ {el?.commentUser?.username}</p>
                  </div>
                </div>
                <p className='commentText '>{el?.comment || "N/A"}</p>
              </div>
            </div>
          );
        })
      ) : (
        <p className='commentText '>No comments found....</p>
      )}
      {}
    </div>
  );
}

export default CommentList;
