import React from "react";

const ButtonCustom = (props) => {
  const { onClick, className, id, isLoading, disabled, style, children } =
    props;

  return (
    <button
      type='button'
      className={`cursor-pointer ${className}`}
      id={id}
      onClick={(e) => {
        if (isLoading || disabled) return;
        onClick(e);
      }}
      style={style}
      disabled={disabled}
    >
      {isLoading ? (
        <>
          {" "}
          <span
            className='spinner-border spinner-border-sm me-2'
            role='status'
            aria-hidden='true'
          ></span>{" "}
          Please wait
        </>
      ) : (
        children
      )}
    </button>
  );
};

export default ButtonCustom;

{
  /**
How to use
    <ButtonCustom
        className="createAccountBtn2 cursor-no-drop"
        type="button"
        style={
            {
                // textDecorationLine: "underline",
                // border: "none",
                // color: "blue",
            }
        }
        onClick={() => {
        console.log("click event");
        }}
        isLoading={false}
        disabled={false}
    >
        Login
    </ButtonCustom>

*/
}
