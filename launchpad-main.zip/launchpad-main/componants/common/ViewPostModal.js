import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import moment from "moment";

import tokenThunkAPI from "../../store/features/token/middleware";
import { clearAllStatus } from "../../store/features/token/tokenSlice";

import Link from "next/link";
import sweplyLogo from "../../static/images/sweplyLogo.svg";

//bootstap
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Image from "next/future/image";
import PostList from "./PostList";
import CommentBox from "./CommentBox";
import CommentList from "./CommentList";
import SectionLoader from "./SectionLoader";

// import advanceCreate from "../../../static/images/advance-create.svg";

const ViewPostDetails = (props) => {
  const dispatch = useDispatch();

  const {
    postId,
    postData,
    setCommentBox,
    commentBox,
    handleClose,
    addDislikeFunction,
    tokenPostLikeUnlikeFunction,
  } = props;

  const [likePost, setLikePost] = useState(false);
  const [disLikePost, setDisLikePost] = useState(false);
  const [likeCount, setLikeCount] = useState(1);
  const [disLikeCount, setDisLikeCount] = useState(1);
  const [commentBoxToggle, setCommentBoxToggle] = useState(true);
  const [commentCount, setCommentCount] = useState();
  const [loader, setLoader] = useState(true);
  const [commentLoader, setCommentLoader] = useState(false);

  const { tokenSinglePostData, createStatus, status } = useSelector(
    (state) => state.tokenState
  );

  console.log(tokenSinglePostData, "tokenSinglePostData");

  useEffect(() => {
    let payload = {
      post_id: postId ? postId : tokenSinglePostData?.post?._id,
    };
    dispatch(tokenThunkAPI.getSingleTokenPostAsync(payload));
  }, [commentBox]);

  useEffect(() => {
    if (tokenSinglePostData != null) {
      setLoader(false);
      setCommentLoader(false);
    }
  }, [status]);

  useEffect(() => {
    setCommentCount(tokenSinglePostData?.totalComment);
  }, [tokenSinglePostData]);

  useEffect(() => {
    if (createStatus == "true") {
      setCommentLoader(false);
      let payload = {
        post_id: postId ? postId : tokenSinglePostData?.post?._id,
      };
      dispatch(clearAllStatus());
      dispatch(tokenThunkAPI.getSingleTokenPostAsync(payload));

      // setCommentBoxToggle(false);
    }
  }, [createStatus]);

  return (
    <>
      <Modal
        className='methodSelectPop postPopup'
        show={commentBox}
        onHide={handleClose}
      >
        <Modal.Header>
          <Modal.Title className='font20'>Post detail</Modal.Title>
          <button
            onClick={handleClose}
            type='button'
            className='close'
            data-dismiss='modal'
            aria-label='Close'
          >
            <span aria-hidden='true'>&times;</span>
          </button>
        </Modal.Header>
        <Modal.Body>
          <>
            {loader ? (
              <SectionLoader />
            ) : (
              <div className='discussionCommentBox'>
                <div className='commentDoneBox'>
                  <div className='commentAddedBox'>
                    <Image
                      alt=''
                      style={{ borderRadius: "50%" }}
                      src={
                        tokenSinglePostData?.creator?.user_profile_image?.url ||
                        sweplyLogo
                      }
                      width={50}
                      height={50}
                    />
                    <div className='commenterBox'>
                      <h6>
                        {tokenSinglePostData?.creator?.name || "N/A"}{" "}
                        <span className='font12 colorGrey'>
                          {moment(
                            tokenSinglePostData?.post?.updated_at
                          ).fromNow(true)}
                        </span>
                      </h6>
                      <p className='colorGrey'>
                        @{tokenSinglePostData?.creator?.username || "N/A"}{" "}
                      </p>
                    </div>
                  </div>
                  <p className='commentText'>
                    {tokenSinglePostData?.post?.postData || "N/A"}
                  </p>
                  <div className='commentLikeBtnBox colorGrey'>
                    <span>
                      {tokenSinglePostData?.isLiked ? (
                        <i
                          className='fa fa-solid fa-thumbs-up backIconHeading'
                          style={{ color: "#FF5D47" }}
                          onClick={(e) => {
                            tokenPostLikeUnlikeFunction(
                              tokenSinglePostData?.post?._id,
                              "unlike"
                            );
                          }}
                        ></i>
                      ) : (
                        <i
                          className='fal fa-thumbs-up backIconHeading'
                          onClick={(e) => {
                            tokenPostLikeUnlikeFunction(
                              tokenSinglePostData?.post?._id,
                              "like"
                            );
                          }}
                        ></i>
                      )}
                      {tokenSinglePostData?.post?.like || "0"}
                    </span>
                    <span>
                      {tokenSinglePostData?.isdisLiked ? (
                        <i
                          className='fa fa-solid fa-thumbs-down backIconHeading'
                          style={{ color: "#FF5D47" }}
                          onClick={(e) => {
                            addDislikeFunction(
                              tokenSinglePostData?.post?._id,
                              "removedislike"
                            );
                          }}
                        ></i>
                      ) : (
                        <i
                          className='fal fa-thumbs-down backIconHeading'
                          onClick={(e) => {
                            addDislikeFunction(
                              tokenSinglePostData?.post?._id,
                              "adddislike"
                            );
                          }}
                        ></i>
                      )}
                      {tokenSinglePostData?.post?.dislike || "0"}
                    </span>
                    <span>
                      <i
                        className='fal fa-comment-alt backIconHeading'
                        onClick={(e) => {
                          // props.setCommentBox(!props.commentBox);
                          setCommentBoxToggle(!commentBoxToggle);
                        }}
                      ></i>
                      {tokenSinglePostData?.totalComment || "0"}
                    </span>

                    <span>
                      <i className='far fa-ellipsis-v backIconHeading'></i>
                    </span>
                  </div>
                  {commentBoxToggle && (
                    <CommentBox
                      postData={postData}
                      submitComment={tokenThunkAPI.createTokenPostsCommentAsync}
                      tokenSinglePostData={
                        tokenSinglePostData ? tokenSinglePostData : {}
                      }
                      setCommentCount={setCommentCount}
                      setCommentLoader={setCommentLoader}
                      commentCount={commentCount}
                      setLoader={setLoader}
                    />
                  )}
                  {!tokenSinglePostData ? (
                    <SectionLoader />
                  ) : (
                    <CommentList tokenSinglePostData={tokenSinglePostData} />
                  )}

                  {/* <div className='replayCommentBox'>
            <div className='commentAddedBox'>
              <Image alt='' src={sweplyLogo} />
              <div className='commenterBox'>
                <h6>cnaw78w</h6>
                <p className='colorGrey'>@cnaw78w</p>
              </div>
            </div>
            <p className='commentText colorGrey'>
              Hello my name is sweply ansd thnis is my token and here we can
              work together to be able to compent the matters so our utlities
              are ready to launch within 2 years
            </p>
          </div> */}
                </div>
              </div>
            )}
          </>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default ViewPostDetails;
