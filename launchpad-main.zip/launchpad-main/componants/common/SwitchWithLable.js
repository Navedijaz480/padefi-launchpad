export default function SwitchWithLable(props) {
  const {
    parantClassName,
    lableBoxClassName,
    className,
    lable,
    info,
    description,
    name,
    type,
    role,
    id,
    onChange,
    checked,
    lableDescription,
    lableDescriptionClassName,
  } = props;
  return (
    <div className={parantClassName}>
      <div className={lableBoxClassName}>
        <h3>
          {lable}{" "}
          {props?.info && (
            <span class="informationSpan posRelative">
              <i className="far fa-info-circle"></i>
              <span class="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
                {props?.info}
              </span>
            </span>
          )}{" "}
          {lableDescription && (
            <span className={lableDescriptionClassName}>
              {lableDescription}
            </span>
          )}
        </h3>
        {description && <p> {description}</p>}
      </div>
      <div className={className}>
        <label className="switch">
          <input
            name={name}
            className={className}
            type={"checkbox"}
            role={role}
            id={id}
            onChange={onChange}
            checked={checked}
          />
          <span className="slider round"></span>
        </label>
      </div>
    </div>
  );
}
