import index from "pages/pool-invested-list";
import React, { useState } from "react";
export default function SummeryBox2(props) {
  const {
    heading,
    containerclassName,
    headingclassName,
    tableHead,
    tableRows,
  } = props;

  const getText = (col) => {
    if (col == "0" || col == 0) return "0";
    else if (!col) return "-";
    else return col;
  };
  return (
    <div className={containerclassName}>
      <h2 className={headingclassName}>{heading}</h2>
      <table className="table table-dark">
        <thead>
          <tr>
            {tableHead &&
              tableHead.map((item, index) => <th key={index}>{item}</th>)}
          </tr>
        </thead>
        <tbody>
          {tableRows &&
            tableRows.map((row, row_index) => (
              <tr key={row_index}>
                {row &&
                  row.map((col, col_index) => (
                    <td
                      key={col_index}
                      className={
                        col_index > 0 && row[0]?.toLowerCase().includes("total")
                          ? "fontBold"
                          : ""
                      }
                    >
                      {getText(col)}
                    </td>
                  ))}
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

// // How to use

// <SummeryBox2
//   heading="Tokenomics Details (Standard)"
//   containerclassName="tokenSummeryBox"
//   headingclassName="font20 fontBold"
//   rowclassName="networkBox"
//   labelTxtclassName="font16"
//   valueTxtclassName="font16"
//   tableHead={["Details", "BUY %", "SELL %"]}
//   tableRows={[
//     ["Marketing", taxData?.marketing_fee.buy, taxData?.marketing_fee.sell],
//     ["Developer", taxData?.developer_fee.buy, taxData?.developer_fee.sell],
//     ["Liquidity Fee", taxData?.liquidity_fee.buy, taxData?.liquidity_fee.sell],
//     [
//       "Holders reward",
//       taxData?.holders_reward.buy,
//       taxData?.holders_reward.sell,
//     ],
//     // ["Total Taxes", taxData?.marketing_fee.buy,  taxData?.marketing_fee.sell],
//   ]}
// />
