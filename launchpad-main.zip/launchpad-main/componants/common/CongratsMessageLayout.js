import React from "react";
import Image from "next/image";
import token_success from "static/images/token-success-icon.svg";

const CongratsMessageLayout = (props) => {
  const { children, message, description } = props;
  return (
    <div className="instantcongratsMain">
      <div className="instantcongratsInner">
        <div className="text-center">
          <Image src={token_success} alt="" />
        </div>
        {message && (
          <div className="instantcongratsHead text-center">{message}</div>
        )}
        {description && (
          <div className="instantcongratsSemihead text-center">
            {description}
          </div>
        )}

        {children && children}
      </div>
    </div>
  );
};

export default CongratsMessageLayout;
