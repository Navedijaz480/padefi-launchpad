import React, { useState, useRef, useEffect } from "react";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css";

const QuillNoSSRWrapper = dynamic(import("react-quill"), {
  ssr: false,
  loading: () => <p>Loading ...</p>,
});

const modules = {
  toolbar: [
    [{ header: "1" }, { header: "2" }, { font: [] }],
    [{ size: [] }],
    ["bold", "italic", "underline", "strike", "blockquote"],
    [
      { list: "ordered" },
      { list: "bullet" },
      { indent: "-1" },
      { indent: "+1" },
    ],
    // ['link'],
    // ['clean'],
  ],
  clipboard: {
    // toggle to add extra line breaks when pasting HTML:
    matchVisual: true,
  },
};
/*
 * Quill editor formats
 * See https://quilljs.com/docs/formats/
 */
const formats = [
  "header",
  "font",
  "size",
  "bold",
  "italic",
  "underline",
  "strike",
  "blockquote",
  "list",
  "bullet",
  "indent",
  "link",
  "image",
  "video",
];

export default function CustomEditor(props) {
  const [value, setValue] = useState("");
  useEffect(() => {
    if (props.value) {
      setValue(props.value);
    }
  }, [props.value]);

  const keyDown = (e) => {
    let valuetext = e.target.innerText;
    if (
      props.length &&
      valuetext.length >= props.length &&
      e.key !== "Backspace"
    ) {
      e.preventDefault();
    }
  };

  const changeEditor = (values) => {
    let valuetext = values.replace(/<[^>]*>?/gm, "");

    if (
      (props.length && parseInt(valuetext.length) <= props.length) ||
      !props.length
    ) {
      setValue(values);
      props.onChange(values);
    }
  };

  return (
    <QuillNoSSRWrapper
    className  = {props?.className}
      modules={modules}
      formats={formats}
      theme="snow"
      length={250}
      value={value}
      onKeyDown={(e) => keyDown(e)}
      onChange={(e) => changeEditor(e)}
    />
  );
}
