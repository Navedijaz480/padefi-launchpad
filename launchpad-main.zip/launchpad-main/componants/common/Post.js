import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/router";
import TextareaAutosize from "react-textarea-autosize";

//aurh
import { getAuthToken } from "services/authToken.service";
import Image from "next/future/image";
import sweplyLogo from "../../static/images/sweplyLogo.svg";
import sendImg from "../../static/images/send.png";
import FormButton from "./FormButton";

function Post(props) {
  const dispatch = useDispatch();
  const router = useRouter();

  const [post, setPost] = useState("");
  const [togglePostLable, setTogglePostLable] = useState(false);
  const [postErrMSg, setPostErrMSg] = useState("");

  //collect post data
  const handlePost = (e) => {
    if (e.target.value.length > 300) {
      setPostErrMSg("Max limit is 300 characters");
      return false;
    }
    setPostErrMSg("");
    setPost(e.target.value);
  };

  //submit post data
  const submitPostData = (e) => {
    e.preventDefault();
    let err;
    if (!getAuthToken()) {
      router.push(`/token/${props.tokenId}?forLoginIn=true`);
      return;
    }
    if (post == "") {
      err = true;
      setPostErrMSg("Please enter some text");
    } else {
      setPostErrMSg("");
    }
    if (err) {
      return false;
    }
    props.setLoader(true);
    setTogglePostLable(true);
    let payload = {
      token_id: props.tokenId,
      postData: post,
    };
    // props.setLoader(true);
    dispatch(props.submitPost(payload));
    setPost("");
  };

  return (
    <>
      <form onSubmit={(e) => submitPostData(e)}>
        <div className='commentInputSection'>
          <Image
            alt=''
            src={
              props.user != null
                ? props.user?.user_profile_image?.url
                : sweplyLogo
            }
            width={50}
            height={50}
            style={{ borderRadius: "50%" }}
          />
          {/* <textarea
            class='form-control bgDarkGrey'
            rows='5'
            id='comment'
            name='post'
            value={post}
            onChange={(e) => handlePost(e)}
          ></textarea> */}
          <TextareaAutosize
            class='form-control bgDarkGrey'
            id='comment'
            name='post'
            minRows={2}
            cols={70}
            value={post}
            onChange={(e) => handlePost(e)}
            maxRows={400}
          />
        </div>
        {postErrMSg != "" && (
          <span className='text-danger' style={{ marginLeft: "48px" }}>
            {postErrMSg}
          </span>
        )}

        <button className='postBtn' type='submit'>
          <span>
            <Image alt='' src={sendImg} />
          </span>
          Post
        </button>
      </form>
    </>
  );
}

export default Post;
