import React from "react";

const ToolTip = (props) => {
  return (
    <span className="informationSpan posRelative">
      <i className="far fa-info-circle"></i>
      <span className="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
        {props?.text}
      </span>
    </span>
  );
};

export default ToolTip;
