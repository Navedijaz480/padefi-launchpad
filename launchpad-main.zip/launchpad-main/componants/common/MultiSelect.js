import React from "react";
import Select from "react-select";

function MultiSelect(props) {
  return (
    <div className='favoriteGameDrop'>
      <div className='form-group'>
        <Select
          name={props.name}
          value={props.value || ""}
          onChange={props.onChange}
          options={props.options}
          isMulti={props.isMulti}
          closeMenuOnSelect={props.closeMenuOnSelect}
          // menuIsOpen="true"
        />
        <div className='text-danger mt-1'>{props.err}</div>
      </div>
    </div>
  );
}

export default MultiSelect;
