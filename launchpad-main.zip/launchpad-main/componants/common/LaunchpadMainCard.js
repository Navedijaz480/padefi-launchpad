import { nanoid } from "@reduxjs/toolkit";
import React from "react";
import LaunchpadCard from "./LaunchpadCard";
import Video from "./Video";
import {video_url} from "utils/config"
export default function LaunchpadMainCard(props) {
  const { dataArr, url, page, tokenName, tokenSymbol, tokendata } = props;
  return (
    <div className='tokenPreviewBox'>
      {dataArr.map((el) => (
        <LaunchpadCard
          header={el?.header}
          data={el?.data}
          key={nanoid()}
          url={url ?? ""}
          tokenName={tokenName || ""}
          tokenSymbol={tokenSymbol || ""}
          tokendata={tokendata || []}
        />
      ))}
      <Video
        id={"instant-step-1-video"}
        parantClassName='videoBox'
        className=''
        width='100%'
        height='100%'
        src={
          video_url
        }
        controls={true}
        autoPlay={true}
        loop={true}
        muted={true}
        videoTitle={"Create token easily now"}
        videoSubTitle={"A quick tutorial from our experts to create a token."}
      />
      {page == "token-page" && (
        <div className='expertTipsMain'>
          <div className='expertTipsHead mb8'>Expert tips | Description</div>
          <div className='expertTipsDesc'>
            When starting with Token description, make headlines and keep it
            simple and direct will make it easier to get liked
          </div>
        </div>
      )}
    </div>
  );
}
