export default function CustomButton(props) {
  const { lable, onClick, className, id, isLoading, disabled } = props;

  if (isLoading) {
    return (
      <a className={className} id={id}>
        <span
          className='spinner-border spinner-border-sm me-2'
          role='status'
          aria-hidden='true'
        ></span>{" "}
        Please wait
      </a>
    );
  } else if (disabled) {
    return (
      <a
        className={`cursor-no-drop disabled-btn ${className}`}
        id={id}
        // onClick={onClick}
      >
        {lable}
      </a>
    );
  } else
    return (
      <a className={`cursor-pointer ${className}`} id={id} onClick={onClick}>
        {lable}
      </a>
    );
}

// //How to use
// <CustomButton
//   lable={"Submit"}
//   onClick={()=>{}}
//   className="nextBtn"
//   isLoading={true}
// />;
