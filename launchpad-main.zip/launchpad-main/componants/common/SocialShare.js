import React from "react";
import Image from "next/future/image";

import {
  FacebookShareButton,
  TwitterShareButton,
  LinkedinShareButton,
} from "react-share";
import copy from "copy-to-clipboard";
import { successAlert } from "utils/sweetAlert";

//icons

import twitterIcon from "static/images/twittericon.svg";
import telegramIcon from "static/images/telegramicon.svg";
import facebookIcon from "static/images/facebookicon.svg";
import chainIcon from "../../static/images/chainicon.svg";

import smallArrow from "static/images/smallarrow.svg";

const SocialShare = (props) => {
  const {
    parantClassName,
    toggleShareMenu,
    setToggleShareMenu,
    url_for_facebook,
    url_for_twitter,
    url_for_linkedin,
    url_for_copy,
  } = props;
  const copyToClipboardBusiness = () => {
    copy(url_for_copy);
    successAlert("Copied");
  };
  return (
    <span
      className={
        parantClassName ? `${parantClassName} cursor-pointer` : `cursor-pointer`
      }
      onClick={setToggleShareMenu}
    >
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M2 17L2.621 19.485C2.72915 19.9177 2.97882 20.3018 3.33033 20.5763C3.68184 20.8508 4.11501 20.9999 4.561 21H19.439C19.885 20.9999 20.3182 20.8508 20.6697 20.5763C21.0212 20.3018 21.2708 19.9177 21.379 19.485L22 17M12 3V15V3ZM12 3L8 7L12 3ZM12 3L16 7L12 3Z"
          stroke="#8B93A3"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
      {toggleShareMenu && (
        <div
          className="dropDownMenu dropdown-menu postMenuDrop show businessShareDropSection shareDropBox"
          aria-labelledby="dropdownMenuButton"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="dropTryIcon" />
          <ul>
            <li className="mb20">
              <div className="">
                <FacebookShareButton
                  onClick={(e) => {
                    setToggleShareMenu();
                    e.stopPropagation();
                  }}
                  url={url_for_facebook}
                >
                  <a className="d-flex align-items-center contentColorGray curPointer contentColorGray font13 ">
                    <div className="userMenuIcon bgLightGray d-flex align-items-center justify-content-center">
                      <Image src={facebookIcon} alt="" height={20} width={20} />
                    </div>
                    Facebook
                  </a>
                </FacebookShareButton>
              </div>
            </li>
            <li className="mb20">
              <div className="">
                <TwitterShareButton
                  onClick={(e) => {
                    setToggleShareMenu();
                    e.stopPropagation();
                  }}
                  url={url_for_twitter}
                >
                  <a className="d-flex align-items-center contentColorGray curPointer contentColorGray font13">
                    <div className="userMenuIcon bgLightGray d-flex align-items-center justify-content-center">
                      <Image src={twitterIcon} alt="" height={20} width={20} />
                    </div>
                    Twitter
                  </a>
                </TwitterShareButton>
              </div>
            </li>
            <li className="mb20">
              <div className="">
                <LinkedinShareButton
                  onClick={(e) => {
                    setToggleShareMenu();
                    e.stopPropagation();
                  }}
                  url={url_for_linkedin}
                >
                  <a className="d-flex align-items-center contentColorGray curPointer contentColorGray font13">
                    <div className="userMenuIcon bgLightGray d-flex align-items-center justify-content-center">
                      <Image src={chainIcon} alt="" height={20} width={20} />
                    </div>
                    Linkedin
                  </a>
                </LinkedinShareButton>
              </div>
            </li>
            <li>
              <div
                className=""
                onClick={(e) => {
                  setToggleShareMenu();
                  e.stopPropagation();
                  copyToClipboardBusiness();
                }}
              >
                <a className="d-flex align-items-center contentColorGray curPointer contentColorGray font13">
                  <div className="userMenuIcon bgLightGray d-flex align-items-center justify-content-center">
                    <Image src={chainIcon} alt="" height={20} width={20} />
                  </div>
                  Copy Link
                </a>
              </div>
            </li>
          </ul>
        </div>
      )}
    </span>
  );
};

export default SocialShare;
