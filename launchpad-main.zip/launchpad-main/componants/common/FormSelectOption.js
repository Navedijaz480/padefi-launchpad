import React from "react";
import { nanoid } from "@reduxjs/toolkit";

/**
 * @desc form select option common use
 * @param { Object } props
 * @param { String } props.name
 * @param { String } props.label
 * @param { String } props.subTitle
 * @param { String } props.info
 * @param { Array } props.options
 * @param { String } props.value
 * @param { String } props.err
 * @param { Function } props.onHandleChange
 * @returns JSX
 */
export default function FormSelectOption(props) {
  const {
    label,
    subTitle,
    info,
    name,
    options,
    onHandleChange,
    value,
    err,
    placeholder,
  } = props;
  return (
    <div className="col-sm-12 col-md-12 col-lg-12">
      <div className="form-group tokentypeGroup">
        <label htmlFor={props?.id} className="font16 fontBold">
          {label}
          {info && (
            <span className="informationSpan posRelative">
              <i className="far fa-info-circle"></i>
              <span className="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
                {info}
              </span>
            </span>
          )}
        </label>
        <p className="colorGrey">{subTitle}</p>
        <select name={name} onChange={onHandleChange} value={value}>
          <option value="" disabled>
            {placeholder}
          </option>
          {(options instanceof Array &&
            options.map((el) => (
              <option
                defaultValue={el.defaultValue}
                key={nanoid()}
                //selected={el.selected}
              >
                {el.name}
              </option>
            ))) || <option disabled>No options</option>}
        </select>
        <i class="far fa-angle-down droparrowicon"></i>
        <span className="text-danger err">{err}</span>
      </div>
    </div>
  );
}

/*
How to use component for common use

<FormSelectOption
    label="Router type"
    info={infoMsg?.router_type}
    subTitle="Choose the type of router platform to use"
    name="router_type"
    options={routerType}
    value={stepTwoData?.router_type}
    onHandleChange={onHandleUserInput}
    err={stepTwoError?.router_type}
    />
*/
