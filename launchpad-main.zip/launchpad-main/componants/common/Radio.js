export default function Radio(props) {
  return (
    <div className={props?.parantClassName}>
      <label className="form-check-label" htmlFor={props?.id}>
        {props?.label}
      </label>
      <input
        className={props?.className}
        type={props?.type}
        name={props?.name}
        id={props?.id}
        defaultValue={props?.defaultValue}
        onChange={props?.onChange}
        checked={props?.checked}
      />
    </div>
  );
}
