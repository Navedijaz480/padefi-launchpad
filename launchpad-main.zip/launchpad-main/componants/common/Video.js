export default function Video(props) {
  return (
    <div className={props?.parantClassName}>
      {props?.videoTitle && (
        <h2 className='font16 fontBold '>{props?.videoTitle}</h2>
      )}

      {props?.videoSubTitle && (
        <p className='colorGrey'>{props?.videoSubTitle}</p>
      )}
      <video
        id={props?.id}
        className={props?.className}
        width={props?.width}
        height={props?.height}
        src={props?.src}
        controls={props?.controls}
        autoPlay={props?.autoPlay}
        loop={props?.loop}
        muted={props?.muted}
      />
    </div>
  );
}

// //How to use
// <Video
//   id={"instant-step-1-video"}
//   parantClassName="videoBox"
//   className=""
//   width="100%"
//   height="100%"
//   src={
//   }
//   controls={true}
//   autoPlay={true}
//   loop={true}
//   muted={true}
//   videoTitle={"Create token easily now"}
//   videoSubTitle={"A quick tutorial from our experts to create a token."}
// />;
