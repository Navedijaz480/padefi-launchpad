import React from "react";

/**
 * @desc form input checkbox component
 * @param {Object} props
 * @returns
 */
export default function FormCheckBox(props) {
  const { type, name, value, checked, label, id, onHandleChange, info } = props;
  return (
    <div className='check-box'>
      <input
        id={id}
        className='filled-in'
        type={type}
        checked={checked}
        name={name}
        value={value}
        onChange={onHandleChange}
      />
      <label htmlFor={id}>{label}</label>

      {info && (
        <span className="informationSpan posRelative">
          <i className="far fa-info-circle"></i>
          <span className="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
            {info}
          </span>
        </span>
      )}
    </div>
  );
}
