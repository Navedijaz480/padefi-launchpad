import { nanoid } from "@reduxjs/toolkit";
import React from "react";
import Image from "next/future/image";
import sweplyLogo from "../../static/images/sweplyLogo.svg";
export default function LaunchpadCard(props) {
  const { header, data, url, tokendata } = props;
  return (
    <>
      {(url && (
        <div className='tokenSummeryBox'>
          <h2 className='fontBold'>Token logo</h2>
          {tokendata?.length > 0 &&
            tokendata?.map((el, i) => {
              return (
                <div
                  className='tokenLogoSectionmain'
                  key={i}
                  style={{ marginBottom: "10px" }}
                >
                  <div className='tokenLogoSection'>
                    <div className='tokenLogoImg'>
                      <Image
                        src={url ?? sweplyLogo}
                        alt=''
                        width={64}
                        height={64}
                        style={{ borderRadius: "50%" }}
                      />
                    </div>
                    <div className='tokenLogoContentName'>
                      <div className='tokenLogoContentNameHead font16'>
                        {el?.name || "N/A"}
                      </div>
                      <div className='tokenLogoContentNameTxt'>
                        {el?.symbol || "N/A"}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      )) || (
        <div className='tokenSummeryBox'>
          <h2 className='fontBold'>{header}</h2>
          {data?.map((el) => (
            <div
              className={el?.rowClassName ? el?.rowClassName : "networkBox"}
              key={nanoid()}
            >
              <h3
                className={el?.labelClassName ? el?.labelClassName : "font16"}
              >
                {el?.label}
              </h3>
              <h4
                className={el?.valueClassName ? el?.valueClassName : "font16"}
              >
                {el?.value}

                {el?.subValue && (
                  <span className='subValue'>{" " + el?.subValue}</span>
                )}
              </h4>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
