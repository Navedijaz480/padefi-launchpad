import React from "react";

/**
 * @desc form button for common use
 * @param { Object } props
 * @param { String } props.label
 * @param { String } props.name
 * @param { String } props.className
 * @param { Function } props.onHandleClick
 * @param { Boolean } props.disabled
 * @param { Boolean } props.isLoading
 * @returns JSX
 */
export default function FormButton(props) {
  const {
    label,
    name,
    className,
    onHandleClick,
    disabled,
    isLoading,
    children,
  } = props;

  return (
    <button
      type="button"
      className={className}
      onClick={onHandleClick}
      name={name}
      style={{ cursor: ((isLoading || disabled) && "no-drop") || "pointer" }}
      disabled={isLoading || disabled}
    >
      {(isLoading && (
        <>
          <span
            className="spinner-border spinner-border-sm me-2"
            role="status"
            aria-hidden="true"
          ></span>
          Please wait
        </>
      )) || (
        <>
          {label} {children && children}
        </>
      )}
    </button>
  );
}

/*
How to use

 <FormButton
    className="tokenCreateBtnfrm fontBold"
    name="createToken"
    label="Create Token"
    disabled={false}
    isLoading={false}
    onHandleClick={onHandleSubmitLaunchpad}
  />

*/
