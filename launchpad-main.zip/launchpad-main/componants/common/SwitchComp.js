export default function SwitchComp(props) {
  return (
    <div className={props?.parantClassName}>
      <label className="form-check-label" htmlFor={props?.id}>
        {props?.label}
      </label>
      <label className="switch">
        <input
          name={props?.name}
          className={props?.className}
          type={props?.type}
          role={props?.role}
          id={props?.id}
          onChange={props.onChange}
          checked={props?.checked}
        />
        <span className="slider round" />
      </label>
    </div>
  );
}
