import React from "react";
import { NumericFormat } from "react-number-format";

export default function NumericFormatInput(props) {
  return (
    <div className={props?.parantclassName}>
      <div className="form-group">
        <label htmlFor={props?.id} className="form-label">
          {props?.label}
          {props?.info && (
            <span class="informationSpan posRelative">
              <i className="far fa-info-circle"></i>
              <span class="posAbsolute noteSection noteSectionTop p16 bgLightGray contentGrayColor">
                {props?.info}
              </span>
            </span>
          )}
        </label>

        <NumericFormat
          type={props?.type}
          value={props?.value}
          className={props?.className}
          id={props?.id}
          placeholder={props?.placeholder}
          onChange={props?.onChange}
          name={props?.name}
          disabled={props?.disabled}
          maxLength={props?.maxLength}
          onBlur={props?.onBlur}
          thousandSeparator=","
          decimalScale={0}
          allowNegative={false}
          // allowLeadingZeros={false}
        />
        {/* <div className="filed-description">
            info
         </div> */}
        <span className="text-danger err">{props?.err}</span>
      </div>
    </div>
  );
}

{
  //   <NumericFormatInput
  //     type="text"
  //     name="total_supply"
  //     parantclassName=""
  //     className="form-control"
  //     id="total_supply"
  //     placeholder="Ex : 100000000"
  //     label="Total Supply*"
  //     err={data?.errors?.total_supply}
  //     onChange={handleChange}
  //     // value={data?.total_supply}
  //     acceptOnly={"number"}
  //     maxLength={supplyLength}
  //     info={info_msg?.total_supply}
  //   />;
}

{
  /* <NumericFormat
          value=""
          allowLeadingZeros
          thousandSeparator=","
          name="total_supply"
          maxLength={supplyLength}
          className="form-control"
          onChange={handleChange}
  /> */
}
