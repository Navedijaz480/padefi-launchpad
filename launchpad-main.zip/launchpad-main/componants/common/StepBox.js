import React from "react";
import { nanoid } from "@reduxjs/toolkit";

/**
 * @desc Step box contain step active or completed
 * @param { Object } props
 * @param { Number } props.selected
 * @param { Array } props.steps
 * @returns JSX
 */
export default function StepBox(props) {
  const { selected, steps } = props;

  /**
   * @desc define active or completed class base on step
   * @param {*} step
   * @returns
   */
  const getClassName = (step) => {
    let cname = "mr16 ";
    cname +=
      (Number(selected) === Number(step) && "active") ||
      (Number(step) < Number(selected) && "complected-step");
    return cname;
  };
  return (
    <div className='stepMainSection '>
      <div className='stepBox'>
        <ul>
          {steps &&
            steps.map((item, index) => (
              <li className={getClassName(item?.step_no)} key={nanoid()}>
                <a className='font16'>
                  <span>
                    <i className='fas fa-check'></i>
                  </span>{" "}
                  {item?.label}
                </a>{" "}
              </li>
            ))}
        </ul>
      </div>
    </div>
  );
}
