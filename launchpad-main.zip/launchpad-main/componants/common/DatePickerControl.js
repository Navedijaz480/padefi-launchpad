import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const DatePickerControl = (props) => {
  const {
    name,
    className,
    selected,
    onChange,
    minDate,
    maxDate,
    dateFormat,
    autoComplete,
    showTimeSelect,
    placeholderText,
    disabled
  } = props;
  return (
    <DatePicker
      name={name}
      className={className}
      selected={selected}
      onChange={onChange}
      minDate={minDate}
      maxDate={maxDate}
      showTimeSelect = {showTimeSelect}
      dateFormat={dateFormat}
      autoComplete={autoComplete}
      placeholderText ={placeholderText}
      disabled ={ disabled}
    />
  );
};

export default DatePickerControl;
