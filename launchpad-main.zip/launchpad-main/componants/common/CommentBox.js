import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import Image from "next/future/image";
import sweplyLogo from "../../static/images/sweplyLogo.svg";
import sendImg from "../../static/images/send.png";
import TextareaAutosize from "react-textarea-autosize";

function Comment(props) {
  const dispatch = useDispatch();
  const {
    postData,
    tokenSinglePostData,
    setCommentCount,
    commentCount,
    setLoader,
  } = props;
  const [comment, setComment] = useState("");
  const [commentErrMSg, setCommentErrMSg] = useState("");

  const userState = useSelector((state) => state.users);
  const user = userState?.user || null;

  //collect comment data
  const handlePostComment = (e) => {
    if (e.target.value.length > 150) {
      setCommentErrMSg("Max limit is 150 characters");
      return false;
    }
    setCommentErrMSg("");
    setComment(e.target.value);
  };

  //submit post data
  const submitPostCommentData = (e) => {
    e.preventDefault();
    let err;
    if (comment == "") {
      err = true;
      setCommentErrMSg("Please enter some text");
    } else {
      setCommentErrMSg("");
    }
    if (err) {
      return false;
    }
    setCommentCount(commentCount + 1);
    // setLoader(true);
    props.setCommentLoader(true);
    let payload = {
      post_id: props?.postData?._id,
      comment: comment,
    };
    dispatch(props.submitComment(payload));
    setComment("");
  };

  return (
    <>
      <form onSubmit={(e) => submitPostCommentData(e)}>
        <div className='commentInputSection mesReplyPopBox'>
          <div className='commentAddedBox'>
            <Image
              alt=''
              src={user != null ? user?.user_profile_image?.url : sweplyLogo}
              width={50}
              height={50}
              style={{ borderRadius: "50%" }}
            />
            <div className='commenterBox'>
              <h6>{user != null ? user?.name : "N/A"}</h6>
              <p class='colorGrey'>@{user != null ? user?.username : "N/A"}</p>
            </div>
          </div>
          <div className='popTextAreaBx'>
            {/* <textarea
              class='form-control bgDarkGrey'
              rows='5'
              id='comment'
              name='comment'
              value={comment}
              onChange={(e) => handlePostComment(e)}
            ></textarea> */}

            <TextareaAutosize
              class='form-control bgDarkGrey'
              id='comment'
              name='comment'
              minRows={2}
              cols={70}
              value={comment}
              onChange={(e) => handlePostComment(e)}
              maxRows={400}
            />
          </div>
        </div>
        {commentErrMSg != "" && (
          <span className='text-danger' style={{ marginLeft: "48px" }}>
            {commentErrMSg}
          </span>
        )}
        <button className='postBtn' type='submit'>
          <span>
            {/* <Image alt='' src={sendImg} /> */}
            <i class='fas fa-paper-plane'></i>
          </span>
          Reply
        </button>
      </form>
    </>
  );
}

export default Comment;
