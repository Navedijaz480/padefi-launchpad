import React, { useState, useRef, useEffect } from "react";
import Image from "next/future/image";
import chainIcon from "../../static/images/chainicon.svg";
import uploadPdfIcon from "../../static/images/uploadpdficon.svg";
import MultiSelect from "componants/common/MultiSelect";
import Select from "react-select";
import validator from "validator";
import ButtonCustom from "componants/common/ButtonCustom";
import launchPadService from "services/launchPad.service";
import * as sweetAlert from "../../utils/sweetAlert";
import { useRouter } from "next/router";

const initialState = {
  token_id: null,
  token_addr: null,
  token_network: null,
  contract_addr: null,
  email: null,
  logo_uri: null,
  project_type: null,
  project_descricption: null,
  project_website: null,
  whitepaper: null,
  block_explore_link: null,
  source_code_link: null,
  status: null,
};
const initialError = {
  token_id: null,
  token_addr: null,
  token_network: null,
  contract_addr: null,
  email: null,
  logo_uri: null,
  project_type: null,
  project_descricption: null,
  project_website: null,
  whitepaper: null,
  block_explore_link: null,
  source_code_link: null,
  status: null,
};
//project type options-
let projectTypeOptions = [
  { label: "Marketing", value: "Marketing" },
  { label: "Gaming", value: "Gaming" },
];

//add social media link
const initialSocialMedia = [
  { value: "EtherScan", label: "EtherScan", isDisabled: false },
  { value: "BscScan", label: "BscScan", isDisabled: false },
];
export default function TokenSetting(props) {
  const {
    selectedTokenItem,
    tokenPageData,
    setTokenPageData,
    whitepaperUrl,
    setWhitePaperUrl,
    blockExplorerLinks,
    setBlockExplorerLinks,
    updateTokenPageData,
    isLoadingSubmit,
  } = props;
  let router = useRouter();
  const websites = selectedTokenItem?.project_website;
  const blockExploreLinks = selectedTokenItem?.block_explore_link;
  const sourceCodeLinks = selectedTokenItem?.source_code_link;

  //states
  const [tokenDetails, setTokenDetails] = useState(initialState);
  const [validateError, setValidateError] = useState(initialError);

  const [projectType, setProjectType] = useState();

  const [website, setWebsite] = useState([""]);
  const [websiteErr, setWebsiteErr] = useState([""]);
  const [socialMediaName, setSocialMediaName] = useState("");
  const [socialMediaMaster, setSocialMediaMaster] =
    useState(initialSocialMedia);

  const [blockExploreLink, setBlockExploreLink] = useState([""]);
  const [blockExploreLinkErr, setblockExploreLinkErr] = useState([""]);

  const [sourceCodeLink, setSourceCodeLink] = useState([""]);
  const [sourceCodeLinkErr, setSourceCodeLinkErr] = useState([""]);
  const [isPdfLoading, setIsPdfLoading] = useState(false);

  const [socialMediaNameError, setSocialMediaNameError] = useState([]);
  const [socialMediaLink, setSocialMediaLink] = useState("");
  const [socialMediaNumberError, setSocialMediaNumberError] = useState("");

  //add/edit project type
  const handleProjectType = (network) => {
    let arr = [];
    let arrName = [];
    network?.map((el) => {
      arr.push(el?.value);
      arrName.push(el?.label);
    });

    setTokenDetails(arrName.toString());
    tokenPageData.project_type = arrName;
    setProjectType(network);
  };

  // add remove website or edit website
  const handleChangeWebsite = (e, index) => {
    // let urlRegex =
    //   /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
    let temp_website = [...website];
    let temp_websiteErr = [...websiteErr];
    temp_website[index] = e.target.value;
    if (!validator.isURL(e.target.value))
      temp_websiteErr[index] = "Enter valid URL";
    else temp_websiteErr[index] = "";
    setWebsiteErr(temp_websiteErr);
    setWebsite(temp_website);
    tokenPageData.project_website = temp_website;
  };
  const addWebsiteInpute = () => {
    let temp_website = [...website];
    temp_website.push("");
    setWebsite(temp_website);
  };
  const removeWebsiteInpute = (index) => {
    let temp_website = [...website];
    temp_website.splice(index, 1);
    setWebsite(temp_website);
    tokenPageData.project_website = temp_website;
  };

  //add,remove or edit Block explorer link
  const handleBlockExplorerLink = (e, index) => {
    let temp = [...blockExploreLink];
    let tempErr = [...blockExploreLinkErr];
    temp[index] = e.target.value;
    if (!validator.isURL(e.target.value)) tempErr[index] = "Enter valid URL";
    else tempErr[index] = "";
    setblockExploreLinkErr(tempErr);
    setBlockExploreLink(temp);
  };
  const addBlockExplorerLink = () => {
    let temp = [...blockExploreLink];
    temp.push("");
    setBlockExploreLink(temp);
  };
  const removeBlockExplorerLink = (index) => {
    let temp = [...blockExploreLink];
    temp.splice(index, 1);
    setBlockExploreLink(temp);
  };

  // add,remove or edit source code link
  const handleSourceCodeLink = (e, index) => {
    let temp = [...sourceCodeLink];
    let tempErr = [...sourceCodeLinkErr];
    temp[index] = e.target.value;
    if (!validator.isURL(e.target.value)) tempErr[index] = "Enter valid URL";
    else tempErr[index] = "";
    setSourceCodeLinkErr(tempErr);
    setSourceCodeLink(temp);
    tokenPageData.source_code_link = temp;
  };

  // get input value
  const onHandleTokenInfo = (event, label) => {
    const { value } = event.target;
    switch (label) {
      case "projectType":
        setTokenPageData({ ...tokenPageData, project_type: value });
        break;
      case "Description":
        setTokenPageData({
          ...tokenPageData,
          project_descricption: value,
        });
        break;
      case "DescriptionErr":
        if (!value.trim()) {
          setValidateError({
            ...validateError,
            project_descricption: "Please enter description",
          });
        } else if (value.trim().length > 600) {
          setValidateError({
            ...validateError,
            project_descricption: "Max limit is 600 characters",
          });
        } else {
          setValidateError({
            ...validateError,
            project_descricption: null,
          });
        }
        break;
      case "whitepaper":
        setTokenPageData({ ...tokenPageData, whitepaper: value.trim() });
        break;
      case "whitepaperErr":
        if (!validator.isURL(value)) {
          setValidateError({ ...validateError, whitepaper: "Enter valid URL" });
        }
        break;
      case "sourceCodeLink":
        setTokenDetails({ ...tokenDetails, source_code_link: value.trim() });
        break;
      case "sourceCodeLinkErr":
        if (!validator.isURL(value)) {
          setValidateError({
            ...validateError,
            source_code_link: "Enter valid URL",
          });
        }
        break;
      default:
        setTokenDetails(initialState);
        setValidateError(initialError);
        break;
    }
  };

  //explore links
  const onHandleSocialMediaChange = (event) => {
    setSocialMediaName(event);
    setSocialMediaNameError();
  };
  const onHandleAddSocialMedia = (event) => {
    let arr = [];
    try {
      let socialMediaLists = blockExplorerLinks;
      let err = true;
      if (socialMediaName) {
        if (!socialMediaLink) {
          setSocialMediaNumberError(
            "Please enter " + socialMediaName?.label + " username"
          );
          err;
        } else {
          let urlRegex =
            /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
          if (socialMediaLink) {
            socialMediaName.url = socialMediaLink;
            socialMediaLists.push(socialMediaName);
            setSocialMediaMaster((prev) =>
              prev.map((el) => {
                el.isDisabled = socialMediaLists.some(
                  (social) => social?.value == el?.value
                );
                return el;
              })
            );
            setBlockExplorerLinks(socialMediaLists);
            if (socialMediaLists?.length > 0) {
              socialMediaLists?.map((el) => {
                arr.push({ lable: el.label, value: el.url });
              });
              tokenPageData.block_explore_link = arr;
            }
            setSocialMediaName("");
            setSocialMediaLink("");
          } else {
            setSocialMediaNumberError(
              "Please enter valid " + socialMediaName?.label ?? "media" + "url"
            );
          }
        }
      }
    } catch (error) {
      const { name, message } = error;
    }
  };

  const onHandleRemoveSocialMedia = (socialMediaLink, index) => {
    let arr = [];
    let socialMediaLists = blockExplorerLinks;
    socialMediaLists.splice(index, 1);
    setBlockExplorerLinks(socialMediaLists);
    if (socialMediaLists?.length > 0) {
      socialMediaLists?.map((el) => {
        arr.push({ lable: el.label, value: el.url });
      });
      tokenPageData.block_explore_link = arr;
    }
    setSocialMediaMaster((prev) =>
      prev.map((el) => {
        el.isDisabled = socialMediaLists.some(
          (social) => social?.value == el?.value
        );
        return el;
      })
    );
  };

  const whitepaperref = useRef();
  const onClickUploadWhitePapert = (e) => {
    whitepaperref.current && whitepaperref.current.click();
  };

  const onHandleWhitePaperUpload = async (event) => {
    setIsPdfLoading(true);
    setWhitePaperUrl("");
    try {
      const { files } = event.target;
      const file = files && files[0];
      if (file instanceof File) {
        const fileType = file.type;

        const isImage = ["application/pdf"];
        const isFileImage = Boolean(isImage.includes(fileType));
        if (isFileImage) {
          let payload = {
            whitePaperPdf: file,
          };
          let response = await launchPadService?.uploadPdfS3(payload);

          if (response.data.status) {
            setIsPdfLoading(false);
            setWhitePaperUrl(
              response.data.imageUri?.replace(/^https?:\/\//, "")
            );
            tokenPageData.whitepaper = response.data.imageUri?.replace(
              /^https?:\/\//,
              ""
            );
          }
        } else {
          sweetAlert.errorAlert("Unsupported file selected.");
          throw new TypeError("The File not supported", file.name);
        }
      }
    } catch (error) {
      if (error instanceof TypeError) {
        const { name, message, fileName } = error;
        console.error(`${name} => ${message} => ${fileName}`);
      }
    }
  };

  //set value when component mount
  useEffect(() => {
    setWebsite(websites);
  }, [websites]);
  useEffect(() => {
    setBlockExploreLink(blockExploreLinks);
  }, [blockExploreLinks]);
  useEffect(() => {
    setSourceCodeLink(sourceCodeLinks);
  }, [sourceCodeLinks]);
  useEffect(() => {
    setTokenDetails({
      ...tokenDetails,
      project_descricption: selectedTokenItem?.project_descricption,
      whitepaper: selectedTokenItem?.whitepaper,
      source_code_link: selectedTokenItem?.source_code_link,
    });
    if (selectedTokenItem?.project_type?.length > 0) {
      let arr = [];
      selectedTokenItem?.project_type?.map((el, i) => {
        projectTypeOptions?.map((item, i) => {
          if (el == item?.label) {
            arr.push({ label: el, value: el });
          }
          setProjectType(arr);
        });
      });
    }
  }, [selectedTokenItem]);
  return (
    <div>
      <div className='tokensettingTabsection'>
        <div className='tokenlabelInputBox mb30'>
          <div className='labelBoxLeft'>
            <h3 className='font16 fontBold'>Token page info</h3>
            <p className='colorGrey'>
              Edit or add new info to your page easily
            </p>
          </div>
        </div>
        {/* add project type */}
        <div className='tokenlabelInputBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h3 className='font16 fontBold'>
                  Project type<i className='far fa-info-circle'></i>
                </h3>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='formGroupRightBox'>
                <div className='form-group'>
                  <MultiSelect
                    name='token_networks'
                    value={projectType}
                    onChange={handleProjectType}
                    options={projectTypeOptions || []}
                    isMulti={true}
                    closeMenuOnSelect={false}
                  />
                  {/* <input type="text" className="form-control mb8"></input>
                  <div className="projectTypeOptionBox">
                    <span className="liveBox projectTypeOption font12">
                      Marketing<i className="far fa-times"></i>
                    </span>
                    <span className="liveBox projectTypeOption font12">
                      Gaming<i className="far fa-times"></i>
                    </span>
                    <span className="projectDropDownArrow">
                      <i className="far fa-chevron-down"></i>
                    </span>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* add discription */}
        <div className='tokenlabelInputBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h3 className='font16 fontBold'>Enter detailed description</h3>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='formGroupRightBox'>
                <div className='form-group'>
                  <textarea
                    className='form-control bgDarkGrey'
                    placeholder='Add Description'
                    rows='4'
                    cols='50'
                    maxLength={600}
                    id='comment'
                    name='text'
                    value={tokenPageData?.project_descricption}
                    onChange={(e) => onHandleTokenInfo(e, "Description")}
                    onBlur={(e) => onHandleTokenInfo(e, "DescriptionErr")}
                  ></textarea>
                  <span className='text-danger'>
                    {validateError?.project_descricption}
                  </span>
                  <p className=' textareaCount font12 colorGrey'>0/600 words</p>
                  <p className='font12 colorGrey'>
                    Our data shows that our users spend more time on pages that
                    use descriptions that adhere to this template:{" "}
                    <a
                      className='colorBlue'
                      href='https://tinyurl.com/yy2mw9v7'
                    >
                      https://tinyurl.com/yy2mw9v7
                    </a>
                    . Recommended word count: 450 - 600 words. Provide a
                    detailed description of your project, which may be used on
                    the asset page{" "}
                    <a
                      className='colorBlue'
                      href='http://padefi.com/currencies/Sweply'
                    >
                      (http://padefi.com/currencies/Sweply)
                    </a>
                    , Minimize the use of hyperbole, superlatives, and redundant
                    statements (e.g. leading, amazing, best, first of its kind,
                    state of the art, decentralized blockchain).
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className='tokenlabelInputBox mb30'>
            <div className='labelBoxLeft'>
              <h3 className='font16 fontBold'>Project links</h3>
              <p className='colorGrey'>
                Edit or add new links to your page easily
              </p>
            </div>
          </div>
          {/* add website */}
          <div className='tokenlabelInputBox'>
            <div className='row'>
              <div className='col-sm-12 col-md-12 col-lg-4'>
                <div className='labelBoxLeft'>
                  <h3 className='font16 fontBold'>
                    Add Website <span>(Optional)</span>
                  </h3>
                </div>
              </div>
              <div className='col-sm-12 col-md-12 col-lg-8'>
                <div className='formGroupRightBox httpsBox'>
                  {website &&
                    Array.isArray(website) &&
                    website?.map((item, i) => {
                      return (
                        <div className='form-group' key={i}>
                          <div className='httpsNewAddBox'>
                            <input
                              id={i}
                              type='text'
                              size='40'
                              className='form-control'
                              placeholder='Ex. PinkMoon'
                              value={item}
                              onChange={(e) => handleChangeWebsite(e, i)}
                            ></input>
                            <span>
                              <Image alt='' src={chainIcon} /> https://
                            </span>
                            <div className='col'>
                              {website.length !== 1 ? (
                                <button
                                  className='btn btn-outline-danger crossInputBtn'
                                  onClick={() => removeWebsiteInpute(i)}
                                >
                                  x
                                </button>
                              ) : (
                                ""
                              )}
                            </div>
                          </div>
                          <div className='text-danger err'>
                            {" "}
                            {websiteErr[i]}
                          </div>
                        </div>
                      );
                    })}
                  <button
                    className='addNewLinkBtn font16 fontBold colorBlue mb24'
                    onClick={addWebsiteInpute}
                  >
                    <i className='far fa-plus'></i> Add another link
                  </button>
                </div>
              </div>
            </div>
          </div>
          {/* add Whitepaper */}
          <div className='tokenlabelInputBox'>
            <div className='row'>
              <div className='col-sm-12 col-md-12 col-lg-4'>
                <div className='labelBoxLeft'>
                  <h3 className='font16 fontBold'>
                    Add Whitepaper <span>(Optional)</span>
                  </h3>
                  <p className='colorGrey'>
                    If you have it in a PDF file, Convert it to URL
                  </p>
                </div>
              </div>
              <div className='col-sm-12 col-md-12 col-lg-8'>
                <div className='formGroupRightBox httpsBox uploadPDForBox'>
                  <div className='form-group'>
                    <input
                      type='text'
                      className='form-control mb8'
                      value={whitepaperUrl}
                      onChange={(e) => {
                        setWhitePaperUrl(
                          e.target.value?.replace(/^https?:\/\//, "")
                        );
                        tokenPageData.whitepaper = e.target.value?.replace(
                          /^https?:\/\//,
                          ""
                        );
                      }}
                      onBlur={(e) => onHandleTokenInfo(e, "whitepaperErr")}
                    ></input>
                    <span>
                      <Image alt='' src={chainIcon} /> https://
                    </span>
                    <div className='text-danger err'>
                      {validateError.whitepaper}
                    </div>
                  </div>
                  <div className='orNuploadBtnBox'>
                    <div className=''>Or</div>

                    <ButtonCustom
                      className='uploadPdfBtn fontBold font16 colorBlue'
                      type='button'
                      onClick={(e) => onClickUploadWhitePapert(e)}
                      isLoading={isPdfLoading}
                      disabled={isPdfLoading}
                    >
                      <Image alt='' src={uploadPdfIcon} /> Upload PDF
                    </ButtonCustom>
                    <input
                      ref={whitepaperref}
                      type='file'
                      accept='.pdf'
                      className='form-control'
                      hidden
                      onChange={(event) => onHandleWhitePaperUpload(event)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className='addwebsiteBox'>
            <div className='row'>
              <div className='col-sm-12 col-md-12 col-lg-4'>
                <h3 className='font16 fontBold'>
                  Add block explorer links (Optional)
                </h3>
                <p className='colorGrey'>(ex. EtherScan, BscScan)</p>
              </div>
              <div className='col-sm-12 col-md-12 col-lg-8'>
                <div className='fillstreamingservicebox editProfServiceBox'>
                  <div className='row row-10'>
                    {blockExplorerLinks &&
                      blockExplorerLinks.length > 0 &&
                      blockExplorerLinks.map((el, i) => (
                        <div
                          className='linkandFromGroupBox secondexplorerlinksBx'
                          key={i}
                        >
                          <div className='form-group socialSelectDrop'>
                            <Select
                              id='portf'
                              className='favoriteGameDrop socialDropDown'
                              name='socialmedianame'
                              disabled={true}
                              noOptionsMessage={() => null}
                              isSearchable={false}
                              value={el}
                            />
                            <div className='invalid-feedback d-block'>
                              {socialMediaNameError || null}
                            </div>
                          </div>

                          <div className='form-group'>
                            <input
                              type='text'
                              value={el.url}
                              className='form-control borderRadius4'
                              name='socialmedialink'
                              disabled={true}
                              placeholder='Enter username'
                            />
                          </div>
                          <button
                            className='btn btn-outline-danger crossInputBtn'
                            onClick={() => onHandleRemoveSocialMedia(i)}
                          >
                            x
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
                <div className='explorerlinksSocialBox'>
                  <div className='groupLinkForm posRelative sigalexplorerlinksBx '>
                    <div className='linkandFromGroupBox'>
                      <div className='form-group socialSelectDrop'>
                        <Select
                          id='portf'
                          className='favoriteGameDrop socialDropDown'
                          name='socialmedianame'
                          //menuIsOpen="true"
                          value={socialMediaName}
                          onChange={(e) => onHandleSocialMediaChange(e)}
                          options={socialMediaMaster}
                          isOptionDisabled={(option) => option.isDisabled}
                        />
                        <div className='invalid-feedback d-block'>
                          {socialMediaNameError || null}
                        </div>
                      </div>

                      <div className='form-group'>
                        {/*<label className="colorWhite active">
                            Add your {socialMediaName?.label ?? "Social"} link
                              </label>*/}
                        <input
                          type='text'
                          value={socialMediaLink ?? ""}
                          onChange={(e) => {
                            setSocialMediaLink(
                              e.target.value?.replace(/^https?:\/\//, "")
                            );
                            setSocialMediaNumberError("");
                          }}
                          className='form-control borderRadius4'
                          name='socialmedialink'
                          placeholder='Enter username'
                        />
                      </div>
                    </div>
                    <div className='invalid-feedback d-block'>
                      {socialMediaNumberError || null}
                    </div>

                    {/* <div className='btn-box'>
                  <button
                    onClick={(e) => onHandleAddSocialMedia(e)}
                    type="button"
                    className="linkCopyBtn posAbsolute borderRadius6 colorWhite font16 socialAddBtn"
                  >
                    Add
                  </button>
                </div> */}
                  </div>
                </div>

                <button
                  className='btnSociallink fontBold'
                  onClick={(e) => onHandleAddSocialMedia(e)}
                >
                  <i className='far fa-plus'></i> Add another link
                </button>
              </div>
            </div>
          </div>
          {/* add block explore links end */}

          {/* Add Source code links */}
          <div className='tokenlabelInputBox'>
            <div className='row'>
              <div className='col-sm-12 col-md-12 col-lg-4'>
                <div className='labelBoxLeft'>
                  <h3 className='font16 fontBold'>
                    Add Source code links <span>(Optional)</span>
                  </h3>
                  <p className='colorGrey'>(ex. GitHub, Gitter)</p>
                </div>
              </div>
              <div className='col-sm-12 col-md-12 col-lg-8'>
                <div className='formGroupRightBox httpsBox'>
                  {sourceCodeLink &&
                    Array.isArray(sourceCodeLink) &&
                    sourceCodeLink?.map((item, i) => {
                      return (
                        <div className='form-group' key={i}>
                          <input
                            type='text'
                            className='form-control'
                            value={item}
                            onChange={(e) => handleSourceCodeLink(e, i)}
                            // onChange={(e) => onHandleTokenInfo(e, "sourceCodeLink")}
                            // onBlur={(e) => onHandleTokenInfo(e, "sourceCodeLinkErr")}
                          ></input>
                          <span>
                            <Image alt='' src={chainIcon} /> https://
                          </span>
                          <div className='text-danger err'>
                            {sourceCodeLinkErr[i]}
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='tokenSettingBtmSavebox'>
        <button
          className='font16 fontBold cancelBlack'
          onClick={() => {
            router.push("/");
          }}
        >
          Cancel
        </button>
        <ButtonCustom
          className='font16 fontBold'
          onClick={(e) => updateTokenPageData(e)}
          isLoading={isLoadingSubmit}
          disabled={isLoadingSubmit}
        >
          Save
        </ButtonCustom>
      </div>
    </div>
  );
}
