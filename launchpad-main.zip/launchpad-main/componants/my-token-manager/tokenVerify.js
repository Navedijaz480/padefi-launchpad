import React from "react";
import { ethers } from "ethers";
import { isConnected } from "../auth/wallet/walletConnectAuth";
import {
  bscTestnet,
  bscMainnet,
  ethereumMainnet,
  fantomMainnet,
} from "../auth/wallet/walletNetworks";
import { getTrustWalletInjectedProvider } from "../auth/CustomWallet/ConnectTrustWallet/TrustWallet";

const checkContractOwner = async (walletAddress, owner) => {
  if(walletAddress[0] && owner) return walletAddress[0].toLowerCase() === props.toLowerCase();
  else return false;
};

const tokenVerify = async (props, network) => {
  try {
    if (network == "ETH") await ethereumMainnet();
    else if (network == "BNB") await bscMainnet();
    else if (network == "POLYGON") await bscTestnet();
    else if (network == "FANTOM") await fantomMainnet();
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const contractAddress = props;

    //abi I am using in my code
    const ERC20_ABI = [
      // Read-Only Functions
      "function decimals() view returns (uint8)",
      "function symbol() view returns (string)",
      "function name() view returns (string)",
      "function totalSupply() view returns (uint256)",
      "function owner() view returns (address)",
    ];

    const contract = new ethers.Contract(contractAddress, ERC20_ABI, provider);

    let tokenDetails = {};
    try {
      let name = await contract.name();
      let symbol = await contract.symbol();
      let totalSupply = await contract.totalSupply();
      let decimals = await contract.decimals();
      let owner = await contract.owner();
      let contract_address = contract.address;

      tokenDetails = {
        name: name,
        symbol: symbol,
        decimals: decimals,
        totalSupply: ethers.utils.formatEther(totalSupply),
        owner: owner,
        contract_address: contract_address,
        networkName: network,
        status: "verified",
      };
    } catch (error) {
      tokenDetails = {
        networkName: network,
        status: "Not verified",
      };
      console.log("errrrr is: ", error);
      return tokenDetails;
    }

    console.log("tokenDetails is: ", tokenDetails);

    return tokenDetails;
  } catch (error) {
    console.log(error);
  }
};

async function MultiTokenVerify(props, network) {
  try {
    let verifyTokenStatus = [];
    for (const element of network) {
      let item = element;
      switch (item.value) {
        case "ETH":
          await ethereumMainnet();
          const ethCheck = await checkTokenVerify(props, "ETH");
          if (Object.keys(ethCheck).length !== 0) {
            verifyTokenStatus.push(
              Object.keys(ethCheck).length === 0 ? "" : ethCheck
            );
          } else {
            verifyTokenStatus.push({
              networkName: "ETH",
              status: "Not verified",
            });
          }
          break;
        case "BSC":
          await bscMainnet();
          const bscCheck = await checkTokenVerify(props, "BSC");
          if (Object.keys(bscCheck).length !== 0) {
            verifyTokenStatus.push(
              Object.keys(bscCheck).length === 0 ? {} : bscCheck
            );
          } else {
            verifyTokenStatus.push({
              networkName: "POLYGON",
              status: "Not verified",
            });
          }
          break;
        case "POLYGON":
          await bscTestnet();
          const polyCheck = await checkTokenVerify(props, "POLYGON");
          if (Object.keys(polyCheck).length !== 0) {
            verifyTokenStatus.push(
              Object.keys(polyCheck).length === 0 ? {} : polyCheck
            );
          } else {
            verifyTokenStatus.push({
              networkName: "POLYGON",
              status: "Not verified",
            });
          }
          break;
        case "FANTOM":
          await fantomMainnet();
          const fantomCheck = await checkTokenVerify(props, "FANTOM");
          if (Object.keys(fantomCheck).length !== 0) {
            verifyTokenStatus.push(
              Object.keys(fantomCheck).length === 0 ? {} : fantomCheck
            );
          } else {
            verifyTokenStatus.push({
              networkName: "FANTOM",
              status: "Not verified",
            });
          }
          break;
        default:
        case "ETH":
          await ethereumMainnet();
          const defaultEthCheck = await checkTokenVerify(props, "ETH");
          if (Object.keys(defaultEthCheck).length !== 0) {
            verifyTokenStatus.push(
              Object.keys(defaultEthCheck).length === 0 ? "" : defaultEthCheck
            );
          } else {
            verifyTokenStatus.push({
              networkName: "ETH",
              status: "Not verified",
            });
          }
      }
    }
    return verifyTokenStatus;
  } catch (error) {
    console.log(error);
  }
}

const checkTokenVerify = async (props, network) => {
  let tokenDetails = {};
  try {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const contractAddress = props;
    const ERC20_ABI = [
      // Read-Only Functions
      "function decimals() view returns (uint8)",
      "function symbol() view returns (string)",
      "function name() view returns (string)",
      "function totalSupply() view returns (uint256)",
      "function owner() view returns (address)",
    ];

    const contract = new ethers.Contract(contractAddress, ERC20_ABI, provider);
    let name = await contract.name();
    let symbol = await contract.symbol();
    let totalSupply = await contract.totalSupply();
    let decimals = await contract.decimals();
    let owner = await contract.owner();
    let contract_address = contract.address;
    tokenDetails = {
      name: name,
      symbol: symbol,
      decimals: decimals,
      totalSupply: ethers.utils.formatEther(totalSupply),
      owner: owner,
      contract_address: contract_address,
      networkName: network.value,
      status: "verified",
    };
    return tokenDetails;
  } catch (error) {
    console.log("error is metamask: ", error);
    tokenDetails = {
      networkName: network.value,
      status: "not verified",
    };
    return tokenDetails;
  }
};
const trustWalletCheckTokenVerify = async (props, network, walletAddress) => {
  let tokenDetails = {};
  try {
    const injectedProvider = await getTrustWalletInjectedProvider();
    const ethersProvider = new ethers.providers.Web3Provider(injectedProvider);
    const contractAddress = props;
    const ERC20_ABI = [
      // Read-Only Functions
      "function decimals() view returns (uint8)",
      "function symbol() view returns (string)",
      "function name() view returns (string)",
      "function totalSupply() view returns (uint256)",
      "function owner() view returns (address)",
    ];

    const contract = new ethers.Contract(
      contractAddress,
      ERC20_ABI,
      ethersProvider
    );
    let name = await contract.name();
    let symbol = await contract.symbol();
    let totalSupply = await contract.totalSupply();
    let decimals = await contract.decimals();
    let owner = await contract.owner();
    let contract_address = contract.address;

    const verifyStatus = await checkContractOwner(walletAddress, owner)
    console.log('verifyStatus', verifyStatus)
    if(verifyStatus){
      tokenDetails = {
        name: name,
        symbol: symbol,
        decimals: decimals,
        totalSupply: ethers.utils.formatEther(totalSupply),
        owner: owner,
        contract_address: contract_address,
        networkName: network.value,
        status: "verified",
      };
      return tokenDetails;
    }else{
      tokenDetails = {
        networkName: network.value,
        status: "not verified",
      };
    }
    
  } catch (error) {
    console.log("error is00000000000: ", error);
    tokenDetails = {
      networkName: network.value,
      status: "not verified",
    };
    return tokenDetails;
  }
};
export {
  tokenVerify,
  checkContractOwner,
  MultiTokenVerify,
  checkTokenVerify,
  trustWalletCheckTokenVerify,
};
