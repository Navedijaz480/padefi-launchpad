import React, { useState, useEffect } from "react";
import Image from "next/future/image";
import chainIcon from "../../static/images/chainicon.svg";
import validator from "validator";
import Input from "componants/common/Input";
import Select from "react-select";
import ButtonCustom from "componants/common/ButtonCustom";
import { useRouter } from "next/router";

const initialState = {
  token_id: null,
  token_addr: null,
  token_network: null,
  contract_addr: null,
  email: null,
  message_board_link: null,
  social_link: null,
  video_channel_link: null,
  highlighted_video_link: null,
  eco_sysytem_link: null,
  status: null,
};
const initialError = {
  token_id: null,
  token_addr: null,
  token_network: null,
  contract_addr: null,
  email: null,
  message_board_link: null,
  social_link: null,
  video_channel_link: null,
  highlighted_video_link: null,
  eco_sysytem_link: null,
  status: null,
  messageBoardLinkErr: null,
};
export default function SocialLinks(props) {
  const {
    selectedTokenItem,
    socialMediaList,
    setSocialMediaList,
    tokenPageData,
    updateTokenPageData,
    isLoadingSubmit,
  } = props;
  //states
  const [tokenDetails, setTokenDetails] = useState(initialState);
  const [validateError, setValidateError] = useState(initialError);
  let router = useRouter();
  let urlRegex =
    /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
  //add social media link
  const initialSocialMedia = [
    { value: "facebook", label: "Facebook", isDisabled: false },
    { value: "linkedin", label: "LinkedIn", isDisabled: false },
    { value: "github", label: "Github", isDisabled: false },
    { value: "discord", label: "Discord", isDisabled: false },
    { value: "talkwalker", label: "Talkwalker", isDisabled: false },
  ];

  const [socialMediaMaster, setSocialMediaMaster] =
    useState(initialSocialMedia);
  const [socialMediaNumberError, setSocialMediaNumberError] = useState("");
  const [socialMediaName, setSocialMediaName] = useState("");
  const [socialMediaNameError, setSocialMediaNameError] = useState([]);
  const [socialMediaLink, setSocialMediaLink] = useState("");
  const inputEcosystem = [{ ecosystem_links: "" }];
  const [ecosystem, setEcosystem] = useState(inputEcosystem);

  const ecosystems = selectedTokenItem?.eco_sysytem_link;

  useEffect(() => {
    if (ecosystems?.length > 0) {
      let arr = [];
      ecosystems?.map((el, i) => {
        arr.push({ value: "", ecosystem: el });
      });
      setEcosystem(arr);
    }
  }, [ecosystems]);

  //add/remove eco system links
  const addEcoSystemLinkInput = () => {
    setEcosystem((s) => {
      return [
        ...s,
        {
          value: "",
        },
      ];
    });
  };
  const handleEcoSystemLink = (e, i) => {
    const { name, value } = e.target;
    const list = [...ecosystem];
    list[i][name] = value?.replace(/^https?:\/\//, "");
    setEcosystem(list);
    tokenPageData.eco_sysytem_link = list;
  };
  const removeEcoSysLinkFields = (i) => {
    const rows = [...ecosystem];
    rows.splice(i, 1);
    setEcosystem(rows);
    tokenPageData.eco_sysytem_link = rows;
  };
  //add social media links
  const onHandleSocialMediaChange = (event) => {
    setSocialMediaName(event);
    setSocialMediaNameError();
  };

  const onHandleAddSocialMedia = (event) => {
    let arr = [];
    try {
      let socialMediaLists = socialMediaList;
      let err = true;
      if (socialMediaName) {
        if (!socialMediaLink) {
          setSocialMediaNumberError(
            "Please enter " + socialMediaName?.label + " username"
          );
          err;
        } else {
          let urlRegex =
            /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
          if (socialMediaLink) {
            socialMediaName.url = socialMediaLink;
            socialMediaLists.push(socialMediaName);
            setSocialMediaMaster((prev) =>
              prev.map((el) => {
                el.isDisabled = socialMediaLists.some(
                  (social) => social?.value == el?.value
                );
                return el;
              })
            );
            setSocialMediaList(socialMediaLists);
            if (socialMediaLists?.length > 0) {
              socialMediaLists?.map((el) => {
                arr.push({ lable: el.label, value: el.url });
              });
              tokenPageData.social_link = arr;
            }
            setSocialMediaName("");
            setSocialMediaLink("");
          } else {
            setSocialMediaNumberError(
              "Please enter valid " + socialMediaName?.label ?? "media" + "url"
            );
          }
        }
      }
    } catch (error) {
      const { name, message } = error;
    }
  };

  const onHandleRemoveSocialMedia = (socialMediaLink, index) => {
    let arr = [];
    let socialMediaLists = socialMediaList;
    socialMediaLists.splice(index, 1);
    setSocialMediaList(socialMediaLists);
    if (socialMediaLists?.length > 0) {
      socialMediaLists?.map((el) => {
        arr.push({ lable: el.label, value: el.url });
      });
      tokenPageData.social_link = arr;
    }
    setSocialMediaMaster((prev) =>
      prev.map((el) => {
        el.isDisabled = socialMediaLists.some(
          (social) => social?.value == el?.value
        );
        return el;
      })
    );
  };

  const onHandleSocialLinkInfo = (event, index, label) => {
    const { value } = event.target;

    let tempTokanDetails = { ...tokenDetails };

    let temp_message_board_link = [...tokenPageData?.message_board_link];
    let temp_social_link = [...tokenDetails?.social_link];

    // let vidioLink = tokenDetails?.video_channel_link;
    // let highlightVidioLink = tokenDetails?.highlighted_video_link;

    // let messageBoardLinkErr = [...validateError?.message_board_link];
    // let socialLinkErr = [...validateError?.social_link];
    // let vidioLinkErr = { ...validateError?.video_channel_link };
    // let highlightVidioLinkErr = { ...validateError?.highlighted_video_link };

    switch (label) {
      case "messageBoardLink":
        temp_message_board_link[index] = value;
        break;
      case "socialLink":
        temp_social_link[index] = value;
        break;

      case "vidioLink":
        tokenPageData.video_channel_link = value.trim();
        break;

      case "highlightVidioLink":
        tokenPageData.highlighted_video_link = value.trim();
        break;

      // case "messageBoardLinkErr":
      //   if (!validator.isURL(value))
      //     messageBoardLinkErr[index] = "Enter valid URL";
      //   else messageBoardLinkErr[index] = "";
      //   break;

      // case "socialLinkErr":
      //   if (!validator.isURL(value)) socialLinkErr[index] = "Enter Valid URL";
      //   else socialLinkErr[index] = "";
      //   break;

      // case "vidioLinkErr":
      //   if (!validator.isURL(value)) vidioLinkErr = "Enter Valid URL";
      //   else vidioLinkErr = "";
      //   break;

      // case "highlightVidioLinkErr":
      //   if (!validator.isURL(value)) highlightVidioLinkErr = "Enter Valid URL";
      //   else highlightVidioLinkErr = "";
      //   break;

      // default:
      //   setTokenDetails(initialState);
      //   setValidateError(initialError);
      //   break;
    }

    tempTokanDetails.message_board_link = temp_message_board_link;
    tempTokanDetails.social_link = temp_social_link;

    setTokenDetails({
      ...tokenDetails,
      ...tempTokanDetails,
    });
    // setTokenDetails({
    //   ...tokenDetails,
    //   message_board_link: messageBoardLink,
    //   social_link: socialLink,
    //   // video_channel_link: vidioLink,
    //   // highlighted_video_link: highlightVidioLink
    // });
    // setValidateError({
    //   ...validateError,
    //   message_board_link: messageBoardLinkErr,
    //   social_link: socialLinkErr,
    //   // video_channel_link: vidioLinkErr,
    //   // highlighted_video_link: highlightVidioLinkErr,
    // });
  };

  /**
   * @desc add/remove another Social Links
   */
  const addSocialLiks = () => {
    let temp_socialLink = [...tokenDetails?.social_link];
    temp_socialLink.push("");
    setTokenDetails({
      ...tokenDetails,
      social_link: temp_socialLink,
    });
  };
  const removeSocialLinks = (index) => {
    let temp_socialLink = [...tokenDetails?.social_link];
    temp_socialLink.splice(index, 1);
    setTokenDetails({
      ...tokenDetails,
      social_link: temp_socialLink,
    });
  };

  /**
   * @desc set value when component mount
   */
  useEffect(() => {
    //set error
    let tempMessageBoardLinkErr = [];
    let tempSocialLinkErr = [];

    selectedTokenItem?.message_board_link &&
      selectedTokenItem?.message_board_link.map((item, i) => {
        tempMessageBoardLinkErr.push("");
      });
    selectedTokenItem?.social_link &&
      selectedTokenItem?.social_link.map((item, i) => {
        tempSocialLinkErr.push("");
      });

    setValidateError({
      ...validateError,
      message_board_link: tempMessageBoardLinkErr,
      social_link: tempSocialLinkErr,
    });
    //set value
    setTokenDetails({
      ...tokenDetails,
      message_board_link: selectedTokenItem?.message_board_link,
      social_link: selectedTokenItem?.social_link,
      video_channel_link: selectedTokenItem?.video_channel_link,
      highlighted_video_link: selectedTokenItem?.highlighted_video_link,
    });
  }, [selectedTokenItem]);
  return (
    <div>
      <div>
        <div className='tokenlabelInputBox additionalProjectLinks'>
          <div className='labelBoxLeft'>
            <h3 className='font16 fontBold'>
              Additional Project links<span>(Optional)</span>
            </h3>
            <p className='colorGrey'>
              Edit or add new social links to your page easily
            </p>
          </div>
        </div>
        {/*  Add message board links */}
        <div className='tokenlabelInputBox addMessageBoardBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h3 className='font16 fontBold'>
                  Add message board links <span>(Optional)</span>
                </h3>
                <p className='colorGrey'>(ex. Medium, Blog )</p>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='formGroupRightBox httpsBox'>
                {tokenDetails?.message_board_link &&
                  tokenDetails?.message_board_link.length > 0 &&
                  tokenDetails?.message_board_link.map((item, i) => {
                    return (
                      <div className='form-group' key={i}>
                        <input
                          type='text'
                          class='form-control mb8'
                          value={item}
                          onChange={(e) =>
                            onHandleSocialLinkInfo(e, i, "messageBoardLink")
                          }
                          onBlur={(e) =>
                            onHandleSocialLinkInfo(e, i, "messageBoardLinkErr")
                          }
                        />
                        <span>
                          <Image alt='' src={chainIcon} />
                          https://
                        </span>
                        <div className='text-danger err'>
                          {validateError?.message_board_link[i]}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        </div>
        {/* Add Social links old code */}
        {/* <div className="tokenlabelInputBox">
          <div className="labelBoxLeft">
            <h3 className="font16 fontBold">
              Add Social links <span>(Optional)</span>
            </h3>
            <p className="colorGrey">
              You must provide a website and a twitter account of your token so
              users can know more about your project. Otherwise, it is optional
              to add more social links
            </p>
          </div>
          <div className="formGroupRightBox httpsBox uploadPDForBox etherscanBox socialDropBox">
            {tokenDetails?.social_link &&
              Array.isArray(tokenDetails?.social_link) &&
              tokenDetails?.social_link.map((item, i) => {
                return (
                  <div className="etherscanDropDown" key={i}>
                    <div className="blockExploerDropDown">
                      <select class="colorGrey">
                        <option>Twitter</option>
                        <option>Telegram</option>
                        <option>LinkedIn</option>
                        <option>Reddit</option>
                        <option>Instagram</option>
                        <option>Discord</option>
                      </select>
                      <i class="far fa-chevron-down"></i>
                    </div>
                    <div className="form-group">
                      <input
                        type="text"
                        class="form-control mb8"
                        value={item}
                        onChange={(e) =>
                          onHandleSocialLinkInfo(e, i, "socialLink")
                        }
                        onBlur={(e) =>
                          onHandleSocialLinkInfo(e, i, "socialLinkErr")
                        }
                      />
                      <span>
                        <Image alt="" src={chainIcon} /> https://
                      </span>
                      <div className="col">
                        {tokenDetails?.social_link?.length !== 1 ? (
                          <button
                            className="btn btn-outline-danger crossInputBtn"
                            onClick={() => removeSocialLinks(i)}
                          >
                            x
                          </button>
                        ) : (
                          ""
                        )}
                      </div>
                      <div className="text-danger err">
                        {validateError?.social_link[i]}
                      </div>
                    </div>
                    <div className="closeIcon">
                      <i class="fal fa-times"></i>
                    </div>
                  </div>
                );
              })}

            <button
              className="addNewLinkBtn font16 fontBold colorBlue mb24"
              onClick={addSocialLiks}
            >
              + Add another link
            </button>
          </div>
        </div> */}
        {/* Add Video channel link old code */}

        <div className='addwebsiteBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h2 className='font16 fontBold'>Add Social links</h2>
                <p className='colorGrey'>
                  You must provide a website and a twitter account of your token
                  so users can know more about your project. Otherwise, it is
                  optional to add more social links
                </p>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='fillstreamingservicebox editProfServiceBox'>
                <div className='row row-10'>
                  {socialMediaList &&
                    socialMediaList.length > 0 &&
                    socialMediaList.map((el, i) => (
                      <div
                        className='linkandFromGroupBox secondexplorerlinksBx'
                        key={i}
                      >
                        <div className='form-group socialSelectDrop'>
                          <Select
                            id='portf'
                            className='favoriteGameDrop socialDropDown'
                            name='socialmedianame'
                            menuIsOpen='true'
                            disabled={true}
                            noOptionsMessage={() => null}
                            isSearchable={false}
                            value={el}
                            // onChange={(e) => onHandleSocialMediaChange(e)}
                            // options={socialMediaMaster}
                            // isOptionDisabled={(option) => option.isDisabled}
                          />
                          <div className='invalid-feedback d-block'>
                            {socialMediaNameError || null}
                          </div>
                        </div>

                        <div className='form-group'>
                          {/*<label className="colorWhite active">
                            Add your {socialMediaName?.label ?? "Social"} link
                              </label>*/}
                          <input
                            type='text'
                            value={el.url}
                            disabled={true}
                            // onChange={(e) => {
                            //   setSocialMediaLink(e.target.value);
                            //   setSocialMediaNumberError("");
                            // }}
                            className='form-control borderRadius4'
                            name='socialmedialink'
                            placeholder={`Enter ${
                              socialMediaName?.label + " username"
                            }`}
                          />
                        </div>
                        <button
                          className='btn btn-outline-danger crossInputBtn'
                          onClick={() => onHandleRemoveSocialMedia(i)}
                        >
                          x
                        </button>
                        {/* <Button
                        varient='primary'
                        onClick={(e) => onHandleRemoveSocialMedia(el, i)}
                      >
                        <i className='fal fa-trash-alt'></i>
                      </Button> */}
                      </div>
                    ))}
                </div>
              </div>
              <div className='explorerlinksSocialBox'>
                <div className='groupLinkForm posRelative sigalexplorerlinksBx '>
                  <div className='linkandFromGroupBox'>
                    <div className='form-group socialSelectDrop'>
                      <Select
                        id='portf'
                        className='favoriteGameDrop socialDropDown'
                        name='socialmedianame'
                        //menuIsOpen="true"
                        value={socialMediaName}
                        onChange={(e) => onHandleSocialMediaChange(e)}
                        options={socialMediaMaster}
                        isOptionDisabled={(option) => option.isDisabled}
                      />
                      <div className='invalid-feedback d-block'>
                        {socialMediaNameError || null}
                      </div>
                    </div>

                    <div className='form-group'>
                      {/*<label className="colorWhite active">
                            Add your {socialMediaName?.label ?? "Social"} link
                              </label>*/}
                      <input
                        type='text'
                        value={socialMediaLink ?? ""}
                        onChange={(e) => {
                          setSocialMediaLink(
                            e.target.value?.replace(/^https?:\/\//, "")
                          );
                          setSocialMediaNumberError("");
                        }}
                        className='form-control borderRadius4'
                        name='socialmedialink'
                        placeholder={`Enter ${
                          socialMediaName?.label ?? "social"
                        }  username`}
                      />
                    </div>
                  </div>
                  <div className='invalid-feedback d-block'>
                    {socialMediaNumberError || null}
                  </div>

                  {/* <div className='btn-box'>
                  <button
                    onClick={(e) => onHandleAddSocialMedia(e)}
                    type="button"
                    className="linkCopyBtn posAbsolute borderRadius6 colorWhite font16 socialAddBtn"
                  >
                    Add
                  </button>
                </div> */}
                </div>
              </div>

              <button
                className='btnSociallink fontBold'
                onClick={(e) => onHandleAddSocialMedia(e)}
              >
                <i className='far fa-plus'></i> Add another link
              </button>
            </div>
          </div>
        </div>

        <div className='tokenlabelInputBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h3 className='font16 fontBold'>
                  Add Video channel link <span>(Optional)</span>
                </h3>
                <p className='colorGrey'>(ex. Youtube, Vimeo)</p>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='formGroupRightBox httpsBox'>
                <label class='colorGrey'>Video channel link</label>
                <div className='form-group'>
                  <input
                    type='text'
                    class='form-control mb8'
                    value={tokenPageData?.video_channel_link}
                    onChange={(e) => {
                      onHandleSocialLinkInfo(e, "", "vidioLink");
                    }}
                    onBlur={(e) => {
                      onHandleSocialLinkInfo(e, "", "vidioLinkErr");
                    }}
                  />
                  <span>
                    <Image alt='' src={chainIcon} />
                    https://
                  </span>
                  {/* <div className="text-danger err">
                    {validateError?.video_channel_link}
                  </div> */}
                </div>
                <label class='colorGrey'>Highlighted Video link</label>
                <div className='form-group'>
                  <input
                    type='text'
                    class='form-control mb8'
                    value={tokenPageData?.highlighted_video_link}
                    onChange={(e) => {
                      onHandleSocialLinkInfo(e, "", "highlightVidioLink");
                    }}
                    onBlur={(e) => {
                      onHandleSocialLinkInfo(e, "", "highlightVidioLinkErr");
                    }}
                  ></input>
                  <span>
                    <Image alt='' src={chainIcon} /> https://
                  </span>
                  {/* <div className="text-danger err">
                    {validateError?.highlighted_video_link}
                  </div> */}
                </div>
              </div>
            </div>
          </div>
        </div>
        {/*  Add Ecosystem links start old code */}
        {/* <div className='tokenlabelInputBox'>
          <div className='labelBoxLeft'>
            <h3 className='font16 fontBold'>
              Add Ecosystem links <span>(Optional)</span>
            </h3>
            <p className='colorGrey'>(link from Appstore, Google, etc...)</p>
          </div>
          <div className='formGroupRightBox httpsBox'>
            <div className='form-group'>
              <input type='text' class='form-control mb8' />

              <span>
                <Image alt='' src={chainIcon} /> https://
              </span>
            </div>
            <div className='form-group'>
              <input type='text' class='form-control mb8'></input>
              <span>
                <Image alt='' src={chainIcon} /> https://
              </span>
            </div>
            <button className='addNewLinkBtn font16 fontBold colorBlue mb24'>
              + Add another link
            </button>
          </div>
        </div> */}
        {/* add ecosystem end old code */}
        <div className='addwebsiteBox'>
          <div className='row'>
            <div className='col-sm-12 col-md-12 col-lg-4'>
              <div className='labelBoxLeft'>
                <h3 className='font16 fontBold'>Add Ecosystem links </h3>
                <p className='colorGrey'>
                  (link from Appstore, Google, etc...)
                </p>
              </div>
            </div>
            <div className='col-sm-12 col-md-12 col-lg-8'>
              <div className='form-group httpsBox'>
                {ecosystem?.map((item, i) => {
                  return (
                    <>
                      <div className='form-group httpsBox' key={i}>
                        <div className='httpsNewAddBox'>
                          <input
                            id={i}
                            onChange={(e) => {
                              if (
                                e.target.value?.length > 0 &&
                                !e.target.value?.match(urlRegex)
                              ) {
                                // props?.setEcoSystemLinksErrToggle(true);
                                // props?.setEcoSystemLinksErr(
                                //   "Please enter valid url"
                                // );
                              } else {
                                // props?.setEcoSystemLinksErrToggle(false);
                                // props?.setEcoSystemLinksErr("");
                              }
                              handleEcoSystemLink(e, i);
                            }}
                            value={item.ecosystem}
                            name='ecosystem'
                            size='40'
                            className='form-control'
                            placeholder='Ex. PinkMoon'
                          />
                          <span>
                            <Image alt='' src={chainIcon} /> https://
                          </span>
                          <div className='col'>
                            {ecosystem.length !== 1 ? (
                              <button
                                className='btn btn-outline-danger crossInputBtn'
                                onClick={() => removeEcoSysLinkFields(i)}
                              >
                                x
                              </button>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}
                <div className='text-danger'>{props.ecoSystemLinksErr}</div>
                <button
                  className='btnSociallink fontBold'
                  onClick={addEcoSystemLinkInput}
                >
                  <i className='far fa-plus'></i> Add another link
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='tokenSettingBtmSavebox'>
        <button
          className='font16 fontBold cancelBlack'
          onClick={() => {
            router.push("/");
          }}
        >
          Cancel
        </button>

        <ButtonCustom
          className='font16 fontBold'
          onClick={(e) => updateTokenPageData(e)}
          isLoading={isLoadingSubmit}
          disabled={isLoadingSubmit}
        >
          Save
        </ButtonCustom>
      </div>
    </div>
  );
}
