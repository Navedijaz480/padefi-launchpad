import React, { useState, useEffect } from "react";
import DeleteTokenPageModel from "../../componants/my-token-manager/DeleteTokenPageModel";
import TokenManagerThunkAPI from "store/features/tokenManager/middleware";
import { useSelector, useDispatch } from "react-redux";

export default function DeactivatePage(props) {
  const { selectedTokenItem } = props;
  const dispatch = useDispatch();
  let token_name = selectedTokenItem?.token_data?.[0]?.name || "N/A";
  let tokenPageId = selectedTokenItem?._id;

  const [toggleShowModel, setToggleShowModel] = useState(false);
  const [deactivate_message, setDeactivate_message] = useState("");
  const [showDeleteMessage, setShowDeleteMessage] = useState(false);
  const [errMsg, setErrMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const deleteTokenPageStatus = useSelector((state) => state.tokenManagerState);
  useEffect(() => {
    setIsLoading(false);
    if (deleteTokenPageStatus?.deleteTokenPageStatus == 1) {
      setShowDeleteMessage(true);
    }
  }, [deleteTokenPageStatus?.deleteTokenPageStatus]);
  const handleCloseDeleteTokenPage = () => {
    setIsLoading(false);
    setDeactivate_message("");
    setErrMsg("");
    setToggleShowModel(false);
  };
  const handleShowDeleteTokenPage = () => setToggleShowModel(true);
  const handleDeactivateMessage = (e) => {
    setDeactivate_message(e.target.value?.trim().toUpperCase());
  };

  // delete token page
  const deleteTokenPageFunction = () => {
    let err;
    try {
      if (
        deactivate_message?.length == 0 ||
        deactivate_message != "DEACTIVATE"
      ) {
        err = true;
        setErrMsg("Please type 'DEACTIVATE' to deactivate token page");
      } else {
        setErrMsg("");
      }
      if (err) {
        return;
      }
      setIsLoading(true);
      let payload = {
        captchaString: deactivate_message,
        tokenPage_id: tokenPageId,
      };
      dispatch(TokenManagerThunkAPI.deleteTokenPageAsync(payload));
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div>
      <div>
        <div className='deactivatePageSection'>
          <h2 className='font24 fontBold'>Deactivate your Token page</h2>
          <p className='colorGrey'>
            By deactivating your Token page, you’ll no longer be able to access
            any of your page data, or community discussion.
          </p>
          <a
            className='deactivateTokenBtn'
            onClick={() => handleShowDeleteTokenPage()}
          >
            Deactivate {token_name} Token Page
          </a>
        </div>
      </div>
      <DeleteTokenPageModel
        show={toggleShowModel}
        handleClose={handleCloseDeleteTokenPage}
        handleShow={handleShowDeleteTokenPage}
        showDeleteMessage={showDeleteMessage}
        deleteTokenPageFunction={deleteTokenPageFunction}
        handleDeactivateMessage={handleDeactivateMessage}
        deactivate_message={deactivate_message}
        errMsg={errMsg}
        isLoading={isLoading}
      />
    </div>
  );
}
