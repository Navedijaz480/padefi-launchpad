import React, { useState } from "react";
import Link from "next/link";
//bootstap
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Image from "next/future/image";

import { useRouter } from "next/router";
import ButtonCustom from "componants/common/ButtonCustom";

const DeleteTokenPageModel = (props) => {
  const { show, handleClose, showDeleteMessage, isLoading } = props;
  const router = useRouter();

  const onNavigate = (link) => {
    if (!getAuthToken()) router.push("/?forLoginIn=true");
    else router.push(link);
  };

  return (
    <>
      <Modal
        className='methodSelectPop deletePopUp'
        show={show}
        onHide={handleClose}
      >
        <Modal.Header>
          <Modal.Title className='font16 fontBold'>
            Delete your Token page
          </Modal.Title>
          <button
            onClick={handleClose}
            type='button'
            className='close'
            data-dismiss='modal'
            aria-label='Close'
          >
            <span aria-hidden='true' >&times;</span>
          </button>
        </Modal.Header>
        <Modal.Body>
          {showDeleteMessage ? (
            <div className='successDeletTokanBx'>
              <svg
                width='32'
                height='32'
                viewBox='0 0 32 32'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <circle
                  cx='16'
                  cy='16'
                  r='15'
                  stroke='#ECF1FF'
                  stroke-width='2'
                />
                <ellipse
                  cx='12'
                  cy='13.3332'
                  rx='2.66667'
                  ry='2.66667'
                  fill='#ECF1FF'
                />
                <ellipse
                  cx='20'
                  cy='13.3332'
                  rx='2.66667'
                  ry='2.66667'
                  fill='#ECF1FF'
                />
                <path
                  d='M22.4566 25.3332C22.5938 24.907 22.6667 24.4602 22.6667 23.9998C22.6667 21.0543 19.6819 18.6665 16 18.6665C12.3181 18.6665 9.33334 21.0543 9.33334 23.9998C9.33334 24.4602 9.40627 24.907 9.54337 25.3332C10.2834 23.0329 12.8936 21.3332 16 21.3332C19.1064 21.3332 21.7166 23.0329 22.4566 25.3332Z'
                  fill='#ECF1FF'
                />
              </svg>
              <h2 className='font16 fontBold'>
                Your Token Page is deactivated
              </h2>
              <h3 className='font16 colorGrey'>We are sorry to see you go!</h3>
            </div>
          ) : (
            <div className='deletTokenInfo'>
              <p>
                After confirming this step, your Token page will be permanently
                deactivated.
              </p>
              <p>Type "DEACTIVATE" below if you want to proceed:</p>
              <div className='form-group'>
                <input
                  type='text'
                  className='form-control'
                  name='deactivate_message'
                  value={props?.deactivate_message}
                  onChange={(e) => props?.handleDeactivateMessage(e)}
                  maxLength='10'
                  placeholder='Type the word “DEACTIVATE”'
                />
                <span className='text-danger'>{props?.errMsg}</span>
              </div>
            </div>
          )}
        </Modal.Body>
        {!showDeleteMessage && (
          <div className='modal-footer'>
            <button
              type='button'
              className='btn btn-secondary font16 fontBold'
              data-dismiss='modal'
              onClick={handleClose}
            >
              Close
            </button>
            <ButtonCustom
              type='button'
              className='btn btn-primary font16 fontBold'
              onClick={(e) => props?.deleteTokenPageFunction(e)}
              isLoading={isLoading}
              disabled={isLoading}
            >
              Deactivate
            </ButtonCustom>
          </div>
        )}
      </Modal>
    </>
  );
};

export default DeleteTokenPageModel;
