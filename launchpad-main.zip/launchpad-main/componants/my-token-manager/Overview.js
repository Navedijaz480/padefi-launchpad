import React, { useEffect, useState } from "react";
import Image from "next/future/image";
import sweplyLogo from "../../static/images/sweplyLogo.svg";

export default function Overview(props) {
  const { selectedTokenItem } = props;

  const tokenData = selectedTokenItem?.token_data;

  const [show, setShow] = useState(false);
  const handleShow = () => setShow(!show);
  return (
    <div>
      <div className='overviewTopText'>
        <h6 className='font16 fontBold'>Overview</h6>
        <p className='font16 colorGrey'>
          Edit or add new info to your page easily
        </p>
      </div>
      <div className='tokenManagerOverviewBox'>
        <div className='overviewTokenBox'>
          <div className='sweplyTokenheading'>
            <Image
              alt=''
              src={selectedTokenItem?.logo_uri || sweplyLogo}
              width={50}
              height={50}
              style={{ borderRadius: "50%" }}
            />
            <div className='tokenCoinNamebox'>
              <h3 className='font20 fontBold'>
                {(tokenData && tokenData?.[0]?.name) || "-"}
              </h3>
              <p className='colorGrey'>
                {(tokenData && tokenData?.[0]?.symbol) || "-"}
              </p>
            </div>
          </div>
          <div className='tokenPageStatusBox'>
            <p className='colorGrey'>Token page status</p>
            <span className='liveBox tokenPageStatus'>Pending</span>
            {/* <span className='liveBox statusApproved'>Approved</span>
              <span className='liveBox statusFailed'>Failed</span> */}
          </div>
        </div>
        <div className='tokenOverviewShowDetailsBox '>
          <p className='colorGrey cursor-pointer'>
            <i class='far fa-chevron-down' onClick={handleShow}></i>
            Show details
          </p>
          {show && (
            <div>
              {tokenData &&
                Array.isArray(tokenData) &&
                tokenData.map((item, i) => (
                  <div className='tokenSummeryBox mt-2' key={i + 1}>
                    {/* <div className="usdSwapDiv"></div> */}
                    <h6 className='fontBold'>
                      Contract info ({item?.networkName})
                    </h6>
                    <div className='networkBox'>
                      <h3 className='font16 colorGrey'>Token name</h3>
                      <h4 className='font16 fontBold'>{item?.name || "-"}</h4>
                    </div>
                    <div className='networkBox'>
                      <h3 className='font16 colorGrey'>Token Symbol</h3>
                      <h4 className='font16 fontBold'>{item?.symbol || "-"}</h4>
                    </div>
                    <div className='networkBox'>
                      <h3 className='font16 colorGrey'>Decimals</h3>
                      <h4 className='font16'>{item?.decimals || "-"}</h4>
                    </div>
                    <div className='networkBox'>
                      <h3 className='font16 colorGrey'>Contract address</h3>
                      <h4 className='contractAddress font16'>
                        {item?.contract_address || "-"}
                      </h4>
                    </div>
                  </div>
                ))}
            </div>
          )}
          {/* <div className="tokenSummeryBox">
            <h6 className="fontBold">Contract info (WETH)</h6>
            <div className="networkBox">
              <h3 className="font16 colorGrey">Token name</h3>
              <h4 className="font16 fontBold">
                {selectedTokenItem?.token_name || "-"}
              </h4>
            </div>
            <div className="networkBox">
              <h3 className="font16 colorGrey">Token Symbol</h3>
              <h4 className="font16 fontBold">
                {selectedTokenItem?.token_symbol || "-"}
              </h4>
            </div>
            <div className="networkBox">
              <h3 className="font16 colorGrey">Decimals</h3>
              <h4 className="font16">
                {selectedTokenItem?.token_decimal || "-"}
              </h4>
            </div>
            <div className="networkBox">
              <h3 className="font16 colorGrey">Contract address</h3>
              <h4 className="contractAddress font16"></h4>
            </div>
          </div> */}
        </div>
      </div>
      <div className='tokenDescriptionBoxOuter'>
        <div className='tokenDescriptionBox'>
          <div className='tokenDescriptionText'>
            <h5 className='font24 fontBold'>Token Description</h5>
            <p className='font16'>
              Add/change your Token info to give the users the best bio
            </p>
          </div>
          <a
            className='font16 cursor-pointer'
            onClick={() => {
              props?.onHandleWindowScroll();
              props?.setKey("token settings");
            }}
          >
            Edit Token Description
          </a>
        </div>
        <div className='tokenDescriptionBox'>
          <div className='tokenDescriptionText'>
            <h5 className='font24 fontBold'>Community links</h5>
            <p className='font16'>
              Check your social links and get more links to add
            </p>
          </div>

          <a
            className='font16 cursor-pointer'
            onClick={() => {
              props?.onHandleWindowScroll();
              props?.setKey("social links");
            }}
          >
            Add/change social links
          </a>
        </div>
        <div className='tokenDescriptionBox'>
          <div className='tokenDescriptionText'>
            <h5 className='font24 fontBold'>Have new links to add?</h5>
            <p className='font16'>
              Check your project links and change/add more links
            </p>
          </div>
          <a href='#' className='font16'></a>
          <a
            className='font16 cursor-pointer'
            onClick={() => {
              props?.onHandleWindowScroll();
              props?.setKey("token settings");
            }}
          >
            Go to Project links
          </a>
        </div>
      </div>
    </div>
  );
}
