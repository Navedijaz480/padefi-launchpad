import "../styles/globals.css";
import "bootstrap/dist/css/bootstrap.css";
//test
// Redux
import { Provider } from "react-redux";
import { useRouter } from "next/router";
import store from "../store";
//test
//  Layout
import Layout from "../componants/Layout/Layout";

// wallet connect
// this is test comments

function MyApp({ Component, pageProps }) {
  return (
    <Provider store={store}>
      <Layout>
        <Component {...pageProps} />
      </Layout>
    </Provider>
  );
}

export default MyApp;
