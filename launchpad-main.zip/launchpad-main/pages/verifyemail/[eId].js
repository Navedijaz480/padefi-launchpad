import React, { useState, useEffect } from "react";
import validator from "validator";
import { useRouter } from "next/router";
import usersService from "../../services/users.service";
import * as sweetAlert from "../../utils/sweetAlert";
const initialState = { password: "", confirmPassword: "" };
const initialError = { password: null, confirmPassword: null };

export async function getServerSideProps(context) {
  const { eId } = context.params;
  return {
    props: { eId }, // will be passed to the page component as props
  };
}
export default function VerifyEmail({ eId }) {
  const router = useRouter();
  useEffect(() => {
    let ss = eId.split("&");
    const ValidateEmail = async () => {
      try {
        const payload = {
          mail: ss[1],
          otp_code: ss[2],
        };
        //console.log("payload >>>>", payload);
        const response = await usersService.ValidateEmail(payload);
        if (response.status) {
          sweetAlert.successAlert(response.message);
          router.push("/");
        } else {
          sweetAlert.errorAlert(response.message);
        }
        //console.log("payload", payload);
      } catch (error) {
        const { name, message } = error;
        console.log(`${name}=>${message}`);
      }
    };
    ValidateEmail();
  }, [eId]);

  return (
    <div className="container-fluid">
      <div className="row justify-content-center">
        <div className="col-4"></div>
      </div>
    </div>
  );
}
