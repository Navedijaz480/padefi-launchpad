import React, { useEffect, useState, useRef } from "react";
import { useRouter } from "next/router";
import Image from "next/future/image";

import _ from "lodash";
import validator from "validator";
import moment from "moment";
//utils
import { errorAlert } from "utils/sweetAlert";
import { video_url } from "utils/config";
import * as sweetAlert from "utils/sweetAlert";

import {
  validateSoftCap,
  validateMinBuy,
  isEmpty,
  removeHtmlTags,
  addCommasInAmount,
  removeProtocol,
  getSocialIcon,
} from "utils/helpers";

//component
import Select from "react-select";
import StepBox from "componants/common/StepBox";
import FormButton from "componants/common/FormButton";
import Input from "componants/common/Input";
import RadioGroup from "componants/common/RadioGroup";
import FormSelectOption from "componants/common/FormSelectOption";
import FormCheckBox from "componants/common/FormCheckBox";
import LaunchpadMainCard from "componants/common/LaunchpadMainCard";
import CustomEditor from "componants/common/CustomEditor";
import DatePickerControl from "componants/common/DatePickerControl";
import CongratsMessage from "componants/launchpad/createlaunchpad/congratsMessage";
import CustomButton from "componants/common/CustomButton";
import LogoPreviewBox from "componants/common/LogoPreviewBox";
import Video from "componants/common/Video";

//info messages
import { info_msg_create_launchpad } from "utils/infoMessages";
import ToolTip from "componants/common/ToolTip";

//services
import { getAuthToken } from "services/authToken.service";
import launchPadService from "services/launchPad.service";

//store
import { useDispatch } from "react-redux";
import launchPadThunkAPI from "store/features/launchPads/middleware";
import tokenThunkAPI from "store/features/token/middleware";

import chainIcon from "static/images/chainicon.svg";
import sweplyLogo from "static/images/sweplyLogo.svg";
import showTwitter from "static/images/show-twitter.png";

// initial state
import {
  initialSteps,
  initialWhiteList,
  initialTokenListing,
  initialPadefiOption,
  initialWhitelistOption,
  initialRefundType,
  initialRouterType,
  initialStepOne,
  initialStepTwo,
  initialStepThree,
  initialStepFour,
  initialStepOneError,
  initialStepTwoError,
  initialStepThreeError,
  initialStepFourError,
} from "utils/forms/createLaunchpad";

// common initial state
import {
  twitter_base_url,
  initialSocialMedia,
  softcap_how_many_percent_of_hardcap,
  minbuy_how_many_percent_of_max_by,
} from "utils/forms/common";

export default function CreateLaunchpad() {
  const router = useRouter();
  const dispatch = useDispatch();

  const [isPageLoading, setIsPageLoading] = useState(false);

  const [showCongratsMessage, setShowCongratsMessage] = useState(false);
  const [createLaunchPadRes, setCreateLaunchPadRes] = useState(false);

  const [step, setStep] = useState(1);
  const [steps] = useState(initialSteps);
  const [infoMsg] = useState(info_msg_create_launchpad);
  const [whiteList, setWhiteList] = useState(initialWhiteList);
  const [tokenList, setTokenList] = useState(initialTokenListing);
  const [padefiOption, setPadefiOption] = useState(initialPadefiOption);
  const [whiteListOption, setWhiteListOption] = useState(
    initialWhitelistOption
  );
  const [refundType, setRefundType] = useState(initialRefundType);
  const [routerType, setRouterType] = useState(initialRouterType);
  const [stepOneData, setStepOneData] = useState(initialStepOne);
  const [stepOneError, setStepOneError] = useState(initialStepOneError);
  const [stepTwoData, setStepTwoData] = useState(initialStepTwo);
  const [stepTwoError, setStepTwoError] = useState(initialStepTwoError);
  const [stepThreeData, setStepThreeData] = useState(initialStepThree);
  const [stepThreeError, setStepThreeError] = useState(initialStepThreeError);
  const [stepFourData, setStepFourData] = useState(initialStepFour);

  const [stepFourError, setStepFourError] = useState(initialStepFourError);
  const [tokenDetails, setTokenDetails] = useState();

  const [socialMediaMaster, setSocialMediaMaster] =
    useState(initialSocialMedia);
  const [socialMediaList, setSocialMediaList] = useState([]);
  const [socialMediaNumberError, setSocialMediaNumberError] = useState("");
  const [socialMediaName, setSocialMediaName] = useState("");
  const [socialMediaNameError, setSocialMediaNameError] = useState([]);
  const [socialMediaLink, setSocialMediaLink] = useState("");
  const [verifyTokenLoading, setVerifyTokenLoading] = useState(false);
  const [uploadLogoLoading, setUploadLogoLoading] = useState(false);
  const [isShowCreateTokenStrip, setIsShowCreateTokenStrip] = useState(true);

  const logoRef = useRef();

  const onHandleWindowScroll = () => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth",
    });
  };

  const onHandleNextPrevStep = (event) => {
    try {
      const { name } = event.target;
      const stepMove = () => {
        if (name === "prev") {
          setStep(step - 1);
        } else {
          setStep(step + 1);
        }
      };

      if (name === "prev") {
        stepMove();
        return;
      }
      switch (step) {
        case 1:
          //stepMove();

          //if contract addres does not verified or token details not fetch
          if (stepOneData?.token_address && !tokenDetails?.token_name) {
            setStepOneError({
              ...stepOneError,
              token_address: "Verify contract address",
            });
            onHandleWindowScroll();
            return;
          }

          if (!validateForm(stepOneData, stepOneError, setStepOneError)) {
            errorAlert("Please check all fields");
          } else {
            stepMove();
          }
          break;
        case 2:
          //stepMove();
          if (!validateForm(stepTwoData, stepTwoError, setStepTwoError)) {
            errorAlert("Please check all fields");
          } else {
            stepMove();
          }
          break;
        case 3:
          //stepMove();
          if (!validateForm(stepThreeData, stepThreeError, setStepThreeError)) {
            errorAlert("Please check all fields");
          } else {
            stepMove();
          }
          break;
        case 4:
          //stepMove();
          if (!validateForm(stepFourData, stepFourError, setStepFourError)) {
            errorAlert("Please check all fields");
          } else {
            stepMove();
          }
          break;
        case 5:
          stepMove();
          break;
      }
      onHandleWindowScroll();
    } catch (error) {
      const { name, message } = error;
      console.error(`${name} => ${message}`);
    }
  };

  const onHandleUserInput = (event) => {
    try {
      let { name, value, type, checked } = event.target;
      switch (type) {
        case "checkbox":
          value = checked;
          break;
        case "text":
        case "date":
        case "radio":
        case "url":
          value = _.trim(value);
        default:
          _.trim(value);
      }

      let errors = {};
      let tempData = {};
      switch (step) {
        case 1:
          errors = { ...stepOneError };
          tempData = { ...stepOneData };

          switch (name) {
            case "token_address":
              errors.token_address =
                (isEmpty(value) &&
                  value.length < 10 &&
                  "Invalid contract address") ||
                null;

              setTokenDetails(null);
              break;
            case "whitelist_name":
              errors.whitelist_name =
                (!isEmpty(value) && "Please select one") || null;
              setRadioButtonValue(setWhiteList, value);
              break;
            case "token_option":
              errors.token_option =
                (!isEmpty(value) && "Please select one") || null;
              setRadioButtonValue(setTokenList, value);
              break;
            case "padefi_option":
              errors.padefi_option =
                (!isEmpty(value) && "Please select one") || null;
              setRadioButtonValue(setPadefiOption, value);
              break;
          }

          setStepOneData({ ...tempData, [name]: value });
          setStepOneError(errors);

          // if value is empty set message
          if (!value)
            validateFormTemp({}, stepOneError, setStepOneError, name, value);

          break;
        case 2:
          errors = { ...stepTwoError };
          tempData = { ...stepTwoData };

          switch (name) {
            case "presale_rate":
              value = value.replace(/\D/g, "");
              errors.presale_rate =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid presale rate") ||
                null;
              break;
            case "whitelist":
              errors.whitelist =
                (!isEmpty(value) && "Please select one") || null;
              setRadioButtonValue(setWhiteListOption, value);
              break;
            case "soft_cap":
              value = value.replace(/\D/g, "");
              errors.soft_cap = validateSoftCap(
                value,
                stepTwoData?.hard_cap,
                softcap_how_many_percent_of_hardcap
              );
              break;
            case "hard_cap":
              value = value.replace(/\D/g, "");
              errors.hard_cap = !value ? "Hardcap cannot be blank" : "";
              errors.soft_cap = validateSoftCap(
                stepTwoData?.soft_cap,
                value,
                softcap_how_many_percent_of_hardcap
              );
              break;
            case "minimun_buy":
              value = value.replace(/\D/g, "");
              errors.minimun_buy = validateMinBuy(
                value,
                stepTwoData?.maximum_buy,
                minbuy_how_many_percent_of_max_by
              );
              break;
            case "maximum_buy":
              value = value.replace(/\D/g, "");
              errors.maximum_buy = !value
                ? "Maximum buy must be positive number"
                : "";
              errors.minimun_buy = validateMinBuy(
                stepTwoData?.minimun_buy,
                value,
                minbuy_how_many_percent_of_max_by
              );
              break;
            case "refund_type":
              errors.refund_type =
                (!isEmpty(value) && "Select on of the above") || null;
              setRefundType((prev) =>
                prev.map((el) => {
                  el.selected = el?.name === value;
                  return el;
                })
              );
              break;
            case "router_type":
              errors.router_type =
                (!isEmpty(value) && "Select on of the above") || null;
              setRouterType((prev) =>
                prev.map((el) => {
                  el.selected = el?.name === value;
                  return el;
                })
              );
              break;
            case "router_liquidity":
              value = value.replace(/\D/g, "");
              errors.router_liquidity =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid maximum router liquidity") ||
                null;
              break;
            case "router_list_rate":
              value = value.replace(/\D/g, "");
              errors.router_list_rate =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid router list rate") ||
                null;
              break;
          }
          setStepTwoData({ ...tempData, [name]: value });
          setStepTwoError(errors);

          // if value is empty set message
          if (!value)
            // validateFormTemp({}, stepOneError, setStepTwoError, name, value);
            break;
        case 3:
          errors = { ...stepThreeError };
          tempData = { ...stepThreeData };
          switch (name) {
            case "start_date":
              errors.start_date =
                (isEmpty(value) && value.length < 1 && "select date") || null;
              break;
            case "end_date":
              errors.end_date =
                (isEmpty(value) && value.length < 1 && "select date") || null;
              break;
            case "liquidity_lockup":
              value = value.replace(/\D/g, "");
              errors.liquidity_lockup =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid liquidity lockup") ||
                null;
              break;
            case "presale_release":
              value = value.replace(/\D/g, "");
              errors.presale_release =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid presale release ") ||
                null;
              break;
            case "vesting_period":
              value = value.replace(/\D/g, "");
              errors.vesting_period =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid vesting period") ||
                null;
              break;
            case "token_release":
              value = value.replace(/\D/g, "");
              errors.token_release =
                (isEmpty(value) &&
                  value.length < 1 &&
                  "Invalid token release") ||
                null;
              break;
            case "contributer":
              tempData.vesting_period = "";
              tempData.token_release = "";
              tempData.presale_release = "";

              break;
          }
          setStepThreeData({ ...tempData, [name]: value });
          setStepThreeError(errors);

          // if value is empty set message
          if (!value)
            validateFormTemp(
              {},
              stepThreeError,
              setStepThreeError,
              name,
              value
            );
          break;
        case 4:
          errors = { ...stepFourError };
          tempData = { ...stepFourData };
          switch (name) {
            case "image_url":
              errors.image_url =
                (isEmpty(value) && value.length < 10 && "Enter valid URL") ||
                null;
              break;
            case "token_description":
              errors.token_description =
                (isEmpty(removeHtmlTags(value)) &&
                  value.length < 30 &&
                  "Enter valid description") ||
                null;
              break;
            case "website":
              errors.website =
                (isEmpty(value) &&
                  !validator.isURL(value) &&
                  "Enter valid URL") ||
                null;
              break;
            case "twitter":
              errors.twitter = !value ? "Enter username" : "";

              // errors.twitter =
              //   (isEmpty(value) &&
              //     !validator.isURL(value) &&
              //     "Enter valid URL") ||
              //   null;
              break;
          }
          setStepFourData({ ...tempData, [name]: value });
          setStepFourError(errors);
          // if value is empty set message
          if (!value)
            validateFormTemp({}, stepFourError, setStepFourError, name, value);
          break;
        case 5:
          break;
      }
    } catch (error) {
      const { name, message } = error;
      console.error(`${name} => ${message}`);
    }
  };

  const setRadioButtonValue = (setStateArr, value) => {
    setStateArr((prev) =>
      prev.map((el) => {
        el.checked = el?.defaultValue === value;
        return el;
      })
    );
  };

  const validateFormTemp = (userObj, errorObj, setObj, key, value) => {
    let errors = { ...errorObj };
    key == "token_address" &&
      !value &&
      _.assign(errors, { [key]: "Enter token contract address" });
    key == "whitelist_name" &&
      !value &&
      _.assign(errors, { [key]: "Select currency" });
    key == "token_option" &&
      !value &&
      _.assign(errors, { [key]: "Select token option" });
    key == "padefi_option" &&
      !value &&
      _.assign(errors, { [key]: "Padefi fee options" });

    key == "presale_rate" &&
      !value &&
      _.assign(errors, { [key]: "Enter presale rate" });

    key == "presale_rate" &&
      !value &&
      _.assign(errors, { [key]: "Enter presale rate" });

    key == "whitelist" &&
      !value &&
      _.assign(errors, { [key]: "Select whitelist" });

    key == "whitelist" &&
      !value &&
      _.assign(errors, { [key]: "Select whitelist" });

    key == "soft_cap" &&
      !value &&
      _.assign(errors, { [key]: "Softcap cannot be blank" });

    key == "hard_cap" &&
      !value &&
      _.assign(errors, { [key]: "Hardcap cannot be blank" });

    key == "minimun_buy" &&
      !value &&
      _.assign(errors, { [key]: "Enter minimun buy amount" });

    key == "maximum_buy" &&
      !value &&
      _.assign(errors, { [key]: "Enter maximum buy amount" });

    key == "refund_type" &&
      !value &&
      _.assign(errors, { [key]: "Select refund type" });

    key == "router_type" &&
      !value &&
      _.assign(errors, { [key]: "Select router type" });

    key == "router_liquidity" &&
      !value &&
      _.assign(errors, { [key]: "Enter router liquidity rate amount" });

    key == "router_list_rate" &&
      !value &&
      _.assign(errors, { [key]: "Enter router Listing  rate amount" });

    key == "start_date" &&
      !value &&
      _.assign(errors, { [key]: "Select start date" });

    key == "end_date" &&
      !value &&
      _.assign(errors, { [key]: "Select end date" });

    key == "liquidity_lockup" &&
      !value &&
      _.assign(errors, { [key]: "Enter liquidity lockup (Days)" });

    key == "token_description" &&
      !removeHtmlTags(value) &&
      _.assign(errors, { [key]: "Enter token description" });

    key == "image_url" &&
      !value &&
      _.assign(errors, { [key]: "Add token logo url or select logo" });

    key == "twitter" && !value && _.assign(errors, { [key]: "Enter username" });

    key == "website" &&
      !value &&
      _.assign(errors, { [key]: "Enter website url" });

    key == "token_release" &&
      _.assign(errors, {
        [key]: "Enter First release for presale amount",
      });

    key == "presale_release" &&
      _.assign(errors, { [key]: "Enter Presale token release amount" });
    key == "vesting_period" &&
      _.assign(errors, { [key]: "Enter vesting period (days)" });

    setObj(errors);
  };

  const validateForm = (userObj, errorObj, setObj) => {
    // console.log("validate 3 setObj", setObj);

    let errors = { ...errorObj };
    let data = { ...userObj };
    let valid = true;
    _.forIn(data, function (value, key) {
      // console.log("key =>", key, " value = >", value);
      if (
        key !== "anti_rug" &&
        key !== "contributer" &&
        key !== "presale_release" &&
        key !== "token_release" &&
        key !== "vesting_period" &&
        key !== "liquidity_lockup"
      ) {
        if (!value) {
          // _.assign(errors, { [key]: "Field required123" });
          valid = false;
          key == "token_address" &&
            !value &&
            _.assign(errors, { [key]: "Enter token contract address" });
          key == "whitelist_name" &&
            !value &&
            _.assign(errors, { [key]: "Select currency" });
          key == "token_option" &&
            !value &&
            _.assign(errors, { [key]: "Select token option" });
          key == "padefi_option" &&
            !value &&
            _.assign(errors, { [key]: "Padefi fee options" });

          key == "presale_rate" &&
            !value &&
            _.assign(errors, { [key]: "Enter presale rate" });

          key == "presale_rate" &&
            !value &&
            _.assign(errors, { [key]: "Enter presale rate" });

          key == "whitelist" &&
            !value &&
            _.assign(errors, { [key]: "Select whitelist" });

          key == "whitelist" &&
            !value &&
            _.assign(errors, { [key]: "Select whitelist" });

          key == "soft_cap" &&
            !value &&
            _.assign(errors, { [key]: "Softcap cannot be blank" });

          key == "hard_cap" &&
            !value &&
            _.assign(errors, { [key]: "Hardcap cannot be blank" });

          key == "minimun_buy" &&
            !value &&
            _.assign(errors, { [key]: "Enter minimun buy amount" });

          key == "maximum_buy" &&
            !value &&
            _.assign(errors, { [key]: "Enter maximum buy amount" });

          key == "refund_type" &&
            !value &&
            _.assign(errors, { [key]: "Select refund type" });

          key == "router_type" &&
            !value &&
            _.assign(errors, { [key]: "Select router type" });

          key == "router_liquidity" &&
            !value &&
            _.assign(errors, { [key]: "Enter router liquidity rate amount" });

          key == "router_list_rate" &&
            !value &&
            _.assign(errors, { [key]: "Enter router Listing  rate amount" });

          key == "start_date" &&
            !value &&
            _.assign(errors, { [key]: "Select start date" });

          key == "end_date" &&
            !value &&
            _.assign(errors, { [key]: "Select end date" });

          key == "liquidity_lockup" &&
            !value &&
            _.assign(errors, { [key]: "Enter liquidity lockup (Days)" });

          key == "token_description" &&
            !removeHtmlTags(value) &&
            _.assign(errors, { [key]: "Enter token description" });

          key == "image_url" &&
            !value &&
            _.assign(errors, { [key]: "Add token logo url or select logo" });

          key == "twitter" &&
            !value &&
            _.assign(errors, { [key]: "Enter username" });

          key == "website" &&
            !value &&
            _.assign(errors, { [key]: "Enter website url" });

          // if(key == "social_links"){
          // }
        }
      }

      if (data?.contributer) {
        if (
          key == "presale_release" ||
          key == "token_release" ||
          key == "vesting_period"
        ) {
          if (!value) {
            // _.assign(errors, { [key]: "Field required" });
            valid = false;

            key == "token_release" &&
              _.assign(errors, {
                [key]: "Enter First release for presale amount",
              });

            key == "presale_release" &&
              _.assign(errors, { [key]: "Enter Presale token release amount" });
            key == "vesting_period" &&
              _.assign(errors, { [key]: "Enter vesting period (days)" });
          }
        }
      }
    });
    setObj(errors);
    return valid;
  };

  const onClickInput = () => {
    logoRef.current && logoRef.current.click();
  };

  const onHandleFileUpload = async (event) => {
    setUploadLogoLoading(true);
    try {
      const { files } = event.target;
      const file = files && files[0];
      if (file instanceof File) {
        const fileType = file.type;
        const isImage = ["image/jpg", "image/jpeg", "image/png", "image/webp"];
        const isFileImage = Boolean(isImage.includes(fileType));
        if (isFileImage) {
          let payload = {
            imageLogo: file,
          };

          let response = await launchPadService?.uploadLogoFileS3(payload);
          if (response.data.status) {
            let tempData = { ...stepFourData };
            setStepFourData({ ...tempData, image_url: response.data.imageUri });

            setStepFourError({ ...stepFourError, image_url: "" });
          }
          setUploadLogoLoading(false);
        } else {
          setUploadLogoLoading(false);

          sweetAlert.errorAlert("Unsupported file selected.");
          throw new TypeError("The File not supported", file.name);
        }
      }
    } catch (error) {
      setUploadLogoLoading(false);

      if (error instanceof TypeError) {
        const { name, message, fileName } = error;
        console.error(`${name} => ${message} => ${fileName}`);
      }
    }
  };

  const submitLaunchpad = () => {
    setIsPageLoading(true);
    let social = {
      website: stepFourData?.website,
      twitter: stepFourData?.twitter,
    };
    if (socialMediaList && socialMediaList.length > 0) {
      for (let x of socialMediaList) {
        social[x.value] = x.url;
      }
    }

    let payload = {
      token_id: tokenDetails?._id,
      token_addr: stepOneData?.token_address,
      token_listing: tokenDetails?.token_name,
      padefi_fee_option: stepOneData?.padefi_option,
      presale_rate: stepTwoData?.presale_rate,
      whitelist: stepTwoData?.whitelist,
      softcap: stepTwoData?.soft_cap,
      hardcap: stepTwoData?.hard_cap,
      min_buy: stepTwoData?.minimun_buy,
      max_buy: stepTwoData?.maximum_buy,
      refund_type: stepTwoData?.refund_type,
      router_type: stepTwoData?.router_type,
      router_liquidity: stepTwoData?.router_liquidity,
      router_listing_rate: stepTwoData?.router_list_rate,
      start_date: stepThreeData?.start_date,
      end_date: stepThreeData?.end_date,
      liquidity_lockup_days: stepThreeData?.liquidity_lockup,
      first_release_for_presale: stepThreeData?.presale_release,
      vesting_period: stepThreeData?.vesting_period,
      presale_token_release: stepThreeData?.token_release,
      logo_url: stepFourData?.image_url,
      currency: stepOneData?.whitelist_name,
      sayf: true,
      audit: true,
      kyc: true,
      launchpad_status: "ENDED",
      descricption: stepFourData?.token_description,
      social_link: social,
    };

    dispatch(
      launchPadThunkAPI.createLaunchpadAsync({
        payload,
        callback: (res) => {
          setIsPageLoading(false);

          if (res?.status) {
            setShowCongratsMessage(true);
            setCreateLaunchPadRes(res?.data);
          } else {
          }
          // router.push("/");
        },
      })
    );
  };

  const onHandleSubmitLaunchpad = async (event) => {
    try {
      const { name } = event.target;
      switch (name) {
        case "verfiytoken":
          setVerifyTokenLoading(true);

          let payload = {
            tokenAddr: stepOneData?.token_address,
            launchpad: true,
          };

          dispatch(
            tokenThunkAPI.tokenInfoAsync({
              payload,
              callback: (res) => {
                if (res?.data?.status) {
                  setTokenDetails(res.data.data);
                  setStepOneError({
                    ...stepOneError,
                    token_address: "",
                  });
                  setVerifyTokenLoading(false);
                } else {
                  setVerifyTokenLoading(false);
                  sweetAlert.errorAlert("Invalid contract address");
                }
              },
            })
          );

          break;
        case "createToken":
          break;
        case "submit":
          submitLaunchpad();
          break;
      }
      // successAlert("Submitted Successfully");
    } catch (error) {
      const { name, message } = error;
      console.error(`${name} => ${message}`);
    }
  };

  const onHandleSocialMediaChange = (event) => {
    setSocialMediaName(event);
    setSocialMediaNameError();
  };

  const onHandleAddSocialMedia = (event) => {
    let arr = [];
    try {
      let socialMediaLists = socialMediaList;
      let err = true;
      if (socialMediaName) {
        if (!socialMediaLink) {
          setSocialMediaNumberError(
            "Please enter " + socialMediaName?.label ?? "media" + "url"
          );
        } else {
          let urlRegex =
            /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
          // if (socialMediaLink.match(urlRegex)) {
          socialMediaName.url = socialMediaLink;
          socialMediaLists.push(socialMediaName);
          setSocialMediaMaster((prev) =>
            prev.map((el) => {
              el.isDisabled = socialMediaLists.some(
                (social) => social?.value == el?.value
              );
              return el;
            })
          );
          setSocialMediaList(socialMediaLists);
          if (socialMediaLists?.length > 0) {
            socialMediaLists?.map((el) => {
              arr.push({ lable: el.label, value: el.url });
            });
            // projectDetailsInputField.block_explorer_link = arr;
          }
          setSocialMediaName("");
          setSocialMediaLink("");
          // } else {
          // setSocialMediaNumberError(
          //   "Please enter valid " + socialMediaName?.label ?? "media" + "url"
          // );
          // }
        }
      }
    } catch (error) {
      const { name, message } = error;
    }
  };

  const onHandleRemoveSocialMedia = (socialMediaLink, index) => {
    let arr = [];
    let socialMediaLists = socialMediaList;
    socialMediaLists.splice(index, 1);
    setSocialMediaList(socialMediaLists);
    if (socialMediaLists?.length > 0) {
      socialMediaLists?.map((el) => {
        arr.push({ lable: el.label, value: el.url });
      });
      // projectDetailsInputField.block_explorer_link = arr;
    }
    setSocialMediaMaster((prev) =>
      prev.map((el) => {
        el.isDisabled = socialMediaLists.some(
          (social) => social?.value == el?.value
        );
        return el;
      })
    );
  };

  const redirectToCreateToken = (e) => {
    router.push(`/toolbox?createToken=true`);
  };

  useEffect(() => {
    if (!getAuthToken()) {
      router.push("/?forLoginIn=true");
    }
  }, []);

  if (showCongratsMessage) {
    return <CongratsMessage id={createLaunchPadRes?._id} />;
  }
  return (
    <>
      <div className="createToolBoxRightSection">
        <StepBox selected={step} steps={steps} />
        <div className="createTokenMainSection">
          {step == 1 && (
            <>
              <div className="createTokenBox">
                <div className="verifyTokenTitle">
                  <h3 className="font24 fontBold">Verify Token</h3>
                  <p className="colorGrey">
                    Enter the token address and verify
                  </p>
                </div>

                {isShowCreateTokenStrip && (
                  <div className="createBtnBoxCross">
                    <p className="mb0 colorGrey font16">
                      Create a Token, If you don’t have one easily
                    </p>
                    <span>
                      <span
                        className="tokenCreteBtn backIconHeading"
                        onClick={(e) => redirectToCreateToken(e)}
                      >
                        Create Token
                      </span>

                      <i
                        className="far fa-times backIconHeading"
                        onClick={(e) => setIsShowCreateTokenStrip(false)}
                      ></i>
                    </span>
                  </div>
                )}

                <div className="form-group">
                  <Input
                    type="text"
                    name="token_address"
                    className="form-control"
                    parantclassName="tokenAddressCreateBox"
                    id="token_address"
                    placeholder="Enter token address"
                    label="Contract Address"
                    minLength={10}
                    maxLength={50}
                    err={stepOneError?.token_address}
                    onChange={onHandleUserInput}
                    value={stepOneData?.token_address}
                    info={infoMsg?.token_address}
                  />

                  <FormButton
                    className="chgUserName connectVerifyTag "
                    name="verfiytoken"
                    label={tokenDetails ? "Verified" : "Connect & Verify"}
                    disabled={!stepOneData?.token_address || tokenDetails}
                    isLoading={verifyTokenLoading}
                    onHandleClick={onHandleSubmitLaunchpad}
                  />
                </div>

                <RadioGroup
                  type="radio"
                  className="col-sm-6 col-md-6 col-lg-6"
                  parantClassName="chooseTokenChain chooseCurrencyRedio"
                  label="Choose Currency"
                  onChange={onHandleUserInput}
                  info={infoMsg?.whitelist_name}
                  name="whitelist_name"
                  subtitle="which users can pay you with"
                  err={stepOneError?.whitelist_name}
                  description="Your token will be built on Binance smart chain network, change network mainnet for other chains"
                  id={"whitelist_name"}
                  options={whiteList}
                />

                <div className="tokenListingRedioBox">
                  <div className="d-flex align-items-center">
                    <h5 className="font20 fontBold">Token Listing</h5>
                    <ToolTip text={infoMsg?.token_listing} />
                  </div>
                  <RadioGroup
                    type="radio"
                    className="col-sm-6 col-md-6 col-lg-6"
                    parantClassName="chooseTokenChain chooseCurrencyRedio"
                    label="Listing Options"
                    onChange={onHandleUserInput}
                    info={infoMsg?.token_option}
                    name="token_option"
                    subtitle=""
                    err={stepOneError?.token_option}
                    description=""
                    id={"token_option"}
                    options={tokenList}
                  />

                  <RadioGroup
                    type="radio"
                    className="col-sm-12 col-md-12 col-lg-12"
                    parantClassName="chooseTokenChain chooseCurrencyRedio"
                    label="Padefi Fee Options"
                    onChange={onHandleUserInput}
                    info={infoMsg?.padefi_option}
                    name="padefi_option"
                    subtitle=""
                    err={stepOneError?.padefi_option}
                    description=""
                    id={"padefi_option"}
                    options={padefiOption}
                  />
                </div>
                <div className="infomessage">
                  <i className="fas fa-info-circle"></i> Do not use this
                  currency for auto liquidity tokens, or tokens that depend on
                  WETH pair. It will lead to error when finalizing the pool or
                  transfering the tokens (for example Liquidity Generator Token,
                  BabyToken, Buyback Baby Token). Contact padefi for more
                  information.
                </div>
              </div>
              <LaunchpadMainCard
                dataArr={[
                  {
                    header: "Token Info",
                    data: [
                      {
                        label: "Token status",
                        value:
                          (tokenDetails?.token_name && "Token Verified") || "-",
                        valueClassName:
                          (tokenDetails?.token_name && "font16 verified-tag") ||
                          "",
                      },
                      {
                        label: "Token name",
                        value: tokenDetails?.token_name || "-",
                      },
                      {
                        label: "Token symbol",
                        value: tokenDetails?.token_symbol || "-",
                      },
                      {
                        label: "Decimals",
                        value: tokenDetails?.decimals || "-",
                      },
                      {
                        label: "Contract address",
                        value:
                          (tokenDetails?.contractAddress &&
                            tokenDetails?.contractAddress?.slice(0, 19) +
                              "...") ||
                          "-",
                      },
                    ],
                  },
                  {
                    header: "Main Currency",
                    data: [
                      {
                        label: "Users can pay you with",
                        value: stepOneData?.whitelist_name || "-",
                      },
                    ],
                  },
                  {
                    header: "Token Listing",
                    data: [
                      {
                        label: "List Options",
                        value: stepOneData?.token_option || "-",
                      },
                      {
                        label: "Padefi Fee Options",
                        value: stepOneData?.padefi_option || "-",
                      },
                    ],
                  },
                ]}
              />
            </>
          )}
          {step == 2 && (
            <>
              <div className="createTokenBox">
                <div className="verifyTokenTitle">
                  <h3 className="font24 fontBold">DeFi Launchpad Info</h3>
                  <p className="colorGrey">
                    Enter the launchpad information that you want to raise ,
                    enter all details about your presale
                  </p>
                </div>
                <Input
                  type="text"
                  name="presale_rate"
                  className="form-control"
                  parantclassName="tokenAddressCreateBox"
                  id="presale_rate"
                  placeholder="Enter presale rate"
                  label="Presale rate"
                  minLength="1"
                  maxLength="10"
                  pattern="[0-9]{10}\D"
                  err={stepTwoError?.presale_rate}
                  onChange={onHandleUserInput}
                  value={stepTwoData?.presale_rate}
                  info={infoMsg?.presale_rate}
                  fieldDesc="if I spend 1BNB how many tokens will I recive?"
                />
                <RadioGroup
                  type="radio"
                  className="col-sm-6 col-md-6 col-lg-6"
                  parantClassName="chooseTokenChain"
                  label="Whitelist"
                  onChange={onHandleUserInput}
                  info={infoMsg?.whitelist}
                  name="whitelist"
                  subtitle=""
                  err={stepTwoError?.whitelist}
                  description=""
                  id={"whitelist"}
                  options={whiteListOption}
                />
                <div className="launchpadFormdetailsBox">
                  <h2 className="font20 fontBold">
                    Launchpad details <i className="far fa-info-circle"></i>
                  </h2>
                  <div className="row">
                    <Input
                      type="text"
                      name="soft_cap"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="soft_cap"
                      placeholder="Enter amount"
                      label={`Softcap (${stepOneData.whitelist_name})`}
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.soft_cap}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.soft_cap}
                      info={infoMsg?.soft_cap}
                      fieldDesc={
                        "Softcap must be " +
                        softcap_how_many_percent_of_hardcap +
                        "% of Hardcap!"
                      }
                    />

                    <Input
                      type="text"
                      name="hard_cap"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="hard_cap"
                      placeholder="Enter amount"
                      label={`HardCap (${stepOneData.whitelist_name})`}
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.hard_cap}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.hard_cap}
                      info={infoMsg?.hard_cap}
                    />

                    <Input
                      type="text"
                      name="minimun_buy"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="minimun_buy"
                      placeholder="Enter amount"
                      label={`Minimum buy (${stepOneData.whitelist_name})`}
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.minimun_buy}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.minimun_buy}
                      info={infoMsg?.minimun_buy}
                      fieldDesc={""}

                      // "Minimum buy must be =" +
                      // minbuy_how_many_percent_of_max_by +
                      // "% of Maximum buy"
                    />

                    <Input
                      type="text"
                      name="maximum_buy"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="maximum_buy"
                      placeholder="Enter amount"
                      label={`Maximum buy (${stepOneData.whitelist_name})`}
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.maximum_buy}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.maximum_buy}
                      info={infoMsg?.maximum_buy}
                    />

                    <FormSelectOption
                      placeholder="Select refund type"
                      label="Refund type"
                      info={infoMsg?.refund_type}
                      subTitle="Choose the type of refund at the end"
                      name="refund_type"
                      options={refundType}
                      value={stepTwoData?.refund_type}
                      onHandleChange={onHandleUserInput}
                      err={stepTwoError?.refund_type}
                    />
                  </div>
                </div>
                <div className="launchpadFormdetailsBox">
                  <h2 className="font20 fontBold">
                    Liquidity info <i className="far fa-info-circle"></i>
                  </h2>
                  <div className="row">
                    <FormSelectOption
                      placeholder="Select router type"
                      label="Router type"
                      info={infoMsg?.router_type}
                      subTitle="Choose the type of router platform to use"
                      name="router_type"
                      options={routerType}
                      value={stepTwoData?.router_type}
                      onHandleChange={onHandleUserInput}
                      err={stepTwoError?.router_type}
                    />

                    <Input
                      type="text"
                      name="router_liquidity"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="router_liquidity"
                      placeholder="Enter amount"
                      label="Router Liquidity(%)"
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.router_liquidity}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.router_liquidity}
                      info={infoMsg?.router_liquidity}
                    />

                    <Input
                      type="text"
                      name="router_list_rate"
                      className="form-control"
                      parantclassName="col-sm-6 col-md-6 col-lg-6"
                      id="router_list_rate"
                      placeholder="Enter amount"
                      label="Router Listing rate"
                      minLength="1"
                      maxLength="10"
                      pattern="[0-9]{10}\D"
                      err={stepTwoError?.router_list_rate}
                      onChange={onHandleUserInput}
                      value={stepTwoData?.router_list_rate}
                      info={infoMsg?.router_list_rate}
                    />
                  </div>
                  <div className="infomessage">
                    <i className="far fa-info-circle"></i> Enter the percentage
                    of raised funds that should be allocated to Liquidity on
                    (Min 51% Max 100%) If I spend 1BNB on how many tokens will I
                    receive? Usually this amount is lower than presale rate to
                    allow for a higher listing price on
                  </div>
                </div>
              </div>
              <LaunchpadMainCard
                dataArr={[
                  {
                    header: "DeFi Launchpad Info",
                    data: [
                      {
                        label: "Presale rate",
                        value: stepTwoData?.presale_rate
                          ? addCommasInAmount(stepTwoData?.presale_rate)
                          : "",
                        subValue: tokenDetails?.token_symbol,
                      },
                      {
                        label: "Whitelist",
                        value: stepTwoData?.whitelist || "-",
                      },
                    ],
                  },
                  {
                    header: "Launchpad details",
                    data: [
                      {
                        label: "Softcap (BNB)",
                        value: stepTwoData?.soft_cap || "-",
                      },
                      {
                        label: "HardCap (BNB)",
                        value: stepTwoData?.hard_cap || "-",
                      },
                      {
                        label: "Minimum buy (BNB)",
                        value: stepTwoData?.minimun_buy || "-",
                      },
                      {
                        label: "Maximum buy (BNB)",
                        value: stepTwoData?.maximum_buy || "-",
                      },
                      {
                        label: "Refund type",
                        value: stepTwoData?.refund_type || "-",
                      },
                    ],
                  },
                  {
                    header: "Liquidity info",
                    data: [
                      {
                        label: "Router type",
                        value: stepTwoData?.router_type || "-",
                      },
                      {
                        label: "Router Liquidity(%)",
                        value: stepTwoData?.router_liquidity || "-",
                      },
                      {
                        label: "Router Listing rate",
                        value: stepTwoData?.router_list_rate || "-",
                      },
                    ],
                  },
                ]}
              />
            </>
          )}
          {step == 3 && (
            <>
              <div className="createTokenBox">
                <div className="verifyTokenTitle">
                  <h3 className="font24 fontBold">Time & Duration</h3>
                  <p className="colorGrey">
                    Enter the launchpad information that you want to raise ,
                    enter all details about your presale
                  </p>
                </div>
                <div className="row">
                  <div className="col-sm-6 col-md-6 col-lg-6">
                    <div className="form-group">
                      <label>
                        Select Start Date (UTC)
                        <ToolTip text={infoMsg?.start_date} />
                      </label>
                      <DatePickerControl
                        name="start_date"
                        className="form-control"
                        selected={stepThreeData?.start_date}
                        onChange={(selected_data) => {
                          let e = {
                            target: {
                              value: selected_data,
                              name: "start_date",
                            },
                          };
                          onHandleUserInput(e);
                        }}
                        minDate={new Date()}
                        maxDate={
                          new Date(
                            moment(stepThreeData?.end_date).subtract({
                              days: 1,
                            })
                          )
                        }
                        showTimeSelect={true}
                        dateFormat="MMM d, yyyy h:mm aa"
                        autoComplete="off"
                        placeholderText="Select start date"
                      />
                      <i class="far fa-calendar-alt"></i>
                    </div>
                  </div>

                  <div className="col-sm-6 col-md-6 col-lg-6">
                    <div className="form-group">
                      <label>
                        Select End Date (UTC)
                        <ToolTip text={infoMsg?.end_date} />
                      </label>
                      <DatePickerControl
                        name="end_date"
                        className="form-control"
                        selected={stepThreeData?.end_date}
                        onChange={(selected_data) => {
                          let e = {
                            target: {
                              value: selected_data,
                              name: "end_date",
                            },
                          };
                          onHandleUserInput(e);
                        }}
                        minDate={
                          new Date(
                            moment(stepThreeData?.start_date).add({
                              days: 1,
                            })
                          )
                        }
                        // maxDate={new Date(startDate)}
                        showTimeSelect={true}
                        dateFormat="MMM d, yyyy h:mm aa"
                        autoComplete="off"
                        placeholderText="Select end date"
                        disabled={!stepThreeData?.start_date}
                      />
                      <i class="far fa-calendar-alt"></i>
                    </div>
                  </div>
                </div>
                <div className="vestingContributorCheck">
                  <FormCheckBox
                    type="checkbox"
                    checked={stepThreeData?.anti_rug}
                    name="anti_rug"
                    id="anti_rug"
                    value={stepThreeData?.anti_rug}
                    label="Using Anti-Rug System (Team Vesting System)?"
                    onHandleChange={onHandleUserInput}
                    info={
                      info_msg_create_launchpad?.using_anti_rug_system_check_box
                    }
                  />

                  <FormCheckBox
                    type="checkbox"
                    checked={stepThreeData?.contributer}
                    name="contributer"
                    id="contributer"
                    value={stepThreeData?.contributer}
                    label="Using vesting contributor ?"
                    onHandleChange={onHandleUserInput}
                    info={
                      info_msg_create_launchpad?.using_vesting_contributor_check_box
                    }
                  />
                  {stepThreeData?.contributer && (
                    <div className="check-box">
                      <div className="checkSHowMainBox">
                        <Input
                          type="text"
                          name="presale_release"
                          className="form-control"
                          parantclassName="checkSHowMainBox"
                          id="presale_release"
                          placeholder="Enter amount"
                          label="First release for presale (Percent)"
                          minLength="1"
                          maxLength="3"
                          pattern="[0-9]{3}\D"
                          err={stepThreeError?.presale_release}
                          onChange={onHandleUserInput}
                          value={stepThreeData?.presale_release}
                          info={infoMsg?.presale_release}
                          fieldDesc="if I spend 1 BNB how many tokens will I receive?"
                          disabled={!stepThreeData?.contributer}
                        />

                        <div className="eachCycleBox">
                          <h2 className="font16 fontBold mb10">Each Cycle</h2>
                          <div className="row">
                            <Input
                              type="text"
                              name="vesting_period"
                              className="form-control"
                              parantclassName="col-sm-6 col-md-6 col-lg-6"
                              id="vesting_period"
                              placeholder="Enter days"
                              label="Vesting period (days)"
                              minLength="1"
                              maxLength="3"
                              pattern="[0-9]{3}\D"
                              err={stepThreeError?.vesting_period}
                              onChange={onHandleUserInput}
                              value={stepThreeData?.vesting_period}
                              info={infoMsg?.vesting_period}
                              disabled={!stepThreeData?.contributer}
                            />

                            <Input
                              type="text"
                              name="token_release"
                              className="form-control"
                              parantclassName="col-sm-6 col-md-6 col-lg-6"
                              id="token_release"
                              placeholder="Enter amount"
                              label="Presale token release (percent)"
                              minLength="1"
                              maxLength="3"
                              pattern="[0-9]{3}\D"
                              err={stepThreeError?.token_release}
                              onChange={onHandleUserInput}
                              value={stepThreeData?.token_release}
                              info={infoMsg?.token_release}
                              disabled={!stepThreeData?.contributer}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {stepThreeData?.contributer && (
                  <div className="infomessage">
                    <i className="far fa-info-circle"></i> Enter the percentage
                    of raised funds that should be allocated to Liquidity on
                    (Min 51% Max 100%) If I spend 1BNB on how many tokens will I
                    receive? Usually this amount is lower than presale rate to
                    allow for a higher listing price on
                  </div>
                )}
              </div>
              <LaunchpadMainCard
                dataArr={[
                  {
                    header: "Time & Duration",
                    data: [
                      {
                        label: "Start Date",
                        value: stepThreeData?.start_date
                          ? moment(stepThreeData?.start_date).format("LT") +
                            ", " +
                            moment(stepThreeData?.start_date).format("ll")
                          : "-",
                      },
                      {
                        label: "End Date",
                        value: stepThreeData?.end_date
                          ? moment(stepThreeData?.end_date).format("LT") +
                            ", " +
                            moment(stepThreeData?.end_date).format("ll")
                          : "-",
                      },
                      {
                        label: "Liquidity lockup (Days)",
                        value: stepThreeData?.liquidity_lockup || "-",
                      },
                    ],
                  },
                  {
                    header: "Using vesting contributor ?",
                    data: [
                      {
                        label: "First release for presale ",
                        value: stepThreeData?.presale_release
                          ? stepThreeData?.presale_release + "%"
                          : "-",
                      },
                      {
                        label: "Vesting period Each Cycle ",
                        value: stepThreeData?.vesting_period
                          ? stepThreeData?.vesting_period + " " + "days"
                          : "-",
                      },
                      {
                        label: "Presale token release Each Cycle ",
                        value: stepThreeData?.token_release
                          ? stepThreeData?.token_release + "%"
                          : "-",
                      },
                    ],
                  },
                ]}
              />
            </>
          )}
          {step == 4 && (
            <>
              <div className="createTokenBox">
                <div className="verifyTokenTitle">
                  <h3 className="font24 fontBold">Add Logo</h3>
                  <p className="colorGrey">
                    URL must end with a supported image extension png, jpg, jpeg
                    or gif. Use our “Create Logo URL” to generate a URL link for
                    you.
                  </p>
                </div>
                <div className="tokenAddressCreateBox logoPicURL">
                  <div className="form-group">
                    <label>
                      Logo pic URL
                      <ToolTip text={infoMsg?.logo_pic_url} />
                    </label>
                    <input
                      type="url"
                      className="form-control"
                      placeholder="Image URL"
                      id="image_url"
                      name="image_url"
                      onChange={onHandleUserInput}
                      value={stepFourData?.image_url ?? ""}
                      readOnly={true}
                    />
                    <span className="text-danger err">
                      {stepFourError?.image_url}
                    </span>
                    {/*<button className="picUploadBtn fontBold" type="button">
                      Upload
          </button>*/}

                    {/* <FormButton
                      className="chgUserName connectVerifyTag "
                      name="verfiytoken"
                      label="Upload"
                      disabled={true}
                      isLoading={false}
                      onHandleClick={() => {}}
                    /> */}
                    <p className="formGroupsmltxt colorGrey font12">
                      Image dimension should be 200x200px
                    </p>
                  </div>
                  <FormButton
                    className="tokenCreateBtnfrm fontBold"
                    type="button"
                    name="createToken"
                    label="Create Logo URL"
                    disabled={false}
                    onHandleClick={onClickInput}
                    isLoading={uploadLogoLoading}
                  >
                    <i className="far fa-cloud-upload"></i>
                  </FormButton>

                  <input
                    ref={logoRef}
                    type="file"
                    accept=".jpg, .jpeg, .png"
                    className="form-control"
                    hidden
                    onChange={(e) => onHandleFileUpload(e)}
                  />
                </div>
                <div className="platformAddDescriptionBox">
                  <h2 className="font20 fontBold">Add Description</h2>
                  <p className="colorGrey">
                    Let users know more about your project by adding detailed
                    info about your token.
                  </p>

                  <div className="form-group">
                    <label>
                      Enter Token description{" "}
                      <ToolTip text={infoMsg?.token_description} />
                    </label>

                    <CustomEditor
                      value=""
                      onChange={(e) => {
                        let obj = {
                          target: {
                            value: e,
                            name: "token_description",
                          },
                        };
                        onHandleUserInput(obj);
                      }}
                      length="1500"
                      maxCount={1500}
                      className=""
                    />

                    <p className="formGroupsmltxt colorGrey font12">
                      Helper text
                    </p>
                    <span className="text-danger err">
                      {stepFourError?.token_description}
                    </span>
                  </div>
                </div>
                <div className="socailLinkSection">
                  <h2 className="font20 fontBold">Social links</h2>
                  <p className="colorGrey">
                    Provide your socials as each link will display on your
                    launchpad page. Viewers will be able to visit your links.
                  </p>
                  <div className="allsocialSection">
                    <h3 className="font16 fontBold">Add Social link</h3>
                    <p className="colorGrey">
                      You must provide a website and a twitter account of your
                      token so users can know more about your project.
                      Otherwise, it is optional to add more social links
                    </p>
                    <div className="socialMainBox">
                      <div className="websiteTitleBox boxLeftRight15">
                        Website*
                      </div>
                      <div className="websiteNameBox">
                        <div className="form-group">
                          <input
                            type="url"
                            className="form-control"
                            placeholder="Website URL"
                            maxLength="60"
                            minLength="20"
                            id="website"
                            name="website"
                            value={stepFourData.website ?? ""}
                            onChange={onHandleUserInput}
                            required
                          />
                          <span className="text-danger err">
                            {stepFourError?.website}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="socialMainBox">
                      <div className="websiteTitleBox boxLeftRight15">
                        Twitter*
                      </div>
                      <div className="websiteNameBox">
                        <div className="form-group">
                          <input
                            type="url"
                            className="form-control"
                            placeholder="User name"
                            maxLength="60"
                            minLength="20"
                            id="twitter"
                            name="twitter"
                            value={stepFourData.twitter ?? ""}
                            onChange={onHandleUserInput}
                            required
                          />
                          <span className="text-danger err">
                            {stepFourError?.twitter}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="addwebsiteBox">
                  <h3 className="font16 fontBold">
                    Add block explorer links (Optional)
                  </h3>
                  <p className="colorGrey">(ex. EtherScan, BscScan)</p>
                  <div className="fillstreamingservicebox editProfServiceBox">
                    <div className="row row-10">
                      {socialMediaList &&
                        socialMediaList.length > 0 &&
                        socialMediaList.map((el, i) => (
                          <div
                            className="linkandFromGroupBox secondexplorerlinksBx"
                            key={i}
                          >
                            <div className="form-group socialSelectDrop">
                              <Select
                                id="portf"
                                className="favoriteGameDrop socialDropDown"
                                name="socialmedianame"
                                disabled={true}
                                noOptionsMessage={() => null}
                                isSearchable={false}
                                //menuIsOpen="true"
                                value={el}
                                // onChange={(e) => onHandleSocialMediaChange(e)}
                                // options={socialMediaMaster}
                                // isOptionDisabled={(option) => option.isDisabled}
                              />
                              <div className="invalid-feedback d-block">
                                {socialMediaNameError || null}
                              </div>
                            </div>

                            <div className="form-group">
                              {/*<label className="colorWhite active">
                            Add your {socialMediaName?.label ?? "Social"} link
                              </label>*/}
                              <input
                                type="text"
                                value={el.url}
                                // onChange={(e) => {
                                //   setSocialMediaLink(e.target.value);
                                //   setSocialMediaNumberError("");
                                // }}
                                className="form-control borderRadius4"
                                name="socialmedialink"
                                disabled={true}
                                placeholder={`Enter ${
                                  socialMediaName?.label ?? "social"
                                }  User name`}
                              />
                            </div>
                            <button
                              className="btn btn-outline-danger crossInputBtn"
                              onClick={() => onHandleRemoveSocialMedia(i)}
                            >
                              x
                            </button>
                            {/* <Button
                        varient='primary'
                        onClick={(e) => onHandleRemoveSocialMedia(el, i)}
                      >
                        <i className='fal fa-trash-alt'></i>
                      </Button> */}
                          </div>
                        ))}
                    </div>
                  </div>
                  <div className="explorerlinksSocialBox">
                    <div className="groupLinkForm posRelative sigalexplorerlinksBx ">
                      <div className="linkandFromGroupBox">
                        <div className="form-group socialSelectDrop">
                          <Select
                            id="portf"
                            className="favoriteGameDrop socialDropDown"
                            name="socialmedianame"
                            //menuIsOpen="true"
                            value={socialMediaName}
                            onChange={(e) => onHandleSocialMediaChange(e)}
                            options={socialMediaMaster}
                            isOptionDisabled={(option) => option.isDisabled}
                          />
                          <div className="invalid-feedback d-block">
                            {socialMediaNameError || null}
                          </div>
                        </div>

                        <div className="form-group">
                          {/*<label className="colorWhite active">
                            Add your {socialMediaName?.label ?? "Social"} link
                              </label>*/}
                          <input
                            type="text"
                            value={socialMediaLink ?? ""}
                            onChange={(e) => {
                              setSocialMediaLink(e.target.value);
                              setSocialMediaNumberError("");
                            }}
                            className="form-control borderRadius4"
                            name="socialmedialink"
                            placeholder={`Enter ${
                              socialMediaName?.label ?? "social"
                            }  URL`}
                          />
                        </div>
                      </div>
                      <div className="invalid-feedback d-block">
                        {socialMediaNumberError || null}
                      </div>

                      {/* <div className='btn-box'>
                  <button
                    onClick={(e) => onHandleAddSocialMedia(e)}
                    type="button"
                    className="linkCopyBtn posAbsolute borderRadius6 colorWhite font16 socialAddBtn"
                  >
                    Add
                  </button>
                </div> */}
                    </div>
                  </div>

                  <button
                    className="btnSociallink fontBold"
                    onClick={(e) => onHandleAddSocialMedia(e)}
                  >
                    <i className="far fa-plus"></i> Add another link
                  </button>
                </div>
              </div>

              <div className="tokenPreviewBox">
                <LogoPreviewBox
                  imageUrl={stepFourData?.image_url}
                  title="Token logo"
                  name={tokenDetails?.token_name}
                  symbolName={tokenDetails?.token_symbol}
                />

                <Video
                  id={"instant-step-1-video"}
                  parantClassName="videoBox"
                  className=""
                  width="100%"
                  height="100%"
                  src={video_url}
                  controls={true}
                  autoPlay={true}
                  loop={true}
                  muted={true}
                  videoTitle={"Create launchpad easily now"}
                  videoSubTitle={
                    "A quick tutorial from our experts to create a launchpad."
                  }
                />
              </div>
            </>
          )}
          {step == 5 && (
            <>
              <div className="createTokenBox">
                <div className="verifyTokenTitle">
                  <h3 className="font24 fontBold">Review & Publish</h3>
                  <p className="colorGrey">
                    Confirm your Launchpad details and publish it.
                  </p>
                </div>
                <div className="launchPadTokeninfo">
                  <h2 className="font20 fontBold">Token info</h2>

                  <div className="tokenLauchInfo">
                    <div className="launchPadTkenImgBox">
                      {stepFourData?.image_url && (
                        <Image
                          src={stepFourData?.image_url || sweplyLogo}
                          alt=""
                          width={64}
                          height={64}
                          style={{ borderRadius: "50%" }}
                        />
                      )}
                    </div>
                    <div className="tokenAddSymMainBox">
                      <div className="launchPadTokenNameBox">
                        <div className="launchPadTokenName">
                          <span className="fontBold font16">Token name</span>
                          <span className="font15">
                            {(tokenDetails?.token_name &&
                              tokenDetails?.token_name) ||
                              "-"}
                          </span>
                        </div>
                        <div className="launchPadTokenName">
                          <span className="fontBold font16">Deciemals</span>
                          <span className="font15">
                            {" "}
                            {(tokenDetails?.decimals &&
                              tokenDetails?.decimals) ||
                              "-"}
                          </span>
                        </div>
                      </div>
                      <div className="launchPadTokenNameBox">
                        <div className="launchPadTokenName">
                          <span className="fontBold font16">Token Symbol</span>
                          <span className="font15">
                            {" "}
                            {(tokenDetails?.token_symbol &&
                              tokenDetails?.token_symbol) ||
                              "-"}
                          </span>
                        </div>
                        <div className="launchPadTokenName">
                          <span className="fontBold font16">
                            Contract address
                          </span>
                          <span className="font15">
                            {(tokenDetails?.contractAddress &&
                              tokenDetails?.contractAddress?.slice(0, 40) +
                                "...") ||
                              "-"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="userPaySection">
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">
                        Users can pay you with
                      </h3>
                      <h4 className="font16 fontBold">
                        {stepOneData?.whitelist_name}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Listing Options</h3>
                      <h4 className="font16 fontBold">
                        {stepOneData?.token_option}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Padefi Fee Options</h3>
                      <h4 className="font16">{stepOneData?.padefi_option}</h4>
                    </div>
                  </div>
                </div>

                <div className="launchPadTokeninfo deFiLaunchpadInfoBox">
                  <h2 className="font20 fontBold">DeFi Launchpad Info</h2>
                  <div className="deFiInfoBox">
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Presale rate</h3>
                      <h4 className="font16">
                        {stepTwoData?.presale_rate &&
                          addCommasInAmount(stepTwoData?.presale_rate)}

                        <span className="colorGrey">
                          {" " + tokenDetails?.token_symbol}
                        </span>
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Whitelist</h3>
                      <h4 className="font16">{stepTwoData?.whitelist}</h4>
                    </div>
                  </div>
                  <div className="deFiInfoBox">
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Softcap (BNB)</h3>
                      <h4 className="font16">{stepTwoData?.soft_cap}</h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">HardCap (BNB)</h3>
                      <h4 className="font16">{stepTwoData?.hard_cap} </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Minimum buy (BNB)</h3>
                      <h4 className="font16">{stepTwoData?.minimun_buy} </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Maximum buy (BNB)</h3>
                      <h4 className="font16">{stepTwoData?.maximum_buy} </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Refund type</h3>
                      <h4 className="font16">{stepTwoData?.refund_type} </h4>
                    </div>
                  </div>
                  <div className="deFiInfoBox">
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Router type</h3>
                      <h4 className="font16">{stepTwoData?.router_type}</h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Router Liquidity(%)</h3>
                      <h4 className="font16">
                        {stepTwoData?.router_liquidity}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Router Listing rate</h3>
                      <h4 className="font16">
                        {stepTwoData?.router_list_rate}
                      </h4>
                    </div>
                  </div>
                </div>
                <div className="launchPadTokeninfo deFiLaunchpadInfoBox">
                  <h2 className="font20 fontBold">Time & Duration</h2>
                  <div className="deFiInfoBox">
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">Start Date</h3>
                      <h4 className="font16">
                        {stepThreeData?.start_date
                          ? moment(stepThreeData?.start_date).format("LT") +
                            ", " +
                            moment(stepThreeData?.start_date).format("ll")
                          : "-"}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">End Date</h3>
                      <h4 className="font16">
                        {stepThreeData?.end_date
                          ? moment(stepThreeData?.end_date).format("LT") +
                            ", " +
                            moment(stepThreeData?.end_date).format("ll")
                          : "-"}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">
                        Liquidity lockup (Days)
                      </h3>
                      <h4 className="font16">
                        {stepThreeData?.liquidity_lockup} Days{" "}
                      </h4>
                    </div>
                  </div>

                  <div className="deFiInfoBox contributorBox">
                    <h5 className="font20 fontBold">
                      Using vesting contributor?
                    </h5>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">
                        First release for presale
                      </h3>
                      <h4 className="font16">
                        {stepThreeData?.presale_release
                          ? stepThreeData?.presale_release
                          : "-"}{" "}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">
                        Vesting period Each Cycle{" "}
                      </h3>
                      <h4 className="font16">
                        {" "}
                        {stepThreeData?.vesting_period
                          ? stepThreeData?.vesting_period + "Days"
                          : "-"}
                      </h4>
                    </div>
                    <div className="networkBox">
                      <h3 className="font16 colorGrey">
                        Presale token release Each Cycle
                      </h3>
                      <h4 className="font16">
                        {" "}
                        {stepThreeData?.token_release
                          ? stepThreeData?.token_release
                          : "-"}
                      </h4>
                    </div>
                  </div>
                </div>
                {/*start socil link box  */}
                {/*start socil link box  */}
                <div className="launchPadTokeninfo socialLinksShowBOx">
                  <h2 className="font20 fontBold">Social links</h2>
                  <div className="row">
                    <div className="col-sm-6 col-md-6 col-lg-6">
                      <div className="detailsSocilBox">
                        <a
                          href={stepFourData?.website}
                          target="_blank"
                          rel="noreferrer"
                        >
                          <div className="socailLinkShowBx font16 colorGrey">
                            {" "}
                            <Image src={chainIcon} alt="" />{" "}
                            {removeProtocol(stepFourData?.website)}
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="col-sm-6 col-md-6 col-lg-6">
                      <div className="detailsSocilBox">
                        <a
                          href={twitter_base_url + stepFourData?.twitter}
                          target="_blank"
                          rel="noreferrer"
                        >
                          <div className="socailLinkShowBx font16 colorGrey">
                            {" "}
                            <Image src={showTwitter} alt="" />{" "}
                            {stepFourData?.twitter}
                          </div>
                        </a>
                      </div>
                    </div>

                    {socialMediaList &&
                      socialMediaList.map((el, index) => (
                        <div className="col-sm-6 col-md-6 col-lg-6" key={index}>
                          <div className="detailsSocilBox">
                            <a
                              href={el?.baseUrl + el?.url}
                              target="_blank"
                              rel="noreferrer"
                            >
                              <div className="socailLinkShowBx font16 colorGrey">
                                {" "}
                                <Image
                                  src={getSocialIcon(el?.value)}
                                  alt=""
                                />{" "}
                                @{el?.url}
                              </div>
                            </a>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
                {/*end socil link box  */}
              </div>
              <LaunchpadMainCard
                dataArr={[
                  {
                    header: "Payment details",
                    data: [
                      {
                        label: "Launchpad creation",
                        value: "-",
                      },
                      {
                        label: "Additional fees",
                        value: "-",
                      },
                      {
                        label: "Total",
                        value: "-",
                        rowClassName: "networkBox marginTop30",
                      },
                    ],
                  },
                ]}
              />
            </>
          )}
        </div>

        <div className="tokenFooterBox">
          <CustomButton
            lable={"Cancel"}
            onClick={() => {
              router.push("/toolbox");
            }}
            className={
              step == 1
                ? "nextBtn prevBtn canbtnFrm"
                : "nextBtn prevBtn canbtnFrm floatLeft"
            }
            isLoading={false}
            disabled={isPageLoading}
          />
          {step > 1 && (
            <FormButton
              className="nextBtn"
              name="prev"
              label="Prev"
              disabled={isPageLoading}
              isLoading={false}
              onHandleClick={onHandleNextPrevStep}
            />
          )}
          {(step != 5 && (
            <FormButton
              className="nextBtn"
              name="next"
              label="Next"
              disabled={false}
              isLoading={false}
              onHandleClick={onHandleNextPrevStep}
            />
          )) || (
            <FormButton
              className="nextBtn"
              name="submit"
              label="Submit"
              disabled={false}
              isLoading={isPageLoading}
              onHandleClick={onHandleSubmitLaunchpad}
            />
          )}
        </div>
      </div>
    </>
  );
}
