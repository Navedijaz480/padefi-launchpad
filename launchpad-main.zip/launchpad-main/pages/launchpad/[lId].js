import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Image from "next/future/image";
import tokenBanner from "../../static/images/token-banner-img.png";
//REDUX
import { useSelector, useDispatch } from "react-redux";
import LaunchPadThunkAPI from "store/features/launchPads/middleware";
//IMPORT COMPONENT
import TokenProgress from "componants/launchpad/TokenProgress";
import Chart from "componants/launchpad/Chart";
import CommunityTrust from "componants/launchpad/CommunityTrust";
import InfoRow from "componants/launchpad/InfoRow";
import HeaderDetails from "componants/launchpad/HeaderDetails";
import Loader from "componants/common/Loader";
import Buy from "componants/launchpad/Buy";

import { STATUSES } from "../../utils/statuses";

import { openAuthModal } from "store/features/users/usersSlice";

//Services

import { getAuthToken } from "services/authToken.service";

const Details = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const launchPadState = useSelector((state) => state.launchPadState);
  const Details = launchPadState?.singleLaunchpadDetails || null;

  useEffect(() => {
    const payload = {
      launchpad_id: router.query?.lId,
    };
    dispatch(LaunchPadThunkAPI.getSingleLaunchpadDetailsAsync(payload));
  }, [router.query]);

  const handleLike = () => {
    if (!getAuthToken()) {
      // router.push("/?forLoginIn=true");
      dispatch(openAuthModal());
      return;
    }
  };

  const handleDislike = () => {
    if (!getAuthToken()) {
      // router.push("/?forLoginIn=true");
      dispatch(openAuthModal());
      return;
    }
  };

  return (
    <div className="launchPadDetailsPageSection">
      {STATUSES?.LOADING == launchPadState?.singleUserStatus && <Loader />}
      <div className="sweplyTokenSection">
        <div className="sweplyTokenDetailsBox">
          {/* header details */}
          <HeaderDetails
            image_url={""}
            tokenName={Details?.tokenName}
            token_symbol={Details?.token_symbol}
            sayf={Details?.sayf}
            kyc={Details?.kyc}
            audit={Details?.audit}
            contractAddr={Details?.token_addr}
            status={Details?.launchpad_status}
            isFavourite={Details?.isfavourite}
            onAddRemoveFavourite={() => {}}
          />

          {/* <p className="mt30">{Details?.descricption}</p> */}
          <div
            dangerouslySetInnerHTML={{ __html: Details?.descricption }}
            className="mt30"
          />

          <Image className="tokenBannerImg" alt="" src={tokenBanner} />
          <div className="tokenSaleDetailsSection">
            <div className="tokenSummeryBox">
              <h2 className="fontBold font24 mb16">Token Sale Details </h2>

              <InfoRow
                valueClassName={""}
                label={"Listing On"}
                // value={"PancakeSwap"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"colorYellow"}
                label={"Presale Address"}
                //value={"0xA681910xA681910xA68191...2aB8fB"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"colorYellow"}
                label={"Token Address"}
                value={Details?.token_addr}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Sale ID"}
                //value={"2606"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Total Supply"}
                //value={"1,000,000,000 ASO"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Tokens For IDO"}
                //value={"2,460,000 ASO"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Tokens For Liquidity"}
                //value={"765,000 ASO"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Soft Cap"}
                value={Details?.softcap}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Hard Cap"}
                value={Details?.hardcap}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"IDO Rate"}
                //value={"250 ESV per BNB"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"PancakeSwap Listing Rate"}
                //value={"250 ESV per BNB"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"PancakeSwap Liquidity %"}
                //value={"250 ESV per BNB"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Minimum Contribution"}
                //value={"0.09 BNB"}
                value={"-"}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"IDO Start Time"}
                value={Details?.start_date}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"IDO End Time"}
                value={Details?.end_date}
              />
              <InfoRow
                valueClassName={"fontBold"}
                label={"Liquidity Unlock Date"}
                //value={"23 Jan 2023 at 19:30"}
                value={"-"}
              />
            </div>
          </div>
        </div>

        <div className="multichainBox">
          <div className="tokenDetailProgressBar mb16">
            {/* token progress */}
            <TokenProgress />

            {/* Buy */}
            <Buy />
          </div>
          {/* token details */}
          <div className="tokenDetailProgressBar mb16">
            <div className="tokenSaleDetailsSection borderNone mt0 mb24">
              <div className="tokenSummeryBox mb0">
                <h2 className="fontBold font24 mb16">Token details</h2>
                <div class="networkBox">
                  <h3 class="font16 colorGrey">Sale type</h3>
                  <h4 class="font700 colorYellow">Public</h4>
                </div>
                <div class="networkBox">
                  <h3 class="font16 colorGrey">Minimum buy</h3>
                  <h4 class="">0.09 BNB</h4>
                </div>
                <div class="networkBox">
                  <h3 class="font16 colorGrey">Maximum buy</h3>
                  <h4 class="">5 BNB</h4>
                </div>
                <div class="networkBox">
                  <h3 class="font16 colorGrey">Total contributors</h3>
                  <h4 class="">2</h4>
                </div>
              </div>
            </div>

            <Chart />
          </div>
          {/* community trust */}
          {/* <CommunityTrust /> */}

          {/* community trust */}
          <CommunityTrust
            data={{}}
            title={"Community trust"}
            question={"Do you like Sweply?"}
            likeBtnLabel={"Like"}
            dislikeBtnLabel={"Dislike"}
            onLike={handleLike}
            onDislike={handleDislike}
            likeLoader={false}
            disLikeLoader={false}
          />
        </div>
      </div>
    </div>
  );
};

export default Details;
