import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useSelector, useDispatch } from "react-redux";
//IMPORT COMPONENT-
import Cart from "componants/dashboard/Cart";
import LaunchpadHeader from "componants/launchpad/all-launchpad/LaunchpadHeader";
import Filter from "componants/launchpad/all-launchpad/Filter";
import Loader from "componants/common/Loader";
import { STATUSES } from "../../utils/statuses";
import DashboardThunkAPI from "store/features/dashboard/middleware";
import LaunchPadThunkAPI from "store/features/launchPads/middleware";
import { likeDislikeLaunchpad } from "store/features/dashboard/dashboardSlice";

const Launchpad = () => {
  const dispatch = useDispatch();
  const [size] = useState(50);
  const [pageNo, setpageNo] = useState(1);

  const dashboardState = useSelector((state) => state.dashboardState);
  const allLaunchpadList = dashboardState?.allLaunchpadList;
  /**
   * @desc show all user launchpad list on launchpad:
   */
  useEffect(() => {
    const payload = {
      pageNo: pageNo,
      size: size,
    };
    dispatch(DashboardThunkAPI.getAllLaunchpadAsync(payload));
  }, []);
  /**
   * @desc add or remove favourite launchpad to list
   */
  const handleAddRemoveLaunchpad = (Id) => {
    dispatch(likeDislikeLaunchpad(Id));
    try {
      const payload = {
        launchpad_id: Id,
      };
      dispatch(
        LaunchPadThunkAPI.addFavouriteLaunchpadAsync({
          payload: payload,
          callback: (res) => {},
        })
      );
    } catch (error) {
      console.log("error", error);
    }
  };

  return (
    <div>
      <div className='dashInnerBox'>
        {STATUSES?.LOADING == dashboardState?.status && <Loader />}
        {/* HEADER */}
        <LaunchpadHeader
          heading={"Launchpad List"}
          buttonName={"Create Launchpad"}
        />
        {/* FILTER */}
        <Filter />

        <div className='latestLaunchpadSection presalesSection'>
          <div className='row'>
            {allLaunchpadList &&
              Array.isArray(allLaunchpadList) &&
              allLaunchpadList.map((item, i) => (
                <div
                  className='col-xl-4 col-lg-6 col-md-6 col-sm-12'
                  key={i + 1}
                >
                  <Cart
                    Id={item?._id}
                    tokenName={item?.tokenName || "NA"}
                    token_symbol={item?.token_symbol || "NA"}
                    hardcap={item?.hardcap || "NA"}
                    status={item?.launchpad_status || "NA"}
                    isKYC={item?.kyc || "NA"}
                    isAudit={item?.audit || "NA"}
                    isSAYF={item?.sayf || "NA"}
                    start_date={item?.start_date || "NA"}
                    end_date={item?.end_date || "NA"}
                    created_date={item?.created_at}
                    currency={item?.currency || "NA"}
                    isLiked={item?.isLiked}
                    handleLikeUnlike={handleAddRemoveLaunchpad}
                  />
                </div>
              ))}
            {/* <div className="latestLaunchpadBox">
                  <div className="latestLaunchpadHead">
                    <Image alt="" src={sweplyLogo} />
                    <div className="latestLaunchpadDetails">
                      <div className="likeBox">
                        <i className="far fa-heart"></i>
                        <span className="liveBox font12">Live</span>
                      </div>
                      <div className="clearfix"></div>
                        <span className="liveBox sayf font12">SAYF</span>
                        <span className="liveBox audit font12">Audit</span>
                        <span className="liveBox kyc font12">KYC</span>
                    </div>
                  </div>
                  <h3 className="font18 fontBold">El Salvador crypto work</h3>
                  <p className="font14">Project will receive 30% at first release</p>
                  <div className="progressBarBox">
                    
                    <div className="launchpadProgressBar">
                      <div className="progressInner" style={{width:"50%"}}>
                      <div className="launchpadProgressBarProgress">50%</div>
                    </div>
                    </div>
                    <div className="launchpadProgressBarReading">
                      <p className="leftReading">123 BNB</p>
                      <p className="rightReading">246 BNB</p>
                    </div>
                  </div>
                  <div className="saleEndTimerBox">
                    <p className="font16">Sale Ends in<span>25:06:48</span></p>
                    <a href="#" className="launchpadViewBtn">View <Image alt="" src={viewBtnArrow} className="viewBtnArrow" /><Image alt="" src={viewBtnArrowBlack} className="viewBtnArrowBlack" /></a>
                  </div>
                </div> */}
            {/* 
             <div className="col-xl-4 col-lg-6 col-md-6 col-sm-12">
              <div className="latestLaunchpadBox">
                <div className="latestLaunchpadHead">
                  <Image alt="" src={sweplyLogo} />
                  <div className="latestLaunchpadDetails">
                    <div className="likeBox">
                      <i className="far fa-heart"></i>
                      <span className="liveBox upcoming font12">Upcoming</span>
                    </div>
                    <div className="clearfix"></div>
                    <span className="liveBox sayf font12">SAYF</span>
                    <span className="liveBox audit font12">Audit</span>
                    <span className="liveBox kyc font12">KYC</span>
                  </div>
                </div>
                <h3 className="font18 fontBold">El Salvador crypto work</h3>
                <p className="font14">
                  Project will receive 30% at first release
                </p>
                <div className="progressBarBox">
                  <div className="launchpadProgressBar">
                    <div className="progressInner" style={{ width: "50%" }}>
                      <div className="launchpadProgressBarProgress">50%</div>
                    </div>
                  </div>
                  <div className="launchpadProgressBarReading">
                    <p className="leftReading">123 BNB</p>
                    <p className="rightReading">246 BNB</p>
                  </div>
                </div>
                <div className="saleEndTimerBox">
                  <p className="font16">
                    Sale Ends in<span>25:06:48</span>
                  </p>
                  <a href="#" className="launchpadViewBtn">
                    View{" "}
                    <Image alt="" src={viewBtnArrow} className="viewBtnArrow" />
                    <Image
                      alt=""
                      src={viewBtnArrowBlack}
                      className="viewBtnArrowBlack"
                    />
                  </a>
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Launchpad;
