import React, { useState } from "react";
import validator from "validator";
import { useRouter } from "next/router";
import usersService from "../../services/users.service";
import { custValidator } from "../../utils/helpers";
import * as sweetalert from "../../utils/sweetAlert";

const initialState = { password: "", confirmPassword: "" };
const initialError = { password: null, confirmPassword: null };

export async function getServerSideProps(context) {
  const { rId } = context.params;
  return {
    props: { rId }, // will be passed to the page component as props
  };
}
export default function Index({ rId }) {
  const router = useRouter();
  const [userDetails, setUserDetails] = useState(initialState);
  const [validateError, setValidateError] = useState(initialError);
  const [passwordType, setPasswordType] = useState("password");
  const [passwordType2, setPasswordType2] = useState("password");

  const togglePassword = (label) => {
    if (label === "newPassword") {
      let temp = "";
      temp = passwordType == "password" ? "text" : "password";
      setPasswordType(temp);
    } else {
      let temp = "";
      temp = passwordType2 == "password" ? "text" : "password";
      setPasswordType2(temp);
    }
  };

  const onHandleInfo = (event, label) => {
    const { value } = event.target;
    switch (label) {
      case "password":
        setUserDetails({ ...userDetails, password: value.trim() });
        break;
      case "confirmPassword":
        setUserDetails({ ...userDetails, confirmPassword: value.trim() });
        break;
      case "passwordError":
        if (!validator.isLength(value, { min: 8, max: 20 })) {
          setValidateError({
            ...validateError,
            password: "Password length should be grater than 8 less than 20",
          });
        } else if (!validator.isStrongPassword(value)) {
          setValidateError({
            ...validateError,
            password:
              "password must contain atleast one uppercase letter,special character and number.",
          });
        } else {
          setValidateError({
            ...validateError,
            password: null,
          });
        }
        break;
      case "confirmPassErr":
        if (value !== userDetails.password) {
          setValidateError({
            ...validateError,
            confirmPassword: "Password Mismatch",
          });
        } else {
          setValidateError({
            ...validateError,
            confirmPassword: null,
          });
        }
        break;
      default:
        setUserDetails(initialState);
        setValidateError(initialError);
        break;
    }
  };
  const passCheck = Boolean(
    userDetails.password &&
      userDetails.confirmPassword &&
      userDetails.password === userDetails.confirmPassword
  );
  const checkError = Boolean(
    validateError.password || validateError.confirmPassword
  );
  const onHandleResetPass = async (event) => {
    event.preventDefault();
    try {
      if (
        custValidator.isEmpty(userDetails.password) &&
        custValidator.isEmpty(userDetails.confirmPassword) &&
        passCheck &&
        !checkError
      ) {
        let payload = {
          slug: rId,
          passPhrase: userDetails.confirmPassword,
        };
        //console.log("payload", payload);
        const response = await usersService.resetPassword(payload);
        if (response.status) {
          setUserDetails(initialState);
          sweetalert.successAlert(response.message);
          router.push("/");
        } else {
          sweetalert.errorAlert(response.message);
        }
        {
          console.log("Error");
          setValidateError({
            ...validateError,
          });
        }
      }
    } catch (error) {
      const { name, message } = error;
      console.log(`${name}=>${message}`);
    }
  };
  return (
    <div className="resetPasswordPage">
      <div className="card-body">
        <form onSubmit={(e) => onHandleResetPass(e)}>
          <h3 className="mb-3">Change Password</h3>
          <div className="resetPassword">
            <div className="form-group">
              <label>New Password</label>
              <input
                type={passwordType}
                className="form-control"
                placeholder="Enter new password"
                value={userDetails.password}
                onChange={(e) => onHandleInfo(e, "password")}
                onBlur={(e) => onHandleInfo(e, "passwordError")}
                onCut={(e) => e.preventDefault()}
                onCopy={(e) => e.preventDefault()}
                onPaste={(e) => e.preventDefault()}
              />
              <span
                className="showEyeIcon cursor-pointer"
                onClick={() => togglePassword("newPassword")}
              >
                {passwordType === "password" ? (
                  <i className="far fa-eye-slash"></i>
                ) : (
                  <i className="far fa-eye"></i>
                )}
              </span>
              <div>
                <h6 style={{ color: "#d34747" }}>{validateError.password}</h6>
              </div>
            </div>
            <div className="form-group">
              <label>Confirm Password</label>
              <input
                type={passwordType2}
                className="form-control"
                placeholder="Enter confirm password"
                value={userDetails.confirmPassword}
                onChange={(e) => onHandleInfo(e, "confirmPassword")}
                onBlur={(e) => onHandleInfo(e, "confirmPassErr")}
                onCut={(e) => e.preventDefault()}
                onCopy={(e) => e.preventDefault()}
                onPaste={(e) => e.preventDefault()}
              />
              <span
                className="showEyeIcon cursor-pointer"
                onClick={() => togglePassword("confirmPassword")}
              >
                {passwordType2 === "password" ? (
                  <i className="far fa-eye-slash"></i>
                ) : (
                  <i className="far fa-eye"></i>
                )}
              </span>
              <div>
                <h6 style={{ color: "#d34747" }}>
                  {validateError.confirmPassword}
                </h6>
              </div>
            </div>

            <button
              // className={
              //   (checkError && "createAccountBtn2") || " createAccountBtn"
              // }
              className={
                ((!userDetails?.password ||
                  !userDetails?.confirmPassword ||
                  checkError) &&
                  "createAccountBtn2 cursor-no-drop mb-4") ||
                " createAccountBtn mb-4"
              }
              type="submit"
              disabled={
                !userDetails?.password ||
                !userDetails?.confirmPassword ||
                checkError
              }
              //style={{ cursor: (checkError && "no-drop") || "pointer" }}
            >
              Change
            </button>
            {/* <h6 className="mt-4">
              Already have an account?
              <span style={{ color: "#4feb34" }}>Sign in</span>
            </h6> */}
          </div>
        </form>
      </div>
    </div>
  );
}
