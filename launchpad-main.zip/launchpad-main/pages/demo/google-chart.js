//For next js and react

import React from "react";
import { Chart } from "react-google-charts";
export const data = [
  ["Task", "Hours per Day"],
  ["Work", 11],
  ["Eat", 2],
  ["Commute", 2],
  ["Watch TV", 2],
  ["Sleep", 7],
];
// export const options = {
//   chart: {
//     title: "Teams",
//     subtitle: "Sales, Expenses, and Profit: 2014-2017",
//   },
// };

export const options = {
  title: "Population of Largest U.S. Cities",
  subtitle: "Sales, Expenses, and Profit: 2014-2017",
  chartArea: { width: "50%" },
  colors: ["#b0120a", "#ffab91"],
  hAxis: {
    title: "Total Population",
    minValue: 0,
  },
  vAxis: {
    title: "City",
  },
};

export default function TeamsChart() {
  return (
    <div className="m-5">
      <Chart
        className="chart-color"
        chartType="PieChart"
        width="100%"
        height="400px"
        data={data}
        options={options}
      />
    </div>
  );
}
