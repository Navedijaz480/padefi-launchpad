import React, { useEffect } from "react";
import { useRouter } from "next/router";

const Dashboard = () => {
  const router = useRouter();

  useEffect(() => {
    router.push("/launchpad");
  }, []);
  
  return <div>Dashboard</div>;
};

export default Dashboard;
