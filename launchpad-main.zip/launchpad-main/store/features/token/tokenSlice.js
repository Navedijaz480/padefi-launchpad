import { createSlice } from "@reduxjs/toolkit";
import { STATUSES } from "../../../utils/statuses";
import tokenThunkAPI from "./middleware";

const initialState = {
  tokenData: null,
  singleUserTokenList: null,
  singleTokenDetails: null,
  tokenSinglePostData: null,
  tokenPostList: null,
  verifyTokenDetails: null,
  singleStatus: STATUSES.IDLE,
  status: STATUSES.IDLE,
  likeStatus: null,
  createStatus: "false",
  createVoteStatus: "false",
  allTokenomicsFeesUser: null,
  tokeVoteDetails: null,
  statusTokenomicsFee: STATUSES.IDLE,
  compileContractData: null,
  tokenPageFavouriteStatus: null,
};

const tokenSlice = createSlice({
  name: "token",
  initialState,
  reducers: {
    clearAllStatus: (state, action) => {
      state.tokenSinglePostData = null;
      state.createStatus = false;
      state.likeStatus = null;
    },
  },
  extraReducers: {
    // verifu token address
    [tokenThunkAPI.tokenInfoAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [tokenThunkAPI.tokenInfoAsync.fulfilled]: (state, action) => {
      state.status = "true";
      state.verifyTokenDetails = action.payload;
    },
    [tokenThunkAPI.tokenInfoAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
  },
});
export const { clearAllStatus } = tokenSlice.actions;
export default tokenSlice.reducer;
