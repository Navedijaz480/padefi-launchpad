import { createAsyncThunk } from "@reduxjs/toolkit";
import tokenService from "../../../../services/token.service.js";
import secure from "../../../../utils/secure";
import * as sweetAlert from "../../../../utils/sweetAlert";

const tokenThunkAPI = {
  //verify token address
  tokenInfoAsync: createAsyncThunk(
    "/tokenInfo",
    async ({ payload, callback }) => {
      try {
        const response = await tokenService.tokenInfo(payload);
        if (response?.data?.status == 1) {
          sweetAlert.successAlert("Token verified");
          callback(response);

          return response?.data?.data;
        } else {
          callback({ status: 0 });

          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        callback({ status: 0 });

        sweetAlert.errorAlert(error?.message);
        return null;
      }
    }
  ),
};
export default tokenThunkAPI;
