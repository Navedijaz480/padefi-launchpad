import { createSlice } from "@reduxjs/toolkit";
import { STATUSES } from "../../../utils/statuses";
import UsersThunkAPI from "./middleware";
import * as sweetAlert from "../../../utils/sweetAlert";
//auth token
import {
  removeCurrantUser,
  setUserWalletInfoInStorage,
  getUserWalletInfo,
  removeUserWalletInfo,
} from "../../../services/authToken.service";

const initialState = {
  user: null,
  userWalletInfo: getUserWalletInfo() ? getUserWalletInfo() : null,
  status: STATUSES.IDLE,
  forgotPwPopup: false,
  isOpenAuthModal: false,
};
const usersSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    openAuthModal: (state) => {
      state.isOpenAuthModal = true;
    },
    closeAuthModal: (state) => {
      state.isOpenAuthModal = false;
    },
    openForgotPwPopup: (state) => {
      state.forgotPwPopup = true;
    },
    closeForgotPwPopup: (state) => {
      state.forgotPwPopup = false;
    },
    logout: (state) => {
      state.user = null;
      state.userWalletInfo = null;
      removeCurrantUser();
      getUserWalletInfo();
      sweetAlert.successAlert("Logged out successfully");
    },
    updateUserDetailsInStore: (state, action) => {
      state.user = action?.payload;
    },
    setUserWalletInfo: (state, action) => {
      // called from NetworkChainSelectorPopup , WalletConnecterPopup
      setUserWalletInfoInStorage(action.payload);
      state.userWalletInfo = action.payload;
    },
  },
  extraReducers: {
    /**
     * @desc Login signup with wallete:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.loginSignupWithWallet.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.loginSignupWithWallet.fulfilled]: (state, action) => {
      state.user = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.loginSignupWithWallet.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },

    /**
     * @desc user login:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.loginAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.loginAsync.fulfilled]: (state, action) => {
      state.user = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.loginAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc  user signup:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.signupAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.signupAsync.fulfilled]: (state, action) => {
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.signupAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc update profile:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.updateProfileAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.updateProfileAsync.fulfilled]: (state, action) => {
      state.user = action?.payload?.data || {};
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.updateProfileAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc user details:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.userDetailsAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.userDetailsAsync.fulfilled]: (state, action) => {
      state.user = action?.payload?.data || {};
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.userDetailsAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc uplade profile image  or bannar image:
     * @param {*} state
     * @param {*} action
     */
    [UsersThunkAPI.updateProfileAndBannerImageAsync.pending]: (
      state,
      action
    ) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.updateProfileAndBannerImageAsync.fulfilled]: (
      state,
      action
    ) => {
      state.user.user_banner_image = action?.payload?.user_banner_image;
      state.user.user_profile_image = action?.payload?.user_profile_image;
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.updateProfileAndBannerImageAsync.rejected]: (
      state,
      action
    ) => {
      state.status = STATUSES.ERROR;
    },

    // updateEmail
    [UsersThunkAPI.updateEmail.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.updateEmail.fulfilled]: (state, action) => {
      // state.user = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.updateEmail.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },

    // validateEmail
    [UsersThunkAPI.validateEmail.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [UsersThunkAPI.validateEmail.fulfilled]: (state, action) => {
      state.user = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [UsersThunkAPI.validateEmail.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
  },
});

export const {
  openForgotPwPopup,
  closeForgotPwPopup,
  logout,
  changeVerifyUserStatus,
  openAuthModal,
  closeAuthModal,
  setUserWalletInfo,
} = usersSlice.actions;

export default usersSlice.reducer;

// validateEmail
