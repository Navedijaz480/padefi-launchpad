import { createAsyncThunk } from "@reduxjs/toolkit";
import usersService from "../../../../services/users.service";
import { setCurrantUser } from "../../../../services/authToken.service";
import * as sweetAlert from "../../../../utils/sweetAlert";
import { data } from "pages/demo/google-chart";

const UsersThunkAPI = {
  // loginSignupWithWallet
  loginSignupWithWallet: createAsyncThunk(
    "user/loginSignupWithWallet",
    async ({ payload, callback }) => {
      try {
        const response = await usersService.loginSignupWithWallet(payload);
        callback(response?.data);
        if (response?.data?.status == 1) {
          // sweetAlert.successAlert(response?.data?.message);
          response.data.data.isSignInOrSignUpWithWallete = true;
          let currant_user = {
            token: response?.data?.data?.token,
            isSignInOrSignUpWithWallete: true,
          };

          setCurrantUser(currant_user);
          callback(response?.data);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        callback(error);
        return null;
      }
    }
  ),

  //signup :
  signupAsync: createAsyncThunk(
    "user/signup",
    async ({ payload, callback }) => {
      try {
        const response = await usersService.signup(payload);
        callback(response?.data);
        if (response?.data.status) {
          sweetAlert.successAlert(response?.data?.message);
        } else {
          sweetAlert.errorAlert(response?.data?.message);
        }
        return null;
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        callback(error);
        return null;
      }
    }
  ),

  //login :
  loginAsync: createAsyncThunk("user/login", async ({ payload, callback }) => {
    try {
      const response = await usersService.login(payload);
      callback(response?.data);
      if (response?.data?.status == 1) {
        sweetAlert.successAlert(response?.data?.message);
        response.data.data.isSignInOrSignUpWithWallete = false;

        let currant_user = {
          token: response.data.data.token,
          isSignInOrSignUpWithWallete: false,
        };

        setCurrantUser(currant_user);
        // callback(response?.data);
        return response?.data.data;
      } else {
        sweetAlert.errorAlert(response?.data?.message);
        return null;
      }
    } catch (error) {
      sweetAlert.errorAlert(error?.message);
      callback(error);
      return null;
    }
  }),

  //updateProfile :
  updateProfileAsync: createAsyncThunk(
    "user/updateProfile",
    async (payload) => {
      const response = await usersService.updateProfile(payload);
      if (response?.status == 1) {
        sweetAlert.successAlert("Profile updated");
      }
      return response;
    }
  ),

  //userDetails :
  userDetailsAsync: createAsyncThunk("user/userDetails", async (payload) => {
    const response = await usersService.userDetails(payload);
    return response;
  }),

  //Update profile & banner image :
  updateProfileAndBannerImageAsync: createAsyncThunk(
    "user/updateProfileAndBannerImage",
    async (payload) => {
      try {
        let response = await usersService.updateProfileAndBannerImage(payload);
        // callback(response?.data);
        if (response?.data.status) {
          sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        // callback(error);
        return null;
      }
    }
  ),

  // updateEmail
  updateEmail: createAsyncThunk(
    "user/updateEmail",
    async ({ payload, callback }) => {
      try {
        let response = await usersService.updateEmail(payload);
        callback(response?.data);
        if (response?.data.status) {
          sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        callback({ status: 0, message: error?.message });
        return null;
      }
    }
  ),

  // updateEmail
  validateEmail: createAsyncThunk(
    "user/validateEmail",
    async ({ payload, callback }) => {
      try {
        let response = await usersService.validateEmail(payload);
        callback(response?.data);
        if (response?.data.status) {
          sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        callback({ status: 0, message: error?.message });
        return null;
      }
    }
  ),
};
export default UsersThunkAPI;
