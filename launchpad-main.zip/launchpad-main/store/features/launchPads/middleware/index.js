import { createAsyncThunk } from "@reduxjs/toolkit";
import * as sweetAlert from "../../../../utils/sweetAlert";
import launchPadService from "../../../../services/launchPad.service";

const LaunchPadThunkAPI = {
  //get user favourite launchpad :
  favouriteLaunchPadAsync: createAsyncThunk(
    "launchPad/favouriteLaunchpadList",
    async (payload) => {
      try {
        const response = await launchPadService.userFavouriteLaunchPadList(
          payload
        );
        //console.log("res launch fav", response);
        if (response?.data.status) {
          //console.log("res", response);
          //sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          // sweetAlert.errorAlert(response?.data?.message);
          //console.log("err", response);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        return null;
      }
    }
  ),
  //add /remove favourite launchpad to list :
  addFavouriteLaunchpadAsync: createAsyncThunk(
    "launchpad/addFavouriteLaunchpad",
    async ({ payload, callback }) => {
      try {
        const response = await launchPadService.addRemoveFavouriteLaunchpad(
          payload
        );
        if (response?.data.status) {
          callback(response?.data);
          ///sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          //console.log("err", response);
          return null;
        }
      } catch (error) {
        sweetAlert.errorAlert(error?.message);
        return null;
      }
    }
  ),
  //get user single launchpad details :
  getSingleLaunchpadDetailsAsync: createAsyncThunk(
    "launchpad/getSingleLaunchpadDetails",
    async (payload) => {
      try {
        const response = await launchPadService.getSingleLaunchpadDetails(
          payload
        );
        //console.log("res>>>>", response);
        if (response?.data?.status) {
          //sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        //console.log("error123", error);
        sweetAlert.errorAlert(error?.message);
        return null;
      }
    }
  ),

  //get user single launchpad details :
  createLaunchpadAsync: createAsyncThunk(
    "launchpad/createLaunchpad",
    async ({ payload, callback }) => {
      try {
        const response = await launchPadService.createLaunchpad(payload);
        callback(response?.data);

        //console.log("res>>>>", response);
        if (response?.data?.status) {
          // sweetAlert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          sweetAlert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        callback({ status: 0 });

        sweetAlert.errorAlert(error?.message);
        return null;
      }
    }
  ),
};
export default LaunchPadThunkAPI;
