import { createSlice, current } from "@reduxjs/toolkit";
import { STATUSES } from "../../../utils/statuses";
import LaunchPadThunkAPI from "./middleware";

const initialState = {
  launchPad: null,
  singleLaunchpadDetails: null,
  status: STATUSES.IDLE,
  singleUserStatus: STATUSES.IDLE,
};

const launchPadSlice = createSlice({
  name: "launchPads",
  initialState,
  reducers: {
    // addRemoveLaunchpad: (state, action) => {
    //   state.launchPad.map((item, i) => {
    //     console.log("item l", item);
    //     if (item?._id == action?.payload) {
    //       item.isLiked = !item.isLiked;
    //     }
    //   });
    // },
    removeFavouriteLaunchpad: (state, action) => {
      console.log("first123 state", current(state));
      console.log("first123 payload", action.payload);

      state.launchPad = state.launchPad.filter((item, i) => {
        return item?._id !== action?.payload;
      });
    },
  },
  extraReducers: {
    /**
     * @desc get user launchpad :
     */
    [LaunchPadThunkAPI.favouriteLaunchPadAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [LaunchPadThunkAPI.favouriteLaunchPadAsync.fulfilled]: (state, action) => {
      state.launchPad = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [LaunchPadThunkAPI.favouriteLaunchPadAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc add or remove user launchpad :
     */
    [LaunchPadThunkAPI.addFavouriteLaunchpadAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [LaunchPadThunkAPI.addFavouriteLaunchpadAsync.fulfilled]: (
      state,
      action
    ) => {
      // state.launchPad = action?.payload;
      // state.launchPad = state.launchPad.filter((item, i) => {
      //   item?._id !== action?.payload;
      // });
      // console.log("state.launchPad ", current(state.launchPad));
      state.status = STATUSES.IDLE;
    },
    [LaunchPadThunkAPI.addFavouriteLaunchpadAsync.rejected]: (
      state,
      action
    ) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc get single user launchpad details :
     */
    [LaunchPadThunkAPI.getSingleLaunchpadDetailsAsync.pending]: (
      state,
      action
    ) => {
      state.singleUserStatus = STATUSES.LOADING;
    },
    [LaunchPadThunkAPI.getSingleLaunchpadDetailsAsync.fulfilled]: (
      state,
      action
    ) => {
      state.singleLaunchpadDetails = action?.payload;
      state.singleUserStatus = STATUSES.IDLE;
    },
    [LaunchPadThunkAPI.getSingleLaunchpadDetailsAsync.rejected]: (
      state,
      action
    ) => {
      state.singleUserStatus = STATUSES.ERROR;
    },
    //Create launchpad
    [LaunchPadThunkAPI.createLaunchpadAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [LaunchPadThunkAPI.createLaunchpadAsync.fulfilled]: (state, action) => {
      state.status = STATUSES.IDLE;
    },
    [LaunchPadThunkAPI.createLaunchpadAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
  },
});
export const { addRemoveLaunchpad, removeFavouriteLaunchpad } =
  launchPadSlice.actions;
export default launchPadSlice.reducer;
