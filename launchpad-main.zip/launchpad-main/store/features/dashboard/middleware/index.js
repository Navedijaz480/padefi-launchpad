import { createAsyncThunk } from "@reduxjs/toolkit";
import dashboardService from "services/dashboard.service";
import * as sweetalert from "../../../../utils/sweetAlert";
const DashboardThunkAPI = {
  //get user all launchpad on dashboard:
  getAllLaunchpadAsync: createAsyncThunk(
    "dashboard/getUserAllLaunchpad",
    async (payload) => {
      try {
        const response = await dashboardService.getAllLaunchpad(payload);
        console.log("all launchpad", response);
        if (response?.data?.status) {
          //sweetalert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          // sweetalert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        // sweetalert.successAlert(error?.message);
        return null;
      }
    }
  ),
  //get user all presale on dashboard:
  getAllPresaleAsync: createAsyncThunk(
    "dashboard/getUserAllPresale",
    async (payload) => {
      try {
        const response = await dashboardService.getAllPresale(payload);
        //console.log("presale res", response);
        if (response?.data?.status) {
          //sweetalert.successAlert(response?.data?.message);
          return response?.data?.data;
        } else {
          // sweetalert.errorAlert(response?.data?.message);
          return null;
        }
      } catch (error) {
        // sweetalert.successAlert(error?.message);
        return null;
      }
    }
  ),
};
export default DashboardThunkAPI;
