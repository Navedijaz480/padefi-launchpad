import { createSlice, current } from "@reduxjs/toolkit";
// import index from "pages/pool-invested-list";
import { STATUSES } from "../../../utils/statuses";
import DashboardThunkAPI from "./middleware";

const initialState = {
  allLaunchpadList: null,
  allPresaleList: null,
  status: STATUSES.IDLE,
};
const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {
    likeDislikeLaunchpad: (state, action) => {
      state.allLaunchpadList.map((item, index) => {
        if (item?._id == action?.payload) {
          item.isLiked = !item.isLiked;
        }
      });
    },
    likeDislikePresale: (state, action) => {
      state.allPresaleList.map((item, index) => {
        if (item?._id == action?.payload) {
          item.isLiked = !item.isLiked;
        }
      });
    },
  },
  extraReducers: {
    /**
     * @desc get all user launchpad
     */
    [DashboardThunkAPI.getAllLaunchpadAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [DashboardThunkAPI.getAllLaunchpadAsync.fulfilled]: (state, action) => {
      state.allLaunchpadList = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [DashboardThunkAPI.getAllLaunchpadAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
    /**
     * @desc get all user presale
     */
    [DashboardThunkAPI.getAllPresaleAsync.pending]: (state, action) => {
      state.status = STATUSES.LOADING;
    },
    [DashboardThunkAPI.getAllPresaleAsync.fulfilled]: (state, action) => {
      state.allPresaleList = action?.payload;
      state.status = STATUSES.IDLE;
    },
    [DashboardThunkAPI.getAllPresaleAsync.rejected]: (state, action) => {
      state.status = STATUSES.ERROR;
    },
  },
});

export const { likeDislikeLaunchpad } = dashboardSlice.actions;
export const { likeDislikePresale } = dashboardSlice.actions;

export default dashboardSlice.reducer;
