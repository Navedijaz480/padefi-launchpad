import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import logger from "redux-logger";
import launchPadReducer from "./features/launchPads/launchPadSlice";
import usersReducer from "./features/users/usersSlice";
import tokenReducer from "./features/token/tokenSlice";
import dashboardReducer from "./features/dashboard/dashboardSlice";
import appSettingsReducer from "./features/appSettings/appSettingsSlice";
// import privateSaleReducer from "./features/privateSale/privateSaleSlice";
// import tokenManagerReducer from "./features/tokenManager/tokenManagerSlice";

const reducer = combineReducers({
  appSettingsState: appSettingsReducer,
  users: usersReducer,
  launchPadState: launchPadReducer,
  // presaleState: privateSaleReducer,
  tokenState: tokenReducer,
  dashboardState: dashboardReducer,
  // tokenManagerState: tokenManagerReducer,
});
const store = configureStore({
  reducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger),
  devTools: process.env.NODE_ENV !== "production",
});
export default store;

// presale
// privateSale
